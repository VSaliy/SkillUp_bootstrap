package mocking

// DoStuffer is a simple interface
type DoStuffer interface {
	DoStuff(input string) error
}
