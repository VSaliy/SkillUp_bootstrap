#!/usr/bin/env bash

mkdir -p output/corpus

echo "0.01" > output/corpus/a
echo "-0.01" > output/corpus/b
echo "0.10" > output/corpus/c
echo "1.00" > output/corpus/d
echo "-1.00" > output/corpus/e
echo "1.11" > output/corpus/f
echo "1" > output/corpus/g
echo "2" > output/corpus/h
echo "999.99" > output/corpus/i
