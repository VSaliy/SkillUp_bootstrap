package main

import "github.com/agtorre/go-cookbook/chapter4/context"

func main() {
	context.Initialize()
}
