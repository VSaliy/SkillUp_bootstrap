package main

import "github.com/agtorre/go-cookbook/chapter9/context"

func main() {
	context.Exec()
}
