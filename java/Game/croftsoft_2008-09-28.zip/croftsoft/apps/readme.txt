CroftSoft Module "apps"
Copyright 2008 CroftSoft Inc
Licensed under the GNU Lesser General Public License version 3.0 (LGPLv3)
http://www.CroftSoft.com/
David Wallace Croft
2008-09-28

===

Module "apps" contains the application specific code.
Reusable source that is not application specific can be found in module "core". 

===

This file is part of CroftSoft Module "apps".

CroftSoft Module "apps" is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public License as
published by the Free Software Foundation; either version 3 of the
License, or (at your option) any later version.

CroftSoft Module "apps" is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

===

Copies of the LGPL and GPL licenses can be found in the subdirectory "doc".