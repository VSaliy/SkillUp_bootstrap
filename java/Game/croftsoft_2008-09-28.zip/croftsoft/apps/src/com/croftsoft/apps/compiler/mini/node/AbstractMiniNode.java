     package com.croftsoft.apps.compiler.mini.node;

     /*********************************************************************
     * Abstract class for MiniNode objects.
     *
     * <P>
     *
     * Reserved for use as an Adapter if needed in the future.
     *
     * @see
     *   MiniNode
     *
     * @author
     *   <A HREF="http://www.alumni.caltech.edu/~croft/">David W. Croft</A>
     * @version
     *   1999-04-24
     *********************************************************************/

     public abstract class  AbstractMiniNode implements MiniNode
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }
