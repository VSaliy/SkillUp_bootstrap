     package com.croftsoft.apps.savor;
     
     import java.awt.*;
     import java.awt.event.*;
     import java.io.*;
     import java.util.*;
     import java.util.concurrent.*;
     import java.util.logging.*;

     import javax.imageio.ImageIO;

     import org.jdesktop.jdic.screensaver.ScreensaverContext;
     import org.jdesktop.jdic.screensaver.ScreensaverSettings;
     import org.jdesktop.jdic.screensaver.SimpleScreensaver;

     import com.croftsoft.core.awt.image.ImageLib;
     import com.croftsoft.core.math.MathConstants;

     /*********************************************************************
     * CroftSoft Savor.
     *
     * @version
     *   $Id: SavorPix.java,v 1.17 2006/12/16 06:30:46 croft Exp $
     * @since
     *   2006-12-09
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  SavorPix
       extends SimpleScreensaver
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final String
       PROPERTY_SHOW  = "show",
       PROPERTY_SPEED = "speed";
       
     private static final String [ ]  PROPERTY_SHOW_VALUES = {
       "off",
       "on" };
     
     private static final String [ ]  PROPERTY_SPEED_VALUES = {
       "slow",
       "medium",
       "fast" };
     
     private static final int [ ]  DISPLAY_TIMES = {
       600,
       60,
       6 };
     
     private static final boolean [ ]  SHOW_VALUES = {
       false,
       true };
     
     private static final long  DEFAULT_DISPLAY_TIME_NANOS
       = DISPLAY_TIMES [ 0 ] * MathConstants.NANOSECONDS_PER_SECOND;
     
     private static final boolean  DEFAULT_SHOW
       = SHOW_VALUES [ 0 ];
     
     private static final int  FRAME_PERIOD = 1;
     
     //
     
     private final Map<String, Integer>  speedMap;
     
     private final Map<String, Boolean>  showMap;
     
     private final Random  random;
     
     private final Logger  logger;
     
     //
     
     private boolean
       initialized,
       show,
       skip;
       
     private int
       componentWidth,
       componentHeight;
     
     private Image  offscreenImage;
     
     private String [ ]  imageFilenames;
     
     private long
       displayTimeNanos,
       lastTimeNanos;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  SavorPix ( )
     //////////////////////////////////////////////////////////////////////
     {
       Logger.getLogger ( "org.jdesktop.jdic.screensaver" ).setLevel (
         Level.FINEST );
       
       logger = Logger.getLogger ( getClass ( ).getName ( ) );
       
       logger.setLevel ( Level.FINEST );
       
       // Turn this on for debugging.
       // initLoggingToFiles ( logger );
       
       random = new Random ( );
       
       speedMap = new HashMap<String, Integer> ( );
       
       for ( int  i = 0; i < PROPERTY_SPEED_VALUES.length; i++ )
       {
         speedMap.put (
           PROPERTY_SPEED_VALUES [ i ],
           new Integer ( DISPLAY_TIMES [ i ] ) );
       }
       
       displayTimeNanos = DEFAULT_DISPLAY_TIME_NANOS;
       
       showMap = new HashMap<String, Boolean> ( );
       
       for ( int  i = 0; i < PROPERTY_SHOW_VALUES.length; i++ )
       {
         showMap.put (
           PROPERTY_SHOW_VALUES [ i ],
           new Boolean ( SHOW_VALUES [ i ] ) );
       }
       
       show = DEFAULT_SHOW;
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     @Override
     public synchronized void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         logger.entering ( getClass ( ).getName ( ), "init" );

         lastTimeNanos = 0;

         final ScreensaverContext  screensaverContext = getContext ( );

         final Component  component = screensaverContext.getComponent ( );

         componentWidth  = component.getWidth  ( );

         componentHeight = component.getHeight ( );

         if ( ( componentWidth  > 0 )
           && ( componentHeight > 0 ) )
         {       
           offscreenImage
           = component.createImage ( componentWidth, componentHeight );
         }

         // Might be called more than once

         if ( initialized )
         {
           return;
         }

         initialized = true;

         // Spacebar skipping stopped working in the switch from Java 5
         // to Java 6.  I do not know why.
         
         component.addKeyListener (
           new KeyAdapter ( )
           {
             @Override
             public void  keyPressed ( final KeyEvent  keyEvent )
             {
               final int  keyCode = keyEvent.getKeyCode ( );

               if ( keyCode == KeyEvent.VK_SPACE )
               {
                 logger.info ( "spacebar pressed" );

                 skip = true;
               }
             }
           } );

         component.requestFocus ( );

         final Integer  displayTimeInteger
           = ( Integer ) getPropertyValue ( PROPERTY_SPEED, speedMap );

         if ( displayTimeInteger != null )
         {
           displayTimeNanos = displayTimeInteger.intValue ( )
           * MathConstants.NANOSECONDS_PER_SECOND;
         }

         final Boolean  showBoolean
         = ( Boolean ) getPropertyValue ( PROPERTY_SHOW, showMap );

         if ( showBoolean != null )
         {
           show = showBoolean.booleanValue ( );
         }

         final Executor  executor = Executors.newSingleThreadExecutor ( );

         executor.execute (
           new Runnable ( )
           {
             public void  run ( )
             {
               imageFilenames = getImageFilenames ( );
             }
           } );
       }
       catch ( final Throwable  throwable )
       {
         throwable.printStackTrace ( );
         
         logger.throwing ( getClass ( ).getName ( ), "init", throwable );
       }
       finally
       {
         logger.exiting ( getClass ( ).getName ( ), "init" );
       }
     }
       
     @Override
     public void  paint ( final Graphics  graphics )
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         if ( ( offscreenImage == null    )
           || ( imageFilenames == null    )
           || ( imageFilenames.length < 1 ) )
         {
           graphics.setColor ( Color.BLACK );

           graphics.fillRect (
             0, 0, Integer.MAX_VALUE, Integer.MAX_VALUE );

           return;
         }

         final long  currentTimeNanos = System.nanoTime ( );

         final long  deltaTimeNanos = currentTimeNanos - lastTimeNanos;

         if ( skip
           || ( deltaTimeNanos >= displayTimeNanos ) )
         {
           logger.info ( "paint changing image" );
         
           skip = false;

           lastTimeNanos = currentTimeNanos;

           final Graphics2D  offscreenGraphics2D
             = ( Graphics2D ) offscreenImage.getGraphics ( );

           offscreenGraphics2D.setColor ( Color.BLACK );

           offscreenGraphics2D.fillRect (
             0, 0, componentWidth, componentHeight );

           if ( ( imageFilenames != null    )
             && ( imageFilenames.length > 0 ) )
           {
             final int  imageIndex
               = random.nextInt ( imageFilenames.length );

             final String  imageFilename = imageFilenames [ imageIndex ];

             logger.info ( imageFilename );
             
             final File  imageFile = new File ( imageFilename );

             final Image  image = ImageIO.read ( imageFile );

             final Rectangle  rectangle = ImageLib.shrinkToFitAndCenter (
               image.getWidth  ( null ),
               image.getHeight ( null ),
               componentWidth,
               componentHeight );

             logger.info ( rectangle.toString ( ) );
             
             if ( image != null )
             {
               offscreenGraphics2D.drawImage (
                 image,
                 rectangle.x,
                 rectangle.y,
                 rectangle.width,
                 rectangle.height,
                 null );
             }
             else
             {
               logger.info ( "null image" );
             }

             if ( show )
             {
               offscreenGraphics2D.setColor ( Color.GREEN );

               offscreenGraphics2D.drawString ( imageFilename, 20, 20 );
             }
           }
           else
           {
             logger.info ( "no images" );
             
             offscreenGraphics2D.setColor ( Color.RED );

             offscreenGraphics2D.drawString ( "no images", 20, 20 );
           }
           
           offscreenGraphics2D.dispose ( );

           graphics.drawImage ( offscreenImage, 0, 0, null );
         }

         Thread.sleep ( FRAME_PERIOD );
       }
       catch ( final Throwable  throwable )
       {
         throwable.printStackTrace ( );
         
         logger.throwing ( getClass ( ).getName ( ), "paint", throwable );
         
         graphics.setColor ( Color.RED );
         
         graphics.fillRect ( 0, 0, Integer.MAX_VALUE, Integer.MAX_VALUE );
         
         graphics.setColor ( Color.BLACK );
         
         graphics.drawString ( throwable.getMessage ( ), 30, 30 );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     // private methods
     //////////////////////////////////////////////////////////////////////
     
     private String [ ]  getImageFilenames ( )
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         final String [ ]  suffixes = ImageIO.getReaderFileSuffixes ( );
         
         final String  userHome = System.getProperty ( "user.home" );
       
         if ( userHome == null )
         {
           return null;
         }
         
         final File  homeDirectory = new File ( userHome );
         
         if ( !homeDirectory.exists ( )
           || !homeDirectory.isDirectory ( ) )
         {
           return null;
         }
       
         File  picturesDirectory
           = new File ( homeDirectory, "My Documents/My Pictures" );
         
         if ( !picturesDirectory.exists ( )
           || !picturesDirectory.isDirectory ( ) )
         {
           picturesDirectory = homeDirectory;
         }
         
         final Set<String>  imageFilenameSet = new HashSet<String> ( );
         
         final Stack<File>  directoryStack = new Stack<File> ( );
         
         directoryStack.add ( picturesDirectory );
         
         File  directory = null;
         
         while ( !directoryStack.isEmpty ( ) )
         {
           directory = directoryStack.pop ( );
           
           final String [ ]  list = directory.list ( );
           
           for ( String  filename : list )
           {
             final File  file = new File ( directory, filename );
             
             if ( file.isDirectory ( ) )
             {
               directoryStack.add ( file );
               
               continue;
             }
             
             filename = filename.toLowerCase ( );
             
             for ( final String  suffix : suffixes )
             {
               if ( filename.endsWith ( "." + suffix ) )
               {
                 filename = file.getCanonicalPath ( );
             
                 imageFilenameSet.add ( filename );
                 
                 break;
               }
             }
           }
         }
         
         return imageFilenameSet.toArray ( new String [ 0 ] );
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
       }
       
       return null;
     }
     
     private Object  getPropertyValue (
       final String  propertyName,
       final Map     propertyMap )
     //////////////////////////////////////////////////////////////////////
     {
       final ScreensaverContext  screensaverContext = getContext ( );
       
       final ScreensaverSettings  screensaverSettings
         = screensaverContext.getSettings ( );
       
       String  propertyValue
         = screensaverSettings.getProperty ( propertyName );
       
       if ( propertyValue == null )
       {
         return null;
       }
       
       propertyValue = propertyValue.trim ( ).toLowerCase ( );
       
       return propertyMap.get ( propertyValue );
     }
     
     private static void  initLoggingToFiles ( final Logger  logger )
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         final String  userHome = System.getProperty ( "user.home" );

         if ( userHome == null )
         {
           return;
         }

         final File  homeDirectory = new File ( userHome );

         if ( !homeDirectory.exists ( )
           || !homeDirectory.isDirectory ( ) )
         {
           return;
         }

         final File  logDirectory
           = new File ( homeDirectory, ".croftsoft/savor" );

         logDirectory.mkdirs ( );

         final FileHandler  fileHandler = new FileHandler (
           "%h/.croftsoft/savor/savor%g.log",
           10000,
           2,
           false );

         Logger.getLogger ( "org.jdesktop.jdic.screensaver" ).addHandler (
           fileHandler );

         logger.addHandler ( fileHandler );
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }