     package com.croftsoft.apps.cyborg;

     import java.io.*;
     import java.util.*;
     
     import org.apache.commons.math.MathException;
     import org.apache.commons.math.distribution.DistributionFactory;
     import org.apache.commons.math.distribution.NormalDistribution;     
     import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;     

     /*********************************************************************
     * Surrogate directional activity.
     *
     * Translated from SurrogateDirectionalActivityV2.xls (2004 October)
     * by Lawrence J. Cauller, Ph.D., which was donated to the
     * Public Domain by Dr. Cauller on 2004-12-01.
     *
     * @version
     *   2004-12-23
     * @since
     *   2004-10-19
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  Activity
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     private static final int  DIRECTIONS =   8;

     private static final int  NEURONS    =  24;

     private static final int  TRIALS     = 100;

     //

     private static final double  RATE_SPONTANEOUS = 10.0;

     private static final double  RATE_MIN         =  5.0;

     private static final double  RATE_MAX         = 50.0;

     private static final double  RATE_DEVIATION   = 10.0;

     //

     /** Random number generator. */
     private static final Random  random = new Random ( );
     
     /** Used to create normal distributions for adding noise. */
     private static final DistributionFactory  distributionFactory
       = DistributionFactory.newInstance ( );
     
     //
     
     private static final String  OUTPUT_FILENAME = "out.txt";

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public static void  main ( String [ ]  args )
       throws Exception
     //////////////////////////////////////////////////////////////////////
     {
       // Write the output to a file using PrintStream printf().
       
       PrintStream  printStream = new PrintStream (
         new FileOutputStream ( OUTPUT_FILENAME ) );
       
       // Assume we know the preferred stimulus direction for each of the
       // neurons that we are recording from.
       
       double [ ]  preferredDirections = new double [ NEURONS ];

       for ( int  unit = 0; unit < NEURONS; unit++ )
       {
         // Assume that the neurons we chose have evenly distributed
         // preferred stimulus directions
         
         preferredDirections [ unit ]
           = ( 2.0 * Math.PI * ( unit ) ) / NEURONS;
       }

       printTemplateActivations ( printStream, preferredDirections );

       runTrials ( printStream, preferredDirections );       
     }
     
     /*********************************************************************
     * Prints the template activations with one standard dev of noise.
     *********************************************************************/
     public static void  printTemplateActivations (
       PrintStream  printStream,
       double [ ]   preferredDirections )
       throws Exception
     //////////////////////////////////////////////////////////////////////
     {
       double [ ]  templateActivations = new double [ NEURONS ];

       double [ ]  addDeviations       = new double [ NEURONS ];

       double [ ]  subDeviations       = new double [ NEURONS ];

       printStream.println ( "unit preferred template addDev subDev" );

       for ( int  unit = 0; unit < NEURONS; unit++ )
       {
         templateActivations [ unit ] = computeNoiselessActivation (
           0.0, preferredDirections [ unit ] );

         addDeviations [ unit ]
           = templateActivations [ unit ] + RATE_DEVIATION;

         subDeviations [ unit ]
           = templateActivations [ unit ] - RATE_DEVIATION;

         subDeviations [ unit ] = Math.ceil ( subDeviations [ unit ] );

         if ( subDeviations [ unit ] <= 0.0 )
         {
           subDeviations [ unit ] = 0.0;
         }
         
         printStream.printf (
           "%1$02d %2$03.0f %3$06.3f %4$06.3f %5$06.3f%n",
           new Object [ ] {
             new Integer ( unit ),
             new Double ( Math.toDegrees (
               preferredDirections [ unit ] ) ),
             new Double ( templateActivations [ unit ] ),
             new Double ( addDeviations       [ unit ] ),
             new Double ( subDeviations       [ unit ] ) } );
       }
     }
       
     /*********************************************************************
     * Runs the trials, gathers statistics, and prints the results.
     *********************************************************************/
     public static void  runTrials (
       PrintStream  printStream,
       double [ ]   preferredDirections )
       throws Exception
     //////////////////////////////////////////////////////////////////////
     {
       // initialize statistics objects
       
       DescriptiveStatistics [ ]  descriptiveStatisticsArray
         = new DescriptiveStatistics [ DIRECTIONS ];
       
       DescriptiveStatistics [ ] [ ]
         averagePopulationVectorsDescriptiveStatistics
         = new DescriptiveStatistics [ DIRECTIONS ] [ NEURONS ];

       for ( int  i = 0; i < DIRECTIONS; i++ )
       {
         descriptiveStatisticsArray [ i ]
           = DescriptiveStatistics.newInstance ( );
         
         for ( int  j = 0; j < NEURONS; j++ )
         {
           averagePopulationVectorsDescriptiveStatistics [ i ] [ j ]
             = DescriptiveStatistics.newInstance ( );
         }
       }
       
       DescriptiveStatistics  grandDescriptiveStatistics
         = DescriptiveStatistics.newInstance ( );
       
       // run the trial data
       
       printStream.println ( "\n" + "trial actual predicted error" ); 

       for ( int  trial = 0; trial < TRIALS; trial++ )
       {
         int  directionIndex = ( trial * DIRECTIONS ) / TRIALS;
         
         double  actualDirection
           = directionIndex * 2.0 * Math.PI / DIRECTIONS; 
         
         double [ ]  noisyActivations = new double [ NEURONS ];
       
         for ( int  unit = 0; unit < NEURONS; unit++ )
         {
           // record the activity from a single neuron for the given trial
           
           noisyActivations [ unit ] = generateNoisyActivation (
             preferredDirections [ unit ],
             actualDirection );
           
           // record the statistical data for this direction and this unit
           
           averagePopulationVectorsDescriptiveStatistics
             [ directionIndex ] [ unit ].addValue (
             noisyActivations [ unit ] );
         }
         
         // Knowing only the preferred directions for each neuron and their
         // current activations, predict the direction for this trial.
         
         double  predictedDirection = predictDirection (
           preferredDirections,
           noisyActivations );
         
         // Compute the error between predicted and actual direction

         double  error = Math.abs ( Math.min (
           predictedDirection - actualDirection,
           actualDirection + 2.0 * Math.PI - predictedDirection ) );
         
         // How variable is the error for the trials in a given direction?
         
         descriptiveStatisticsArray [ directionIndex ].addValue ( error );
         
         // How variable is the error from trial to trial?
         
         grandDescriptiveStatistics.addValue ( error );
         
         // trial actual predicted error

         printStream.printf (
           "%1$02d %2$03.0f %3$07.3f %4$07.3f%n",
           new Object [ ] {
             new Integer ( trial ),
             new Double ( Math.toDegrees ( actualDirection ) ),
             new Double ( Math.toDegrees ( predictedDirection ) ),
             new Double ( Math.toDegrees ( error ) ) } );
       }
       
       printStream.println ( "\n" +
         "direction / mean error / error std / mean-error / mean+error" );  

       for ( int  i = 0; i < DIRECTIONS; i++ )
       {
         double  direction = i * 2.0 * Math.PI / DIRECTIONS;
         
         double  meanError = descriptiveStatisticsArray [ i ].getMean ( );
         
         double  errorStd
           = descriptiveStatisticsArray [ i ].getStandardDeviation ( );
         
         // the mean error and standard deviation in error for a direction
         
         printStream.printf (
           "%1$03.0f %2$06.3f %3$06.3f %4$06.3f %5$06.3f%n",
           new Double ( Math.toDegrees ( direction ) ),
           new Double ( Math.toDegrees ( meanError ) ),
           new Double ( Math.toDegrees ( errorStd  ) ),
           new Double ( Math.toDegrees ( meanError - errorStd ) ),
           new Double ( Math.toDegrees ( meanError + errorStd ) ) );
       }
       
       // the mean error and standard deviation in error for all trials
         
       printStream.println ( "\n" + "grand mean error:  "
         + Math.toDegrees ( grandDescriptiveStatistics.getMean ( ) ) );

       printStream.println ( "\n" + "grand deviation:  "
         + Math.toDegrees (
         grandDescriptiveStatistics.getStandardDeviation ( ) ) );
       
       // print the mean activity from each neuron for each direction
       
       printStream.println ( "\n" + "direction preferred average" );
       
       for ( int  i = 0; i < DIRECTIONS; i++ )
       {
         for ( int  j = 0; j < NEURONS; j++ )
         {
           printStream.printf (
             "%1$03.0f %2$03.0f %3$03.0f%n",
             new Double [ ] {
               new Double (
                 Math.toDegrees ( i * 2.0 * Math.PI / DIRECTIONS ) ),
               new Double (
                 Math.toDegrees ( j * 2.0 * Math.PI / NEURONS    ) ),
               new Double (
                 Math.ceil (
                   averagePopulationVectorsDescriptiveStatistics
                     [ i ] [ j ]
                     .getMean ( ) ) ) } );
         }
       }
     }

     /*********************************************************************
     * Generates activation for a neuron without random noise.
     *********************************************************************/
     public static double  computeNoiselessActivation (
       double  preferredDirection,
       double  actualDirection )
     //////////////////////////////////////////////////////////////////////
     {
       double  angleFromPreferred
         = preferredDirection - actualDirection;

       if ( angleFromPreferred < 0.0 )
       {
         angleFromPreferred += 2.0 * Math.PI;
       }

       double  computedActivation;

       if ( ( angleFromPreferred <=     Math.PI / 2 )
         || ( angleFromPreferred >= 3 * Math.PI / 2 ) )
       {
         computedActivation
           = RATE_SPONTANEOUS
           + Math.cos ( angleFromPreferred )
           * ( RATE_MAX - RATE_SPONTANEOUS );
       }
       else
       {
         computedActivation
           = RATE_SPONTANEOUS
           + Math.cos ( angleFromPreferred )
           * ( RATE_SPONTANEOUS - RATE_MIN );
       }

       return computedActivation;
     }

     /*********************************************************************
     * Generates activation for a neuron with random noise.
     *********************************************************************/
     public static double  generateNoisyActivation (
       double  preferredDirection,
       double  actualDirection )
       throws Exception
     //////////////////////////////////////////////////////////////////////
     {
       double  noiselessActivation = computeNoiselessActivation (
         preferredDirection,
         actualDirection );

       double  probability = random.nextDouble ( );

       double  noisyActivation = Math.ceil (
         normInv (
           probability,
           noiselessActivation,
           RATE_DEVIATION ) );

       if ( noisyActivation <= 0.0 )
       {
         noisyActivation = 0.0;
       }           

       return noisyActivation;
     }

     public static double  normInv (
       double  probability,
       double  mean,
       double  standardDeviation )
       throws MathException
     //////////////////////////////////////////////////////////////////////
     {
       NormalDistribution  normalDistribution
         = distributionFactory.createNormalDistribution (
         mean, standardDeviation );

       return
         normalDistribution.inverseCumulativeProbability ( probability );
     }

     /*********************************************************************
     * Predicts the direction for this trial.
     * Knowing only the preferred directions for each neuron and their
     * current activations, predict the direction for this trial.
     * This method is the heart of the algorithm.
     *********************************************************************/
     public static double  predictDirection (
       double [ ]  preferredDirections,
       double [ ]  noisyActivations )
     //////////////////////////////////////////////////////////////////////
     {
       double  sumCosComponents = 0.0;
       
       double  sumSinComponents = 0.0;
       
       for ( int  unit = 0; unit < NEURONS; unit++ )
       {
         // weight the activation of each neuron by their cartesian
         // components along their preferred directions
           
         double  cosComponent
           = Math.cos ( preferredDirections [ unit ] )
           * noisyActivations [ unit ];

         double  sinComponent
           = Math.sin ( preferredDirections [ unit ] )
           * noisyActivations [ unit ];
           
         // sum the weighted contributions from each neuron for this trial
           
         sumCosComponents += cosComponent;

         sumSinComponents += sinComponent;
       }
       
       // Here is the predicted direction.
         
       double  predictedDirection = Math.atan2 (
         sumSinComponents,
         sumCosComponents );
         
       // return a non-negative angle for the answer
         
       if ( predictedDirection < 0.0 )
       {
         predictedDirection += 2.0 * Math.PI;
       }
       
       // Note the arctan adjustment is not necessary since
       // the atan2(y,x) function was used.
         
       return predictedDirection;
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }