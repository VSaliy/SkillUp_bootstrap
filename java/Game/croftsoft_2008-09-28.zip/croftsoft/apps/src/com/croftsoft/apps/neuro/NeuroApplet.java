    package com.croftsoft.apps.neuro;
     
    import javax.swing.JApplet;
     
    import com.croftsoft.core.lang.lifecycle.*;
     
    /***********************************************************************
    * Applet.
    *
    * @version
    *   $Id: NeuroApplet.java,v 1.1 2008/08/17 21:03:24 croft Exp $
    * @since
    *   2008-08-17
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/
     
    public final class  NeuroApplet
      extends JApplet
      implements Lifecycle
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private static final long  serialVersionUID = 0L;
     
    //
     
    // private static final String  EXAMPLE_PARAMETER = "example";
     
    //
       
    private final NeuroMain  neuroMain;
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
       
    public  NeuroApplet ( )
    ////////////////////////////////////////////////////////////////////////
    {
      neuroMain = new NeuroMain ( null );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // overridden applet methods
    ////////////////////////////////////////////////////////////////////////
     
    @Override
    public String  getAppletInfo ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return neuroMain.getNeuroConfig ( ).getInfo ( );
    }
     
    @Override
    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      // final NeuroConfig  neuroConfig
      //   = neuroMain.getNeuroConfig ( );
       
      // neuroConfig.setCodeBase ( getCodeBase ( ) );
       
      neuroMain.setContentPane ( getContentPane ( ) );
       
      // neuroConfig.setExampleParameter (
      //   getParameter ( EXAMPLE_PARAMETER ) );
       
      LifecycleLib.init ( neuroMain );
    }
     
    @Override
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.start ( neuroMain );
    }
     
    @Override
    public void  stop ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.stop ( neuroMain );
    }
     
    @Override
    public void  destroy ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.destroy ( neuroMain );
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }