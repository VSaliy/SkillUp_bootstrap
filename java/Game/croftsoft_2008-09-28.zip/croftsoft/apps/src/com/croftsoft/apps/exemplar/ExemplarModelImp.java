    package com.croftsoft.apps.exemplar;
     
    import com.croftsoft.core.lang.*;
    import com.croftsoft.core.lang.lifecycle.Startable;
    import com.croftsoft.core.lang.lifecycle.Updatable;
    import com.croftsoft.core.math.MathConstants;
    import com.croftsoft.core.util.mail.Mail;

    /***********************************************************************
    * Model.
    * 
    * Maintains program state.
    * 
    * @version
    *   $Id: ExemplarModelImp.java,v 1.5 2008/02/15 22:38:03 croft Exp $
    * @since
    *   2006-01-03
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  ExemplarModelImp
      implements ExemplarModel, Startable, Updatable
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    // private final instance variables
      
    private final Mail<ExemplarMessage>  mail;
       
    // model state instance variables
     
    private long    clickCount;
     
    private double  phase;
     
    private long    lastUpdateTime;
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public  ExemplarModelImp (
      final ExemplarConfig         exemplarConfig,
      final Mail<ExemplarMessage>  mail )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        exemplarConfig,
        this.mail = mail );
       
      // clickCount = exemplarConfig.getClickCountInit ( );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // interface Accessor methods
    ////////////////////////////////////////////////////////////////////////
     
    public long    getClickCount ( ) { return clickCount; }
     
    public double  getPhase      ( ) { return phase;      }
     
    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      lastUpdateTime = System.nanoTime ( );
    }
     
    public void  update ( )
    ////////////////////////////////////////////////////////////////////////
    {
      final int  size = mail.size ( );
      
      for ( int  i = 0; i < size; i++ )
      {      
        final ExemplarMessage  exemplarMessage = mail.get ( i );
       
        final ExemplarMessage.Type  type = exemplarMessage.getType ( );
         
        switch ( type )
        {
          case INCREMENT_CLICK_COUNT:
             
            clickCount++;
             
            mail.offer ( ExemplarMessage.CLICK_COUNT_CHANGED_INSTANCE );
             
            break;
             
          default:
            
            // ignore
        }
      }
       
      final long  currentTime = System.nanoTime ( );
       
      final long  deltaTimeNanos = currentTime - lastUpdateTime;
       
      lastUpdateTime = currentTime;
      
      phase
        += MathConstants.TWO_PI
        * 0.1 // frequency
        * deltaTimeNanos * MathConstants.SECONDS_PER_NANOSECOND;
       
      if ( phase >= MathConstants.TWO_PI )
      {
        phase -= MathConstants.TWO_PI;
      }
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }