     package com.croftsoft.apps.road;
     
     import java.applet.*;
     import java.awt.*;
     import java.awt.event.*;
     import java.awt.geom.*;
     import java.io.*;
     import java.net.URL;
     import java.util.*;
     import javax.swing.*;
     import javax.swing.event.*;

     import com.croftsoft.core.animation.clock.Timekeeper;
     import com.croftsoft.core.animation.sprite.IconSprite;

     import com.croftsoft.apps.road.model.Car;

     /*********************************************************************
     * Roadrunner enemy Sprite.
     *
     * @version
     *   2003-11-09
     * @since
     *   2003-09-10
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  EnemySprite
       extends IconSprite
       implements Constants
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     private final Car         car;

     private final Timekeeper  timekeeper;

     private final Random      random;

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public  EnemySprite (
       Icon        enemyIcon,
       Car         car,
       Timekeeper  timekeeper,
       Random      random )
     //////////////////////////////////////////////////////////////////////
     {
       super ( enemyIcon );

       this.car = car;

       this.timekeeper = timekeeper;

       this.random = random;
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public void  update ( JComponent  component )
     //////////////////////////////////////////////////////////////////////
     {
       car.setDestinationPoint (
         new Point (
           random.nextInt ( component.getBounds ( ).width  ),
           random.nextInt ( component.getBounds ( ).height ) ) );

       double  timeDelta = timekeeper.getTimeDelta ( );

       car.update ( timeDelta );

       x = car.getCenterX ( );

       y = car.getCenterY ( );
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }