    package com.croftsoft.apps.exemplar;
     
    import java.awt.*;
     
    /***********************************************************************
    * Exemplar configuration.
    *  
    * Can be modified to be persistent.
    * 
    * @version
    *   $Id: ExemplarConfig.java,v 1.5 2008/02/18 23:22:49 croft Exp $
    * @since
    *   2008-02-18
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public interface  ExemplarConfig
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
     
    public Color      getBackgroundColor ( );
     
    public Cursor     getCursor ( );
     
    public String     getExampleParameter ( );
     
    public Color      getForegroundColor ( );
     
    public String     getInfo ( );
     
    public Font       getFont ( );
     
    public Dimension  getFrameSize ( );
     
    public String     getFrameTitle ( );

    public String     getShutdownConfirmationPrompt ( );
     
    public String     getThreadName ( );
     
    public double     getUpdateRate ( );
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public void  setExampleParameter ( final String  exampleParameter );
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }