    package com.croftsoft.apps.skipper;

    import java.awt.*;
    import java.awt.event.*;
    import java.io.*;
    import java.util.*;
    import java.util.logging.*;
    import javax.imageio.*;
    import javax.swing.*;

    import com.croftsoft.core.animation.ComponentAnimator;
    import com.croftsoft.core.awt.image.ImageLib;
    import com.croftsoft.core.lang.NullArgumentException;
    import com.croftsoft.core.math.MathConstants;

    /***********************************************************************
    * Skipper ComponentAnimator.
    *
    * Copyright 2007 David Wallace Croft.
    * 
    * @version
    *   $Date: 2007/07/28 16:57:03 $ $Author: croft $
    * @since
    *   2006-12-19
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  SkipperAnimator
      implements ComponentAnimator
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private static final String  CLASS_NAME
      = SkipperAnimator.class.getName ( );

    //

    private final Logger         logger;

    private final SkipperConfig  skipperConfig;

    private final SkipperModel   skipperModel;

    private final Rectangle      componentBounds;

    private final Random         random;

    //

    private boolean  skip;

    private long     lastTimeNanos;

    private Image    image;

    private String   imageFilename;

    private int      imageIndex;

    ////////////////////////////////////////////////////////////////////////
    // constructor methods
    ////////////////////////////////////////////////////////////////////////

    /***********************************************************************
    * Main constructor.
    ***********************************************************************/
    public  SkipperAnimator (
      final SkipperConfig  skipperConfig,
      final SkipperModel   skipperModel,
      final JComponent     jComponent )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        this.skipperConfig = skipperConfig,
        this.skipperModel  = skipperModel,
        jComponent );

      logger = Logger.getLogger ( CLASS_NAME );

      componentBounds = new Rectangle ( );

      random = new Random ( );

      jComponent.setOpaque ( true );

      jComponent.setFont ( skipperConfig.getFont ( ) );

      jComponent.addKeyListener (
        new KeyAdapter ( )
        {
          @Override
          public void  keyPressed ( final KeyEvent  keyEvent )
          {
            final int  keyCode = keyEvent.getKeyCode ( );

            if ( keyCode == KeyEvent.VK_SPACE )
            {
              logger.info ( "Spacebar pressed.  Skipping..." );

              skip = true;
            }
          }
        } );

      jComponent.requestFocus ( );

      update ( jComponent );       
    }

    ////////////////////////////////////////////////////////////////////////
    // interface ComponentAnimator methods
    ////////////////////////////////////////////////////////////////////////

    public void  paint (
      final JComponent  jComponent,
      final Graphics2D  graphics2D )
    ////////////////////////////////////////////////////////////////////////
    {
      try
      {
        jComponent.getBounds ( componentBounds );

        graphics2D.setColor ( skipperConfig.getBackgroundColor ( ) );

        graphics2D.fill ( componentBounds );

        if ( image != null )
        {
          final Rectangle  rectangle = ImageLib.shrinkToFitAndCenter (
            image.getWidth  ( null ),
            image.getHeight ( null ),
            componentBounds.width,
            componentBounds.height );

          graphics2D.drawImage (
            image,
            rectangle.x,
            rectangle.y,
            rectangle.width,
            rectangle.height,
            null );
        }

        if ( imageFilename != null )
        {
          Boolean  displayingImageFilename
            = skipperConfig.getDisplayingImageFilename ( );
          
          if ( displayingImageFilename == null )
          {
            displayingImageFilename
              = skipperConfig.getDefaultDisplayingImageFilename ( );
            
            skipperConfig.setDisplayingImageFilename (
              displayingImageFilename );
          }
          
          if ( displayingImageFilename.booleanValue ( ) )
          {
            graphics2D.setColor ( skipperConfig.getForegroundColor ( ) );

            graphics2D.drawString ( imageFilename, 20, 20 );
          }
        }
      }
      catch ( final Exception  ex )
      {
        ex.printStackTrace ( );

        logger.throwing ( CLASS_NAME, "paint", ex );
      }
    }

    public void  update ( final JComponent  jComponent )
    ////////////////////////////////////////////////////////////////////////
    {
      try
      {
        final long  currentTimeNanos = System.nanoTime ( );

        final long  deltaTimeNanos = currentTimeNanos - lastTimeNanos;

        long  displayTime = skipperConfig.getDisplayTime ( );

        if ( displayTime <= 0 )
        {
          displayTime = skipperConfig.getDefaultDisplayTime ( );

          skipperConfig.setDisplayTime ( displayTime );
        }

        final long  displayTimeNanos
          = displayTime * MathConstants.NANOSECONDS_PER_SECOND;
        
        final boolean  done = deltaTimeNanos >= displayTimeNanos; 

        if ( done || skip )
        {
          if ( skip )
          {
            skip = false;
            
            skipperModel.decreaseProbabilityOfSkipped ( imageIndex );

            skipperModel.divideEachProbabilityBySum ( );
          }

          imageFilename = randomlyChooseSelection ( );

          if ( imageFilename != null )
          {
            final File  imageFile = new File ( imageFilename );

            image = ImageIO.read ( imageFile );

            lastTimeNanos = currentTimeNanos;             
          }
        }

        jComponent.paintImmediately ( componentBounds );
      }
      catch ( final Exception  ex )
      {
        ex.printStackTrace ( );

        logger.throwing ( CLASS_NAME, "update", ex );
      }
      catch ( final OutOfMemoryError  error )
      {
        System.err.println ( "Out of memory loading " + imageFilename );

        logger.throwing ( CLASS_NAME, "update", error );
      }
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    private String  randomlyChooseSelection ( )
    ////////////////////////////////////////////////////////////////////////
    {
      final String [ ]  selections = skipperModel.getSelections ( );

      if ( ( selections == null    )
        || ( selections.length < 1 ) )
      {
        return null;
      }

      final double [ ]  thresholds
        = skipperModel.getCumulativeProbabilityThresholds ( );

      if ( ( thresholds == null    )
        || ( thresholds.length < 1 ) )
      {
        return selections [ 0 ];
      }

      final double  roll = random.nextDouble ( );

      imageIndex = 0;

      for ( int  i = 0; i < thresholds.length; i++ )
      {
        if ( roll < thresholds [ i ] )
        {
          break;
        }

        imageIndex = i;
      }

      logger.info ( "index = " + imageIndex + ", roll = " + roll );

      return selections [ imageIndex ];
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }