     package com.croftsoft.apps.cyborg;
     
     import java.util.*;
     import javax.swing.event.*;
     
     import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;
     
     import com.croftsoft.core.math.MathConstants;
     import com.croftsoft.core.math.MathLib;
     import com.croftsoft.core.util.loop.*;
     
     /*********************************************************************
     * Maintains state.
     * 
     * @version
     *   $Id: CyborgModelImpl.java,v 1.34 2008/04/19 21:30:58 croft Exp $
     * @since
     *   2005-03-16
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  CyborgModelImpl
       implements CyborgModel
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private final Random  random;
     
     private final Set<ChangeListener>  changeListenerSet;
     
     private final DescriptiveStatistics  descriptiveStatistics;
     
     private final NanoTimeLoopGovernor  nanoTimeLoopGovernor;
       
     //
       
     private double
       aimX,
       aimY,
       alpha,
       max = CyborgConfig.DEFAULT_MAX,
       offset,
       x,
       y,
       targetCenterX,
       targetCenterY,
       targetRadius;
     
     private String  transform;
     
     //
       
     private boolean [ ] [ ]  spikeRasters;
     
     private long
       currentTime,
       lastOffTargetTime,
       lastUpdateTime,
       startTime;
     
     private boolean  paused;
     
     private boolean
       animate,
       forceLength,
       realTime;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  CyborgModelImpl ( )
     //////////////////////////////////////////////////////////////////////
     {
       spikeRasters = new boolean [ 4 ] [ 200 ];
       
       random = new Random ( );
       
       targetRadius = 0.1;
       
       transform = CyborgConfig.JOYSTICK_TRANSFORM_OPTION_LINEAR;
       
       changeListenerSet = new HashSet<ChangeListener> ( );
       
       descriptiveStatistics = DescriptiveStatistics.newInstance ( );
       
       nanoTimeLoopGovernor = new NanoTimeLoopGovernor ( );
       
       setRealTime ( true );
       
       animate = true;
       
       forceLength = true;
       
       reset ( );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  reset ( )
     //////////////////////////////////////////////////////////////////////
     {
       descriptiveStatistics.clear ( );
       
       x = y = aimX = aimY = 0;
       
       targetCenterX = 2.0 * random.nextDouble ( ) - 1.0;

       targetCenterY = 2.0 * random.nextDouble ( ) - 1.0;
       
       startTime = currentTime; // System.nanoTime ( );
       
       lastOffTargetTime = startTime;
     }
     
     //////////////////////////////////////////////////////////////////////
     // accessor methods
     //////////////////////////////////////////////////////////////////////
     
     public double  getAimX ( ) { return aimX; }

     public double  getAimY ( ) { return aimY; }
     
     public double  getAlpha ( ) { return alpha; }
     
     public boolean  getAnimate ( ) { return animate; }
     
     public boolean  getForceLength ( ) { return forceLength; }
     
     public LoopGovernor  getLoopGovernor ( )
       { return nanoTimeLoopGovernor; }     
     
     public double  getMax  ( ) { return max;  }
     
     public double  getOffset ( ) { return offset; }
     
     public boolean  getRealTime ( ) { return realTime; }
     
     public boolean [ ] [ ]  getSpikeRasters ( ) { return spikeRasters; }
     
     public double  getX ( ) { return x; }
     
     public double  getY ( ) { return y; }
     
     public double  getTargetCenterX ( ) { return targetCenterX; }
     
     public double  getTargetCenterY ( ) { return targetCenterY; }
     
     public double  getTargetRadius  ( ) { return targetRadius;  }
     
     public String  getTransform ( ) { return transform; }
     
     //////////////////////////////////////////////////////////////////////
     // mutator methods
     //////////////////////////////////////////////////////////////////////
     
     public void  setAimX ( double  aimX ) { this.aimX = aimX; }
     
     public void  setAimY ( double  aimY ) { this.aimY = aimY; }
     
     public void  setAlpha ( double  alpha )
     //////////////////////////////////////////////////////////////////////
     {
       final double  gain = 1 / ( 1 - alpha );
       
       CyborgConfig.INSTANCE.getLog ( ).record (
         String.format (
           "alpha = %1$1.2f (gain = %2$1.3f)",
           new Double ( alpha ),
           new Double ( gain  ) ) );
       
       this.alpha = alpha;
       
       reset ( );
       
       broadcast ( );
     }
     
     public void  setAnimate ( boolean  animate )
     //////////////////////////////////////////////////////////////////////
     {
       this.animate = animate;
       
       CyborgConfig.INSTANCE.getLog ( ).record ( "Animate:  " + animate );
       
       broadcast ( );
     }
     
     public void  setForceLength ( boolean  forceLength )
     //////////////////////////////////////////////////////////////////////
     {
       this.forceLength = forceLength;
       
       CyborgConfig.INSTANCE.getLog ( ).record (
         "Force-length:  " + forceLength );
       
       broadcast ( );
     }
     
     public void  setMax  ( double  max  ) { this.max  = max;  }
     
     public void  setOffset ( double  offset )
     //////////////////////////////////////////////////////////////////////
     {
       this.offset = offset;
       
       CyborgConfig.INSTANCE.getLog ( ).record ( "offset = " + offset );
       
       broadcast ( );       
     }
     
     public void  setRealTime ( boolean  realTime )
     //////////////////////////////////////////////////////////////////////
     {
       this.realTime = realTime;
       
       CyborgConfig.INSTANCE.getLog ( ).record (
         "Real-time:  " + realTime );
       
       if ( realTime )
       {
         nanoTimeLoopGovernor.setFrequency ( CyborgConfig.FRAME_RATE );
       }
       else
       {
         nanoTimeLoopGovernor.setPeriodNanos ( 0L );
       }
       
       broadcast ( );
     }
     
     public void  setTransform ( String  transform )
     //////////////////////////////////////////////////////////////////////
     {
       this.transform = transform;
         
       CyborgConfig.INSTANCE.getLog ( ).record (
         "Transform:  " + transform );
       
       reset ( );
       
       broadcast ( );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     /*********************************************************************
     * Transforms from [-1 to +1] to [0 to +1].  
     *********************************************************************/
     public double  transform ( double  control )
     //////////////////////////////////////////////////////////////////////
     {
       control -= offset;
       
       double  value;
       
       final double  gain = 1.0 / ( 1.0 - alpha );
       
       // transforms from [-1 to +1] to [0 to +1]
       final double  transformed = ( control + 1.0 ) / 2.0;
       
       if ( transform.equals (
         CyborgConfig.JOYSTICK_TRANSFORM_OPTION_CUMULATIVE ) )
       {
         value = MathLib.cumulative ( transformed, gain )
           / MathLib.cumulative ( 1, gain ); 
       }
       else if ( transform.equals (
         CyborgConfig.JOYSTICK_TRANSFORM_OPTION_EXPONENTIAL ) )
       {
         value = ( Math.exp ( gain * transformed ) - 1 )
           / ( Math.exp ( gain ) - 1 );
       }
       else if ( transform.equals (
         CyborgConfig.JOYSTICK_TRANSFORM_OPTION_LINEAR ) )
       {
         value = ( gain * control + 1 ) / 2;         
       }
       else if ( transform.equals (
         CyborgConfig.JOYSTICK_TRANSFORM_OPTION_LOGARITHMIC ) )
       {
         value = Math.log ( gain * ( ( control + 1 ) / 2 + 1 ) )
           / Math.log ( gain * 2.0 );
       }
       else if ( transform.equals (
         CyborgConfig.JOYSTICK_TRANSFORM_OPTION_SIGMOIDAL ) )
       {
         final double  min = MathLib.sigmoid ( gain * -1 );
         
         final double  max = MathLib.sigmoid ( gain *  1 );
         
         value = ( MathLib.sigmoid ( gain * control ) - min )
           / ( max - min );
       }
       else
       {       
         throw new IllegalStateException (
           "unknown transform:  " + transform );
       }
       
       if ( value > 1.0 )
       {
         value = 1.0;
       }
       else if ( value < 0.0 )
       {
         value = 0.0;
       }
       
       return value;
     }
     
     public void  addChangeListener ( ChangeListener  changeListener )
     //////////////////////////////////////////////////////////////////////
     {
       changeListenerSet.add ( changeListener );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  setPaused ( boolean  paused )
     //////////////////////////////////////////////////////////////////////
     {
       this.paused = paused;
     }
     
     public void  update ( )
     //////////////////////////////////////////////////////////////////////
     {
       if ( paused )
       {
         return;
       }
       
       //long  currentTime = System.nanoTime ( );
       
       currentTime += ( MathConstants.NANOSECONDS_PER_SECOND / 200 );
       
/*       
       double  deltaTime = ( currentTime - lastUpdateTime )
         * MathConstants.SECONDS_PER_NANOSECOND;
       
       lastUpdateTime = currentTime;
*/
       double  deltaTime = 1 / 200.0;
       
       double  probability = max * deltaTime;
       
       for ( int  i = 0; i < spikeRasters.length; i++ )
       {
         boolean [ ]  spikeRaster = spikeRasters [ i ];
         
         for ( int  j = spikeRaster.length - 1; j > 0; j-- )
         {
           spikeRaster [ j ] = spikeRaster [ j - 1 ]; 
         }
         
         double  r = random.nextDouble ( );
         
         switch ( i )
         {
           case 0:
             
             spikeRaster [ 0 ]
               = r <= probability * transform ( -aimY );
             
             if ( spikeRaster [ 0 ] )
             {
               y -= (
                 ( forceLength ? ( ( 1.0 + y ) ) : 1 )
                 * deltaTime * CyborgConfig.DELTA );
               
               if ( y < -1.0 )
               {
                 y = -1.0;
               }
             }
             
             break;
             
           case 1:
             
             spikeRaster [ 0 ]
               = r <= probability * transform ( aimY );
             
             if ( spikeRaster [ 0 ] )
             {
               y += (
                 ( forceLength ? ( ( 1.0 - y ) ) : 1 )
                 * deltaTime * CyborgConfig.DELTA );
               
               if ( y > 1.0 )
               {
                 y = 1.0;
               }
             }
             
             break;
             
           case 2:
             
             spikeRaster [ 0 ]
               = r <= probability * transform ( -aimX );
             
             if ( spikeRaster [ 0 ] )
             {
               x -= (
                 ( forceLength ? ( ( 1.0 + x ) ) : 1 )
                 * deltaTime * CyborgConfig.DELTA );
               
               if ( x < -1.0 )
               {
                 x = -1.0;
               }
             }
             
             break;
             
           case 3:
             
             spikeRaster [ 0 ]
               = r <= probability * transform ( aimX );
             
             if ( spikeRaster [ 0 ] )
             {
               x += (
                 ( forceLength ? ( ( 1.0 - x ) ) : 1 )
                 * deltaTime * CyborgConfig.DELTA );
               
               if ( x > 1.0 )
               {
                 x = 1.0;
               }
             }
             
             break;
         }
       }
       
       double  distance = Math.sqrt (
           Math.pow ( x - targetCenterX, 2.0 )
         + Math.pow ( y - targetCenterY, 2.0 ) );
       
       if ( distance < targetRadius )
       {
         long  onTargetTime = currentTime - lastOffTargetTime;
         
         if ( onTargetTime >= 3 * MathConstants.NANOSECONDS_PER_SECOND )
         {
           lastOffTargetTime = currentTime;
           
           double  acquisitionTime = ( currentTime - startTime )
             * MathConstants.SECONDS_PER_NANOSECOND;
           
           descriptiveStatistics.addValue ( acquisitionTime );
           
           long  realCurrentTime = System.nanoTime ( );
           
           long  sampleSize = descriptiveStatistics.getN ( );
           
           boolean  doAnimation
             = animate
             | realCurrentTime >= lastUpdateTime
               + 10 * MathConstants.NANOSECONDS_PER_SECOND
             | ( sampleSize % ( int ) Math.pow ( 10.0,
               ( int ) Math.log10 ( sampleSize ) ) ) == 0;
           
           if ( doAnimation )
           {
             double  variance = descriptiveStatistics.getVariance ( );
             
             double  standardError = Math.sqrt ( variance / sampleSize );
             
             CyborgConfig.INSTANCE.getLog ( ).record (
               String.format (
                 "X=%1$1.3f N=%2$d M=%3$1.3f SD=%4$1.3f SE=%5$1.3f",
                 new Double ( acquisitionTime ),
                 new Long   ( sampleSize ),
                 new Double ( descriptiveStatistics.getMean ( ) ),
                 new Double (
                   descriptiveStatistics.getStandardDeviation ( ) ),
                 new Double ( standardError ) ) );
             
             lastUpdateTime = realCurrentTime;
           }
           
           targetCenterX = 2.0 * random.nextDouble ( ) - 1.0;
 
           targetCenterY = 2.0 * random.nextDouble ( ) - 1.0;
           
           startTime = currentTime;          
         }
       }
       else
       {
         lastOffTargetTime = currentTime;
       }
     }
     
     private void  broadcast ( )
     //////////////////////////////////////////////////////////////////////
     {
       for ( ChangeListener  changeListener : changeListenerSet )
       {
         changeListener.stateChanged ( new ChangeEvent ( this ) );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }