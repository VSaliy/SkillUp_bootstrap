    package com.croftsoft.apps.neuro;

    import java.awt.*;
    import java.awt.event.ComponentAdapter;
    import java.awt.event.ComponentEvent;
    import javax.swing.JComponent;

    import com.croftsoft.core.animation.ComponentAnimator;
    import com.croftsoft.core.animation.animator.FrameRateAnimator;
    import com.croftsoft.core.lang.NullArgumentException;
    import com.croftsoft.core.util.mail.Mail;

    /***********************************************************************
    * ComponentAnimator.
    *
    * @version
    *   $Id: NeuroAnimator.java,v 1.13 2008/08/30 02:36:51 croft Exp $
    * @since
    *   2008-08-17
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  NeuroAnimator
      implements ComponentAnimator
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
    	 
    private final NeuroConfig         neuroConfig;
    
    private final Mail<NeuroMessage>  mail;
       
    private final NeuroModel          neuroModel;
     
    private final Rectangle           componentBounds;
     
    private final FrameRateAnimator   frameRateAnimator;
     
    ////////////////////////////////////////////////////////////////////////
    // constructor methods
    ////////////////////////////////////////////////////////////////////////

    /***********************************************************************
    * Main constructor.
    ***********************************************************************/
    public  NeuroAnimator (
      final NeuroConfig         neuroConfig,
      final Mail<NeuroMessage>  mail,
      final NeuroModel          neuroModel,
      final JComponent          jComponent )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        this.neuroConfig = neuroConfig,
        this.mail        = mail,
        this.neuroModel  = neuroModel,
        jComponent );
       
      componentBounds = new Rectangle ( );
       
      jComponent.setOpaque ( true );
       
      jComponent.setFont ( neuroConfig.getFont ( ) );
         
      jComponent.setCursor ( neuroConfig.getCursor ( ) );
       
      jComponent.requestFocus ( );
       
      jComponent.addComponentListener (
        new ComponentAdapter ( )
        {
          @Override
          public void  componentResized ( ComponentEvent  componentEvent )
          {
            update ( jComponent );
    	             
            jComponent.repaint ( );
          }
        } );
       
      frameRateAnimator = new FrameRateAnimator ( jComponent );
      
      frameRateAnimator.toggle ( );
       
      update ( jComponent );       
    }
     
    ////////////////////////////////////////////////////////////////////////
    // interface ComponentAnimator methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  paint (
      final JComponent  jComponent,
      final Graphics2D  graphics2D )
    ////////////////////////////////////////////////////////////////////////
    {
      graphics2D.setColor ( neuroConfig.getBackgroundColor ( ) );
       
      graphics2D.fill ( componentBounds );
       
      graphics2D.setColor ( neuroConfig.getForegroundColor ( ) );
       
      final int  length = neuroModel.getMembraneVoltageLength ( );
      
      final int  xMargin = 10;
      
      final int  yMargin = 20;
      
      final int  xOffset = xMargin;
      
      final int  yOffset = componentBounds.height / 2;
      
      graphics2D.drawLine (
        xMargin, yOffset, componentBounds.width - xMargin, yOffset );
      
      final double  xScale
        = ( componentBounds.width - 2 * xMargin ) / ( double ) length;
      
      final double  yScale
        = -( ( componentBounds.height - 2 * yMargin ) / 2 )
        / neuroModel.getMembraneVoltageMax ( );
      
//      final double  timeInterval = neuroModel.getTimeInterval ( );
//      
//      final double  timeMin = neuroModel.getTimeMin ( );
      
      for ( int  i = 0; i < length; i += 100 )
      {
        final int  x = xMargin + ( int ) Math.round ( xScale * i );
          
        graphics2D.drawLine ( x, yOffset - 10, x, yOffset + 10 );
      }
      
      for ( int  i = 0; i < length; i++ )
      {
        final int  x = ( int ) Math.round ( i * xScale ) + xOffset;
        
        final double  membraneVoltage = neuroModel.getMembraneVoltage ( i );
        
        final int  y
          = ( int ) Math.round ( membraneVoltage * yScale ) + yOffset;
        
        graphics2D.drawOval ( x - 5, y - 5, 10, 10 );
        
        if ( i < length - 1 )
        {
          final double  nextMembraneVoltage
            = neuroModel.getMembraneVoltage ( i + 1 );
          
          final int  nextX
            = ( int ) Math.round ( ( i + 1 ) * xScale ) + xOffset;
          
          final int  nextY
            = ( int ) Math.round ( nextMembraneVoltage * yScale ) + yOffset;
          
          graphics2D.drawLine ( x, y, nextX, nextY );
        }
      }
      
      if ( neuroModel.getSpikeCount ( ) > 0 )
      {
        Toolkit.getDefaultToolkit ( ).beep ( );
      }
      
//      final HhNeuron  hhNeuron = neuroModel.getHhNeuron ( );
//      
//      System.out.format (
//        "v = %1$,1.3f, h = %2$,1.3f, m = %3$,1.3f, n = %4$,1.3f\n",
//        new Double ( hhNeuron.getMembraneVoltage ( ) ),
//        new Double ( hhNeuron.getH ( ) ),
//        new Double ( hhNeuron.getM ( ) ),
//        new Double ( hhNeuron.getN ( ) ) );
       
      frameRateAnimator.paint ( jComponent, graphics2D );
    }
     
    public void  update ( final JComponent  jComponent )
    ////////////////////////////////////////////////////////////////////////
    {
      final int  size = mail.size ( );
      
      for ( int  i = 0; i < size; i++ )
      {      
        final NeuroMessage  neuroMessage = mail.get ( i );
       
        final NeuroMessage.Type  type = neuroMessage.getType ( );
         
        switch ( type )
        {
          case TOGGLE_FRAME_RATE_REQUEST:
            
            frameRateAnimator.toggle ( );
            
            break;
            
          default:
            
            // ignore
        }
      }
      
      jComponent.getBounds ( componentBounds );
         
      frameRateAnimator.update ( jComponent );
      
      jComponent.paintImmediately ( componentBounds );
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }
