     package com.croftsoft.apps.infant;
     
     import java.util.*;
     
     /*********************************************************************
     * Data recorded for analysis.
     * 
     * @version
     *   $Id: InfantData.java,v 1.4 2007/12/01 00:51:07 croft Exp $
     * @since
     *   2006-03-05
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  InfantData
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final class  Record
     {
       long
         cycle,
         stimulus;
       
       double
         contemplation,
         duration;
       
       public  Record (
         final long    cycle,
         final long    stimulus,
         final double  duration,
         final double  contemplation )
       {
         this.cycle         = cycle;
         
         this.stimulus      = stimulus;
         
         this.duration      = duration;
         
         this.contemplation = contemplation;
       }
     }
       
     private final List<Record>  recordList;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  InfantData ( )
     //////////////////////////////////////////////////////////////////////
     {
       recordList = new ArrayList<Record> ( );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  record (
       final long    cycle,
       final long    stimulus,
       final double  duration,
       final double  contemplation )
     //////////////////////////////////////////////////////////////////////
     {
       recordList.add (
         new Record ( cycle, stimulus, duration, contemplation ) );           
     }
     
     public String  report ( )
     //////////////////////////////////////////////////////////////////////
     {
       final StringBuffer  stringBuffer = new StringBuffer ( );
       
       for ( final Record  record : recordList )
       {
         stringBuffer.append (
           String.format ( "%1$d %2$d %3$1.3f %4$1.3f%n",
             new Long   ( record.cycle         ),
             new Long   ( record.stimulus      ),
             new Double ( record.duration      ),
             new Double ( record.contemplation ) ) );
       }
       
       return stringBuffer.toString ( );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }