     package com.croftsoft.apps.mars.net.request;

     import java.io.Serializable;

     /*********************************************************************
     * Network request object.
     *
     * @version
     *   2003-05-13
     * @since
     *   2003-04-06
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public interface  Request
       extends Serializable
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     public String  getPlayerName ( );

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }