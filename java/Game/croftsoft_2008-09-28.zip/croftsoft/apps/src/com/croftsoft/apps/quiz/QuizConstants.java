     package com.croftsoft.apps.quiz;

     /*********************************************************************
     * @version
     *   2001-07-10
     * @since
     *   2001-07-10
     * @author
     *   <a href="http://croftsoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public interface  QuizConstants
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     public static final String  DEFAULT_QUIZ_FILENAME   = "quiz.xml";

     public static final String  DEFAULT_BACKUP_FILENAME = "quiz.bak";

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }
