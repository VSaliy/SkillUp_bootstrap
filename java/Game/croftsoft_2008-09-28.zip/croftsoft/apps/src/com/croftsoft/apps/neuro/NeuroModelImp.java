    package com.croftsoft.apps.neuro;
    
    import java.util.*;

    import com.croftsoft.core.ai.neuro.Channel;
    import com.croftsoft.core.ai.neuro.ChannelMut;
    import com.croftsoft.core.ai.neuro.HhNeuron;
    import com.croftsoft.core.ai.neuro.imp.ChannelMutImp;
    import com.croftsoft.core.ai.neuro.imp.HhNeuronImp;
    import com.croftsoft.core.lang.*;
    import com.croftsoft.core.lang.lifecycle.Startable;
    import com.croftsoft.core.lang.lifecycle.Updatable;
    import com.croftsoft.core.math.MathConstants;
    import com.croftsoft.core.sim.DeltaClock;
    import com.croftsoft.core.sim.DeltaClockImp;
    import com.croftsoft.core.sim.SimLib;
    import com.croftsoft.core.util.mail.Mail;
    import com.croftsoft.core.util.seq.ListSeq;
    import com.croftsoft.core.util.seq.Seq;

    /***********************************************************************
    * Model.
    * 
    * Maintains program state.
    * 
    * @version
    *   $Id: NeuroModelImp.java,v 1.18 2008/08/30 01:37:30 croft Exp $
    * @since
    *   2008-08-17
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  NeuroModelImp
      implements NeuroModel, Startable, Updatable
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
      
    private static final long
      TIME_INTERVAL_NANOS = 100 * MathConstants.NANOSECONDS_PER_MICROSECOND,
      UPDATES_PER_UPDATE  = 10,
      DELTA_TIME_NANOS    = TIME_INTERVAL_NANOS / UPDATES_PER_UPDATE;
       
    private static final double
      DELTA_TIME
        = MathConstants.SECONDS_PER_NANOSECOND * DELTA_TIME_NANOS,
      TIME_INTERVAL
        = MathConstants.SECONDS_PER_NANOSECOND * TIME_INTERVAL_NANOS;
    
    private static final double
      CHANNEL_CONDUCTANCE = 2.11e-10;
    
    // private final instance variables
      
    private final Mail<NeuroMessage>  mail;
    
    private final ChannelMut          channelMut;
    
    private final DeltaClock          deltaClock;
       
    private final HhNeuronImp         hhNeuronImp;
     
    // model state instance variables
     
    private double [ ]  membraneVoltageTimeSeries;
     
    private double  timeMin;
    
    private int
      membraneVoltageLength,
      offset;
    
    private long  timeStep;
     
    private boolean  simulationRunning = true;
    
    /** Number of spikes since the previous update. */
    private int  spikeCount;
    
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public  NeuroModelImp (
      final NeuroConfig         neuroConfig,
      final Mail<NeuroMessage>  mail )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        neuroConfig,
        this.mail = mail );
      
      final List<Channel>  channelList = new ArrayList<Channel> ( );
      
      channelMut = new ChannelMutImp (
        CHANNEL_CONDUCTANCE, HhNeuronImp.SODIUM_REVERSAL_POTENTIAL, false );
      
      channelList.add ( channelMut );
      
      final Seq<Channel>  channelSeq = new ListSeq<Channel> ( channelList );
      
      System.out.println ( "DELTA_TIME = " + DELTA_TIME );      
      
      System.out.println ( "TIME_INTERVAL = " + TIME_INTERVAL );
      
      deltaClock = new DeltaClockImp ( DELTA_TIME );
      
      hhNeuronImp = new HhNeuronImp ( channelSeq, deltaClock );
      
      membraneVoltageLength = 1000;
      
      membraneVoltageTimeSeries = new double [ membraneVoltageLength ];
      
      final double  membraneVoltage = hhNeuronImp.getMembraneVoltage ( );
      
      for ( int  i = 0; i < membraneVoltageLength; i++ )
      {
        membraneVoltageTimeSeries [ i ] = membraneVoltage;  
      }
    }
     
    ////////////////////////////////////////////////////////////////////////
    // interface Accessor methods
    ////////////////////////////////////////////////////////////////////////
    
    public HhNeuron  getHhNeuron ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return hhNeuronImp;
    }
     
    public double  getMembraneVoltage ( final int  index )
    ////////////////////////////////////////////////////////////////////////
    {
      return membraneVoltageTimeSeries [
        ( offset + index ) % membraneVoltageLength ];
    }
     
    public int  getMembraneVoltageLength ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return membraneVoltageLength;
    }
    
    public double  getMembraneVoltageMax ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return 0.100;
    }
    
    public int  getSpikeCount ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return spikeCount;
    }
    
    public double  getTimeInterval ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return TIME_INTERVAL;
    }
    
    public double  getTimeMin ( ) { return timeMin; }
    
    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      // empty
    }
     
    public void  update ( )
    ////////////////////////////////////////////////////////////////////////
    {
      final int  size = mail.size ( );
      
      for ( int  i = 0; i < size; i++ )
      {      
        final NeuroMessage  neuroMessage = mail.get ( i );
       
        final NeuroMessage.Type  type = neuroMessage.getType ( );
         
        switch ( type )
        {
          case TOGGLE_CHANNEL_REQUEST:
            
            channelMut.setOpen ( !channelMut.isOpen ( ) );
            
            break;
            
          case TOGGLE_PAUSE_REQUEST:
            
            simulationRunning = !simulationRunning;
            
            break;
            
          default:
            
            // ignore
        }
      }
      
      if ( simulationRunning )
      {
        spikeCount = 0;

        for ( int  i = 0; i < UPDATES_PER_UPDATE; i++ )
        {      
          SimLib.update ( hhNeuronImp );

          if ( hhNeuronImp.isSpiking ( ) )
          {
            spikeCount++;
          }
        }
       
        final double  membraneVoltage = hhNeuronImp.getMembraneVoltage ( );
        
        membraneVoltageTimeSeries [ offset ] = membraneVoltage;
        
        offset = ( offset + 1 ) % membraneVoltageLength;
        
        timeStep++;
        
        timeMin = ( timeStep - membraneVoltageLength ) * TIME_INTERVAL;
      }
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }