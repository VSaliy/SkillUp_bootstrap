    package com.croftsoft.apps.ajgp.data;
    
    import java.util.*;
    import javax.xml.bind.annotation.*;

    import com.croftsoft.core.lang.NullArgumentException;

    /*********************************************************************
    * Bean implementation of interface of EnumData.
    *
    * @version
    *   $Id: EnumDataBean.java,v 1.2 2007/06/29 03:19:27 croft Exp $
    * @since
    *   2007-06-28
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    *********************************************************************/

    @XmlRootElement
    public final class  EnumDataBean
      implements EnumData
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
      
    private Map<EnumInteger, Integer>  integerMap;
    
    private Map<EnumString,  String>   stringMap;
      
    ////////////////////////////////////////////////////////////////////////
    // constructor methods
    ////////////////////////////////////////////////////////////////////////
      
    public  EnumDataBean ( )
    ////////////////////////////////////////////////////////////////////////
    {
      // a no-argument constructor for JAXB conversion
    }
      
    ////////////////////////////////////////////////////////////////////////
    // interface EnumData accessor methods
    ////////////////////////////////////////////////////////////////////////

    public Integer  get ( final EnumInteger  enumInteger )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.check ( enumInteger );
      
      return integerMap == null ? null : integerMap.get ( enumInteger );
    }
    
    public String  get ( final EnumString  enumString )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.check ( enumString );
      
      return stringMap == null ? null : stringMap.get ( enumString );
    }

    ////////////////////////////////////////////////////////////////////////
    // interface EnumData mutator methods
    ////////////////////////////////////////////////////////////////////////

    public void  set (
      final EnumInteger  enumInteger,
      final Integer      value )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.check ( enumInteger );
      
      if ( integerMap == null )
      {
        integerMap
          = new EnumMap<EnumInteger, Integer> ( EnumInteger.class );
      }
      
      if ( value == null )
      {
        integerMap.remove ( enumInteger );
      }
      else
      {
        integerMap.put ( enumInteger, value );
      }
    }
    
    public void  set (
      final EnumString  enumString,
      final String      value )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.check ( enumString );
      
      if ( stringMap == null )
      {
        stringMap = new EnumMap<EnumString, String> ( EnumString.class );
      }
      
      if ( value == null )
      {
        stringMap.remove ( enumString );
      }
      else
      {
        stringMap.put ( enumString, value );
      }
    }

    ////////////////////////////////////////////////////////////////////////
    // JAXB accessor methods
    ////////////////////////////////////////////////////////////////////////
    
    public Map<EnumInteger, Integer>  getIntegerMap ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return integerMap;
    }
    
    public Map<EnumString, String>  getStringMap ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return stringMap;
    }
    
    ////////////////////////////////////////////////////////////////////////
    // JAXB mutator methods
    ////////////////////////////////////////////////////////////////////////
    
    public void  setIntegerMap (
      final Map<EnumInteger, Integer>  integerMap )
    ////////////////////////////////////////////////////////////////////////
    {
      this.integerMap = integerMap;
    }
    
    public void  setStringMap (
      final Map<EnumString, String>  stringMap )
    ////////////////////////////////////////////////////////////////////////
    {
      this.stringMap = stringMap;
    }
    
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }