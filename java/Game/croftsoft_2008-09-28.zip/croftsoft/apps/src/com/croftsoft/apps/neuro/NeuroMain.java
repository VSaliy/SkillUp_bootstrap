    package com.croftsoft.apps.neuro;
     
    import java.awt.*;
    import javax.swing.*;
    
    import com.croftsoft.core.gui.LifecycleWindowListener;
    import com.croftsoft.core.lang.lifecycle.Lifecycle;
    import com.croftsoft.core.lang.lifecycle.LifecycleLib;
    import com.croftsoft.core.lang.lifecycle.Updatable;
    import com.croftsoft.core.util.loop.EventQueueUpdateLoop;
    import com.croftsoft.core.util.loop.Looper;
    import com.croftsoft.core.util.loop.NanoTimeLoopGovernor;
    import com.croftsoft.core.util.mail.FlipMail;
     
    /***********************************************************************
    * Main.
    *
    * Launches the application within a framework.
    * 
    * @version
    *   $Id: NeuroMain.java,v 1.2 2008/08/30 00:52:22 croft Exp $
    * @since
    *   2008-08-17
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  NeuroMain
      implements Lifecycle
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private final NeuroConfig      neuroConfig;
     
    private final NeuroModelImp    neuroModelImp;
     
    private final NeuroController  neuroController;
       
    private final NeuroView        neuroView;
     
    private final Looper           looper;
       
    ////////////////////////////////////////////////////////////////////////
    // public static methods
    ////////////////////////////////////////////////////////////////////////

    public static void  main ( final String [ ]  args )
    ////////////////////////////////////////////////////////////////////////
    {
      final NeuroMain  neuroMain = new NeuroMain ( args );
       
      final JFrame  jFrame = new JFrame (
        neuroMain.neuroConfig.getFrameTitle ( ) );
       
      neuroMain.setContentPane ( jFrame.getContentPane ( ) );
       
      // The Frame is the framework.
       
      LifecycleWindowListener.launchFrameAsDesktopApp (
        jFrame,
        neuroMain,
        neuroMain.neuroConfig.getFrameSize ( ),
        neuroMain.neuroConfig.getShutdownConfirmationPrompt ( ) );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // constructor methods
    ////////////////////////////////////////////////////////////////////////
     
    public  NeuroMain ( final String [ ]  args )
    ////////////////////////////////////////////////////////////////////////
    {
      neuroConfig = NeuroConfigImp.load ( args );
       
      System.out.println ( "\n" + neuroConfig.getInfo ( ) );
      
      final FlipMail<NeuroMessage>  flipMail
        = new FlipMail<NeuroMessage> ( );
       
      neuroModelImp = new NeuroModelImp (
        neuroConfig,
        flipMail );
       
      neuroController = new NeuroController ( flipMail );
       
      neuroView = new NeuroView (
        neuroConfig,
        flipMail,
        neuroModelImp );
       
      neuroView.addUserInputListener ( neuroController );
      
      final Updatable [ ]  updatables = new Updatable [ ] {
        flipMail,
        neuroModelImp,
        neuroView,
        neuroController };
       
      looper = new Looper (
        new EventQueueUpdateLoop ( updatables ), // loopable
        new NanoTimeLoopGovernor ( neuroConfig.getUpdateRate ( ) ),
        null, // exceptionHandler
        neuroConfig.getThreadName ( ),
        Thread.MIN_PRIORITY,
        true ); // useDaemonThread
    }
     
    ////////////////////////////////////////////////////////////////////////
    // accessor methods
    ////////////////////////////////////////////////////////////////////////
     
    public NeuroConfig  getNeuroConfig ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return neuroConfig;
    }
     
    ////////////////////////////////////////////////////////////////////////
    // mutator methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  setContentPane ( final Container  contentPane )
    ////////////////////////////////////////////////////////////////////////
    {
      neuroView.setContentPane ( contentPane );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // interface Lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.init ( neuroView, looper );
    }
     
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.start (
        neuroView, neuroController, neuroModelImp, looper );
    }
     
    public void  stop ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.stop ( neuroView, looper );
    }
     
    public void  destroy ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.destroy ( neuroView, looper );
    }     
       
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }