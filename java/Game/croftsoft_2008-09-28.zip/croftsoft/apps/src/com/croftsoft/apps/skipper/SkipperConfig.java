    package com.croftsoft.apps.skipper;
     
    import java.awt.*;
    import java.io.*;
    import java.util.logging.*;

    import com.croftsoft.core.CroftSoftConstants;
    import com.croftsoft.core.beans.XmlBeanCoder;

    /***********************************************************************
    * Skipper persistent configuration.
    *  
    * Copyright 2007 David Wallace Croft.
    * 
    * @version
    *   $Date: 2007/07/28 17:59:46 $ $Author: croft $
    * @since
    *   2006-12-19
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  SkipperConfig
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private static final String
      VERSION    = "$Date: 2007/07/28 17:59:46 $",
      CLASS_NAME = SkipperConfig.class.getName ( ),
      TITLE      = "CroftSoft Skipper";

    private static final String  INFO
      = TITLE + "\n"
      + "Version " + VERSION + "\n"
      + CroftSoftConstants.COPYRIGHT + "\n"
      + CroftSoftConstants.DEFAULT_LICENSE + "\n"
      + CroftSoftConstants.HOME_PAGE + "\n";

    private static final int
      FRAME_WIDTH  = 600,
      FRAME_HEIGHT = 400;

    private static final double  UPDATE_RATE = 1.0;

    private static final String  SHUTDOWN_CONFIRMATION_PROMPT = null;

    private static final Font    FONT
      = new Font ( "Arioso", Font.BOLD, 20 );

    private static final Color
      BACKGROUND_COLOR = Color.BLACK,
      FOREGROUND_COLOR = Color.GREEN;

    private static final String
      CROFTSOFT_DIRECTORY   = ".croftsoft",
      SKIPPER_DIRECTORY     = "skipper",
      CONFIG_FILENAME       = "skipper.cfg",
      DEFAULT_PICTURES_PATH = "My Documents/My Pictures",
      WEIGHTS_FILENAME      = "skipper.dat";
    
    private static final String  SKIPPER_PATH
      = System.getProperty ( "user.home" )
      + File.separator
      + CROFTSOFT_DIRECTORY
      + File.separator
      + SKIPPER_DIRECTORY;

    // default values
    
    private static final long     DEFAULT_DISPLAY_TIME = 60;

    private static final Boolean  DEFAULT_DISPLAYING_IMAGE_FILENAME
      = Boolean.FALSE;

    // instance variables

    private Boolean  displayingImageFilename;

    private long     displayTime;

    private String   picturesPath;

    ////////////////////////////////////////////////////////////////////////
    // static methods
    ////////////////////////////////////////////////////////////////////////

    public static File  createWeightsFile ( )
    ////////////////////////////////////////////////////////////////////////
    {
      final File  skipperPathFile = new File ( SKIPPER_PATH );
      
      skipperPathFile.mkdirs ( );
      
      return new File ( skipperPathFile, WEIGHTS_FILENAME );
    }

    public static SkipperConfig  load ( String [ ]  args )
    ////////////////////////////////////////////////////////////////////////
    {
      try
      {
        final File  configFile = new File ( SKIPPER_PATH, CONFIG_FILENAME );

        if ( configFile.exists ( ) )
        {
          return ( SkipperConfig )
            XmlBeanCoder.loadFromXmlFile ( configFile );
        }
      }
      catch ( final Exception  ex )
      {
        Logger.getLogger ( CLASS_NAME ).throwing ( CLASS_NAME, "load", ex );
      }

      return new SkipperConfig ( );
    }

    ////////////////////////////////////////////////////////////////////////
    // accessor methods
    ////////////////////////////////////////////////////////////////////////
    
    public Color  getBackgroundColor ( ) { return BACKGROUND_COLOR; }

    public Color  getForegroundColor ( ) { return FOREGROUND_COLOR; }

    public String  getInfo ( ) { return INFO; }

    public Font  getFont ( ) { return FONT; }

    public Dimension  getFrameSize ( )
      { return new Dimension ( FRAME_WIDTH, FRAME_HEIGHT ); }

    public String  getFrameTitle ( ) { return TITLE; }

    public String  getPicturesPath ( ) { return picturesPath; }

    public String  getShutdownConfirmationPrompt ( )
      { return SHUTDOWN_CONFIRMATION_PROMPT; }

    public String  getThreadName ( ) { return TITLE; }

    public double  getUpdateRate ( ) { return UPDATE_RATE; }

    public long  getDisplayTime ( ) { return displayTime; }

    public long  getDefaultDisplayTime ( ) { return DEFAULT_DISPLAY_TIME; }

    public String  getDefaultPicturesPath ( )
      { return DEFAULT_PICTURES_PATH; }

    public Boolean  getDisplayingImageFilename ( )
      { return displayingImageFilename; }
    
    public Boolean  getDefaultDisplayingImageFilename ( )
      { return DEFAULT_DISPLAYING_IMAGE_FILENAME; }

    ////////////////////////////////////////////////////////////////////////
    // mutator methods
    ////////////////////////////////////////////////////////////////////////
    
    public void  setDisplayingImageFilename (
      final Boolean  displayingImageFilename )
    ////////////////////////////////////////////////////////////////////////
    {
      this.displayingImageFilename = displayingImageFilename;
    }
    
    public void  setDisplayTime ( final long  displayTime )
    ////////////////////////////////////////////////////////////////////////
    {
      this.displayTime = displayTime;
    }     

    public void  setPicturesPath ( final String  picturesPath )
    ////////////////////////////////////////////////////////////////////////
    {
      this.picturesPath = picturesPath;
    }

    ////////////////////////////////////////////////////////////////////////
    // persistence method
    ////////////////////////////////////////////////////////////////////////

    public void  save ( )
      throws IOException
    ////////////////////////////////////////////////////////////////////////
    {
      final File  skipperPathFile = new File ( SKIPPER_PATH );

      skipperPathFile.mkdirs ( );

      XmlBeanCoder.saveToXmlFile (
        this,
        new File ( skipperPathFile, CONFIG_FILENAME ) );
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }