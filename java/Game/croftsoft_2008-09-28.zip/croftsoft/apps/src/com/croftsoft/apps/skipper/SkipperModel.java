    package com.croftsoft.apps.skipper;
     
    import java.awt.*;
    import java.io.*;
    import java.util.*;
    import java.util.concurrent.*;
    import java.util.logging.*;

    import javax.imageio.*;

    import com.croftsoft.core.lang.*;
    import com.croftsoft.core.lang.lifecycle.*;

    /***********************************************************************
    * Skipper Model.
    * 
    * Maintains program state.
    * 
    * Copyright 2007 David Wallace Croft.
    * 
    * @version
    *   $Date: 2007/07/28 16:57:03 $ $Author: croft $
    * @since
    *   2006-12-19
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  SkipperModel
      implements Commissionable
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {

    private static final String  CLASS_NAME
      = SkipperModel.class.getName ( );

    private static final Double  DEFAULT_WEIGHT = new Double ( 1 );
    
    private static final double  REDUCTION_FACTOR = 0.5;

    //

    private final SkipperConfig  skipperConfig;

    private final Logger         logger;

    //

    private String [ ]  selections;

    private double [ ]  probabilities;

    private double [ ]  thresholds;

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    public  SkipperModel ( final SkipperConfig  skipperConfig )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        this.skipperConfig = skipperConfig );

      logger = Logger.getLogger ( CLASS_NAME );
      
      selections    = new String [ 0 ];
      
      probabilities = new double [ 0 ];
      
      thresholds    = new double [ 0 ];
    }

    ////////////////////////////////////////////////////////////////////////
    // accessor methods
    ////////////////////////////////////////////////////////////////////////

    public String [ ]  getSelections ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return selections;
    }

    public double [ ]  getCumulativeProbabilityThresholds ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return thresholds;
    }
    
    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////

    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      Executors.newSingleThreadExecutor ( ).execute (
        new Runnable ( )
        {
          public void  run ( )
          {
            final Map<String, Double>  selectionToWeightMap
              = loadSelections ( );
            
            loadWeights ( selectionToWeightMap );
            
            EventQueue.invokeLater (
              new Runnable ( )
              {
                public void  run ( )
                {
                  loadProbabilities ( selectionToWeightMap );

                  divideEachProbabilityBySum ( );
                }
              } );
          }
        } );
    }

    public void  destroy ( )
    ////////////////////////////////////////////////////////////////////////
    {
      try
      {
        saveWeights ( );
      }
      catch ( final Exception  ex )
      {
        logger.throwing ( CLASS_NAME, "destroy", ex );
      }
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    public void  decreaseProbabilityOfSkipped ( final int  imageIndex )
    ////////////////////////////////////////////////////////////////////////
    {
      if ( ( imageIndex >= 0 )
        && ( imageIndex < probabilities.length ) )
      {
        probabilities [ imageIndex ]
          = REDUCTION_FACTOR * probabilities [ imageIndex ];
      }
    }

    public void  divideEachProbabilityBySum ( )
    ////////////////////////////////////////////////////////////////////////
    {
      if ( probabilities.length < 1 )
      {
        return;
      }

      double  sumOfProbabilities = 0;

      for ( int  i = 0; i < probabilities.length; i++ )
      {
        sumOfProbabilities += probabilities [ i ];
      }
      
      thresholds [ 0 ] = 0;

      for ( int  i = 0; i < probabilities.length; i++ )
      {
        probabilities [ i ] = probabilities [ i ] / sumOfProbabilities;

        if ( i < probabilities.length - 1 )
        {         
          thresholds [ i + 1 ] = thresholds [ i ] + probabilities [ i ];
        }
      }

      final StringBuffer  stringBuffer
        = new StringBuffer ( "cumulative probability thresholds:  " );

      for ( int  i = 0; i < thresholds.length; i++ )
      {
        stringBuffer.append ( thresholds [ i ] + " " );
      }

      logger.info ( stringBuffer.toString ( ) );
    }
    
    ////////////////////////////////////////////////////////////////////////
    // private methods
    ////////////////////////////////////////////////////////////////////////

    private void  loadProbabilities (
      final Map<String, Double>  selectionToWeightMap )
    ////////////////////////////////////////////////////////////////////////
    {
      selections
        = selectionToWeightMap.keySet ( ).toArray ( new String [ 0 ] );

      final int  selectionCount = selections.length;

      logger.info ( "selectionCount = " + selectionCount );

      probabilities = new double [ selectionCount ];
      
      thresholds    = new double [ selectionCount ];

      for ( int  i = 0; i < selectionCount; i++ )
      {
        final Double  weight
          = selectionToWeightMap.get ( selections [ i ] );

        probabilities [ i ] = weight.doubleValue ( );
      }
    }

    private Map<String, Double>  loadSelections ( )
    ////////////////////////////////////////////////////////////////////////
    {
      try
      {
        logger.entering ( CLASS_NAME, "load" );

        final String [ ]  suffixes = ImageIO.getReaderFileSuffixes ( );

        final String  userHome = System.getProperty ( "user.home" );

        if ( userHome == null )
        {
          return null;
        }

        final File  homeDirectory = new File ( userHome );

        if ( !homeDirectory.exists ( )
          || !homeDirectory.isDirectory ( ) )
        {
          return null;
        }

        File  picturesDirectory = null;

        String  picturesPath = skipperConfig.getPicturesPath ( );

        if ( picturesPath == null )
        {
          picturesDirectory = new File (
            homeDirectory,
            skipperConfig.getDefaultPicturesPath ( ) );

          if ( picturesDirectory.exists ( )
            && picturesDirectory.isDirectory ( ) )
          {
            picturesPath = picturesDirectory.getCanonicalPath ( );

            skipperConfig.setPicturesPath ( picturesPath );
          }
        }
        else
        {
          picturesDirectory = new File ( picturesPath );
        }

        if ( ( picturesDirectory == null )
          || !picturesDirectory.exists ( )
          || !picturesDirectory.isDirectory ( ) )
        {
          picturesDirectory = homeDirectory;
        }

        logger.info ( "picturesDirectory:  " + picturesDirectory );

        final Map<String, Double>  selectionToWeightMap
          = new HashMap<String, Double> ( );

        final Stack<File>  directoryStack = new Stack<File> ( );

        directoryStack.add ( picturesDirectory );

        File  directory = null;

        while ( !directoryStack.isEmpty ( ) )
        {
          directory = directoryStack.pop ( );

          final String [ ]  list = directory.list ( );

          for ( String  filename : list )
          {
            final File  file = new File ( directory, filename );

            if ( file.isDirectory ( ) )
            {
              directoryStack.add ( file );

              continue;
            }

            filename = filename.toLowerCase ( );

            for ( final String  suffix : suffixes )
            {
              if ( filename.endsWith ( "." + suffix ) )
              {
                filename = file.getCanonicalPath ( );

                selectionToWeightMap.put ( filename, DEFAULT_WEIGHT );

                break;
              }
            }
          }
        }
        
        return selectionToWeightMap;
      }
      catch ( final Exception  ex )
      {
        logger.throwing ( CLASS_NAME, "load", ex );
      }
      finally
      {       
        logger.exiting ( CLASS_NAME, "load" );
      }
      
      return null;
    }

    private static void  loadWeights (
      final Map<String, Double>  selectionToWeightMap )
    ////////////////////////////////////////////////////////////////////////
    {
      try
      {
        final File  weightsFile = SkipperConfig.createWeightsFile ( ); 

        if ( ( weightsFile == null )
          || !weightsFile.exists ( ) )
        {
          return;
        }

        final BufferedReader  bufferedReader
          = new BufferedReader ( new FileReader ( weightsFile ) );

        try
        {
          String  line = null;

          while ( ( line = bufferedReader.readLine ( ) ) != null )
          {
            final int  index = line.trim ( ).indexOf ( ' ' );

            if ( index < 0 )
            {
              continue;
            }

            final String  weightString = line.substring ( 0, index );

            try
            {
              final double  weight = Double.parseDouble ( weightString );

              final String  imageFilename = line.substring ( index + 1 );

              if ( selectionToWeightMap.containsKey ( imageFilename ) )
              {             
                selectionToWeightMap.put (
                  imageFilename,
                  new Double ( weight ) );
              }
            }
            catch ( NumberFormatException  ex )
            {
              Logger.getLogger ( CLASS_NAME ).warning (
                "Weight does not parse as number:  " + weightString );
            }
          }
        }
        finally
        {
          bufferedReader.close ( );
        }
      }
      catch ( final Exception  ex )
      {
        Logger.getLogger ( CLASS_NAME ).throwing (
          CLASS_NAME, "loadWeights", ex );
      }
    }

    private void  saveWeights ( )
      throws IOException
    ////////////////////////////////////////////////////////////////////////
    {
      if ( ( selections == null    )
        || ( selections.length < 1 ) )
      {
        return;
      }

      final File  weightsFile = SkipperConfig.createWeightsFile ( );
      
      if ( weightsFile == null )
      {
        return;
      }
      
      final BufferedWriter  bufferedWriter
        = new BufferedWriter ( new FileWriter ( weightsFile ) );
      
      try
      {
        final int  selectionCount = selections.length;

        for ( int  i = 0; i < selectionCount; i++ )
        {
          final double  weight = probabilities [ i ] * selectionCount;

          bufferedWriter.write ( weight + " " + selections [ i ] );

          bufferedWriter.newLine ( );
        }
      }
      finally
      {
        bufferedWriter.close ( );
      }
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }