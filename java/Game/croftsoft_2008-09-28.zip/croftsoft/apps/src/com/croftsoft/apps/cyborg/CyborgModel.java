     package com.croftsoft.apps.cyborg;
     
     import javax.swing.event.*;

     import com.croftsoft.core.lang.lifecycle.Updatable;
     import com.croftsoft.core.util.loop.*;
     
     /*********************************************************************
     * Interface for CyborgModel.
     * 
     * @version
     *   $Id: CyborgModel.java,v 1.17 2008/04/19 21:30:58 croft Exp $
     * @since
     *   2005-03-16
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public interface  CyborgModel
       extends Updatable
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     public double  getAimX ( );
     
     public double  getAimY ( );
     
     public double  getAlpha ( );
     
     public boolean  getAnimate ( );
     
     public boolean  getForceLength ( );
     
     public LoopGovernor  getLoopGovernor ( );
     
     public double  getMax  ( );
     
     public double  getOffset ( );
     
     public boolean  getRealTime ( );
     
     public boolean [ ] [ ]  getSpikeRasters ( );
     
     public double  getTargetCenterX ( );
     
     public double  getTargetCenterY ( );
     
     public double  getTargetRadius ( );
     
     public double  getX ( );
     
     public double  getY ( );
     
     public String  getTransform ( );
       
     public void  setAimX ( double  aimX );

     public void  setAimY ( double  aimY );
     
     public void  setAlpha ( double  alpha );
     
     public void  setAnimate ( boolean  animate );
     
     public void  setForceLength ( boolean  forceLength );
     
     public void  setMax ( double  max );
     
     public void  setOffset ( double  offset );
     
     public void  setPaused ( boolean  paused );
     
     public void  setRealTime ( boolean  realTime );
     
     public void  setTransform ( String  transform );
     
     /*********************************************************************
      * Transforms from [-1 to +1] to [0 to +1].  
      *********************************************************************/
     public double  transform ( double  control );
     
     public void  addChangeListener ( ChangeListener  changeListener );
     
     public void  reset ( );
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }