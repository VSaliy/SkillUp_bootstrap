     package com.croftsoft.apps.infant;
     
     import java.io.*;     
     import java.util.*;
     
     import com.croftsoft.core.io.FileLib;
     import com.croftsoft.core.lang.*;
     import com.croftsoft.core.lang.lifecycle.*;
     import com.croftsoft.core.math.MathConstants;
     import com.croftsoft.core.util.ArrayLib;
     
     /**********************************************************************
     * Maintains state.
     * 
     * @version
     *   $Id: InfantModel.java,v 1.37 2007/02/25 03:25:29 croft Exp $
     * @since
     *   2006-01-03
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     **********************************************************************/

     public final class  InfantModel
       implements Destroyable, InfantAccessor, Updatable
     ///////////////////////////////////////////////////////////////////////
     ///////////////////////////////////////////////////////////////////////
     {
       
     // private final instance variables
       
     private final InfantConfig  infantConfig;
     
     private final Queue<InfantMessage>
       eventQueue,
       requestQueue;
       
     // model state instance variables
     
     private int     imageIndex;
     
     private String [ ]  imagePaths;
     
     private String  imagePath;
     
     private long
       imageDisplayTime,
       interStimulusInterval;
     
     private long
       imageStartTime,
       originalImageStartTime,
       cycle,
       contemplationNanos,
       contemplationStartTimeNanos,
       durationNanos;
     
     private InfantData  infantData;
     
     private boolean     experimentIsRunning;
     
     ///////////////////////////////////////////////////////////////////////
     ///////////////////////////////////////////////////////////////////////
     
     public  InfantModel (
       final InfantConfig          infantConfig,
       final Queue<InfantMessage>  requestQueue,
       final Queue<InfantMessage>  eventQueue )
     ///////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.checkArgs (
         this.infantConfig = infantConfig,
         this.requestQueue = requestQueue,
         this.eventQueue   = eventQueue );
       
       imagePaths = infantConfig.getImagePaths ( );
       
       imageDisplayTime = infantConfig.getImageDisplayTime ( );
       
       interStimulusInterval = infantConfig.getInterStimulusInterval ( );
       
       imageIndex = 0;
       
       if ( ( imagePaths != null    )
         && ( imagePaths.length > 0 ) )
       {
         imagePath = imagePaths [ 0 ];
       }
       
       infantData = new InfantData ( );
     }
     
     ///////////////////////////////////////////////////////////////////////
     // interface InfantAccessor methods
     ///////////////////////////////////////////////////////////////////////
     
     public long    getImageDisplayTime ( ) { return imageDisplayTime; }
     
     public String  getImagePath ( ) { return imagePath; }
     
     public long    getInterStimulusInterval ( )
       { return interStimulusInterval; }
     
     public double  getScale ( )
     ///////////////////////////////////////////////////////////////////////
     {
       final double  scale = infantConfig.getScale ( );
       
       return scale <= 0.0 ? 1.0 : scale;
     }
     
     ///////////////////////////////////////////////////////////////////////
     // lifecycle methods
     ///////////////////////////////////////////////////////////////////////
     
     public void  update ( )
     ///////////////////////////////////////////////////////////////////////
     {
       processRequests ( );
       
       updateExperiment ( );
     }
     
     public void  destroy ( )
     ///////////////////////////////////////////////////////////////////////
     {
       try
       {
         infantConfig.saveIfChanged ( this );
       }
       catch ( Exception  ex )
       {
         ex.printStackTrace ( );
       }
     }
     
     ///////////////////////////////////////////////////////////////////////
     // private methods
     ///////////////////////////////////////////////////////////////////////
     
     private void  addImage ( final InfantMessage  infantRequest )
     ///////////////////////////////////////////////////////////////////////
     {
       final String  addedImagePath
         = ( String ) infantRequest.getValue ( );
       
       try
       {
         final File  file = new File (
           InfantConfig.getInfantImagesDirPath ( ), addedImagePath );
       
         final String  canonicalPath = file.getCanonicalPath ( );
       
         imagePaths = ( String [ ] ) ArrayLib.append (
           imagePaths, canonicalPath );
       
         infantConfig.getLog ( ).record (
           "Added image \"" + canonicalPath + "\"" );
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
         
         infantConfig.getLog ( ).record (
           "Unable to add image \"" + addedImagePath + "\"" );
       }
     }
     
     private void  experimentBegin ( )
     ///////////////////////////////////////////////////////////////////////
     {
       experimentIsRunning = true;

       infantConfig.getLog ( ).record ( "Experiment started." );
       
       infantData = new InfantData ( );
       
       imageIndex = 0;
       
       setImagePath ( imagePaths [ 0 ] );
       
       durationNanos = contemplationNanos = cycle = 0;
       
       eventQueue.offer (
         new InfantMessage ( InfantMessage.Type.STIMULUS_WINDOW_OPEN ) );
     }     
     
     private void  experimentEnd ( )
     ///////////////////////////////////////////////////////////////////////
     {
       if ( !experimentIsRunning )
       {
         infantConfig.getLog ( ).record ( "Cannot end experiment "
           + "because experiment is not currently running." );
         
         return;
       }
       
       experimentIsRunning = false;
       
       recordData ( );
       
       infantConfig.getLog ( ).record ( "Experiment ended." );

       infantConfig.getLog ( ).record (
         "\nReport (cycle, stimulus, duration, contemplation)\n---\n"
         + infantData.report ( ) + "---\n" );
       
       eventQueue.offer (
         new InfantMessage ( InfantMessage.Type.STIMULUS_WINDOW_CLOSE ) );
     }
     
     private void  loadSetup ( final File  file )
     ///////////////////////////////////////////////////////////////////////
     {
       try
       {
         infantConfig.getLog ( ).record (
           "\nLoading setup file \"" + file + "\"..." );
         
         imagePaths = new String [ 0 ];
         
         final String  text = FileLib.loadTextFile ( file.getPath ( ) );
         
         final String [ ]  array = StringLib.toStringArray ( text );
         
         for ( String  s : array )
         {
           s = s.trim ( ).toLowerCase ( );
           
           if ( "".equals ( s ) )
           {
             continue;
           }
           
           int  index = s.indexOf ( ' ' );
           
           if ( index < 1 )
           {
             continue;
           }
           
           final String  name = s.substring ( 0, index );
           
           String  value = s.substring ( index );
           
           value = value.trim ( );
           
           if ( "".equals ( value ) )
           {
             continue;
           }
           
           if ( name.equals ( "duration" ) )
           {
             final Double  d = new Double ( value );
             
             final long  l = Math.round ( d.doubleValue ( )
               * MathConstants.NANOSECONDS_PER_SECOND );
             
             requestQueue.offer (
               new InfantMessage (
                 InfantMessage.Type.DURATION,
                 new Long ( l ) ) );
           }
           else if ( name.equals ( "isi" ) )
           {
             final Double  d = new Double ( value );
             
             final long  l = Math.round ( d.doubleValue ( )
               * MathConstants.NANOSECONDS_PER_SECOND );
             
             requestQueue.offer (
               new InfantMessage (
                 InfantMessage.Type.ISI,
                 new Long ( l ) ) );
           }
           else if ( name.equals ( "image" ) )
           {
             requestQueue.offer (
               new InfantMessage (
                 InfantMessage.Type.IMAGE,
                 value ) );
           }
           else if ( name.equals ( "scale" ) )
           {
             requestQueue.offer (
               new InfantMessage (
                 InfantMessage.Type.SET_SCALE_REQUEST,
                 value ) );
           }
           else
           {
             System.out.println ( "Ignoring " + s );
           }
         }
       }
       catch ( Exception  ex )
       {
         ex.printStackTrace ( );
       }
     }
     
     private void  processRequests ( )
     ///////////////////////////////////////////////////////////////////////
     {
       InfantMessage  infantRequest = null;
       
       while ( ( infantRequest = requestQueue.poll ( ) ) != null )
       {
         final InfantMessage.Type  type = infantRequest.getType ( );
         
         final Object  value = infantRequest.getValue ( );
         
         switch ( type )
         {
           case DURATION:
             
             setImageDisplayTime ( ( ( Long ) value ).longValue ( ) );
             
             break;
             
           case EXPERIMENT_BEGIN:
             
             experimentBegin ( );
             
             break;
             
           case EXPERIMENT_END:
             
             experimentEnd ( );
             
             break;
             
           case IMAGE:
             
             addImage ( infantRequest );
             
             break;
             
           case ISI:
             
             setInterStimulusInterval ( ( ( Long ) value ).longValue ( ) );
             
             break;
             
           case LOAD_SETUP:
             
             final File  file = ( File ) value;
             
             if ( file == null )
             {             
               eventQueue.offer (
                 new InfantMessage ( InfantMessage.Type.LOAD_SETUP ) );
             }
             else
             {
               loadSetup ( file );
             }
             
             break;
             
           case PACIFIER:
             
             final long  currentTime = System.nanoTime ( );
       
             if ( imagePath == imagePaths [ 0 ] )
             {
               final long  deltaTimeNanos = currentTime - imageStartTime;
       
               if ( deltaTimeNanos >= interStimulusInterval )
               {
                 contemplationNanos
                   = currentTime - contemplationStartTimeNanos;
                 
                 if ( imageIndex != 0 )
                 {
                   recordData ( );
                 }
                 
                 imageIndex = ( imageIndex + 1 ) % imagePaths.length;
                 
                 if ( imageIndex == 0 )
                 {
                   imageIndex = ( imageIndex + 1 ) % imagePaths.length;
                   
                   cycle++;
                 }
                 
                 durationNanos = contemplationNanos = 0;
               }               
               
               originalImageStartTime = currentTime;
               
               setImagePath ( imagePaths [ imageIndex ] );
             }
             
             imageStartTime = currentTime;
             
             break;
             
           case REQUEST_SAVE_FILENAME:
             
             requestSaveFilename ( );             
             
             break;
             
           case SAVE_DATA:
             
             saveData ( infantRequest );
             
             break;
             
           case SET_SCALE_REQUEST:
             
             setScale ( ( ( Double ) value ).doubleValue ( ) );
             
             break;
             
           case SET_CONTROLLER_INDEX:
             
             setControllerIndex ( infantRequest );
             
             break;
             
           case STIMULUS_WINDOW_CLOSING:
             
             experimentEnd ( );
             
             break;
             
           default:
             
             infantConfig.getLog ( ).record (
               "InfantModel:  unknown message type:  " + type );
         }
       }
     }
     
     private void  saveData ( final InfantMessage  infantMessage )
     ///////////////////////////////////////////////////////////////////////
     {
       final Object [ ]  value = ( Object [ ] ) infantMessage.getValue ( );
       
       final File  file = ( File ) value [ 0 ];
       
       final InfantData  infantData2 = ( InfantData ) value [ 1 ];
       
       try
       {
         final BufferedWriter  bufferedWriter
           = new BufferedWriter ( new FileWriter ( file ) );
         
         bufferedWriter.write ( infantData2.report ( ) );
         
         bufferedWriter.close ( );

         infantConfig.getLog ( ).record (
           "Data saved to " + file.getCanonicalPath ( ) );
       }
       catch ( final IOException  ex )
       {
         ex.printStackTrace ( );

         infantConfig.getLog ( ).record ( "Saving data failed." );
         
         infantConfig.getLog ( ).record ( ex );
       }
     }
     
     private void  setControllerIndex (
       final InfantMessage  infantMessage )
     ///////////////////////////////////////////////////////////////////////
     {
       final Integer  value = ( Integer ) infantMessage.getValue ( );
       
       final int  newControllerIndex = value.intValue ( );
       
       final int  oldControllerIndex = infantConfig.getControllerIndex ( );
       
       if ( newControllerIndex == oldControllerIndex )
       {
         return;
       }
       
       infantConfig.setControllerIndex ( newControllerIndex );
       
       infantConfig.getLog ( ).record (
         "Controller index set to " + newControllerIndex );
     }       
     
     private void  setImageDisplayTime ( final long  imageDisplayTime )
     ///////////////////////////////////////////////////////////////////////
     {
       if ( imageDisplayTime != this.imageDisplayTime )
       {
         this.imageDisplayTime = imageDisplayTime;
       
         eventQueue.offer (
           new InfantMessage ( InfantMessage.Type.DURATION_CHANGED ) );
       }
       
       infantConfig.getLog ( ).record (
         "Image display time set to "
         + imageDisplayTime * MathConstants.SECONDS_PER_NANOSECOND
         + " s" );         
     }
     
     private void  setImagePath ( final String  imagePath )
     ///////////////////////////////////////////////////////////////////////
     {
       this.imagePath = imagePath;
       
       eventQueue.offer (
         new InfantMessage ( InfantMessage.Type.IMAGE ) );
     }
     
     private void  setInterStimulusInterval (
       final long  interStimulusInterval )
     ///////////////////////////////////////////////////////////////////////
     {
       if ( interStimulusInterval != this.interStimulusInterval )
       {
         this.interStimulusInterval = interStimulusInterval;
       
         eventQueue.offer (
           new InfantMessage ( InfantMessage.Type.ISI_CHANGED ) );
       }
       
       infantConfig.getLog ( ).record (
         "Interstimulus interval (ISI) set to "
         + interStimulusInterval * MathConstants.SECONDS_PER_NANOSECOND
         + " s" );         
     }
     
     private void  requestSaveFilename ( )
     ///////////////////////////////////////////////////////////////////////
     {
       if ( experimentIsRunning )
       {
         experimentEnd ( );
       }
       
       eventQueue.offer (
         new InfantMessage (
           InfantMessage.Type.GET_SAVE_REPORT_FILENAME,
           infantData ) );
     }
     
     private void  setScale ( final double  scale )
     ///////////////////////////////////////////////////////////////////////
     {
       if ( scale <= 0 )
       {
         infantConfig.getLog ( ).record ( "Scale must be > 0.0" );
         
         return;
       }
       
       infantConfig.setScale ( scale );
       
       infantConfig.getLog ( ).record ( "Scale set to " + scale );
     }
     
     private void  updateExperiment ( )
     ///////////////////////////////////////////////////////////////////////
     {
       if ( imagePaths.length < 1 )
       {
         return;
       }
       
       if ( imagePath != imagePaths [ 0 ] )
       {
         final long  currentTime = System.nanoTime ( );
       
         final long  deltaTimeNanos = currentTime - imageStartTime;
       
         if ( deltaTimeNanos >= imageDisplayTime )
         {
           setImagePath ( imagePaths [ 0 ] );
           
           durationNanos += ( currentTime - originalImageStartTime );
           
           contemplationStartTimeNanos = currentTime;
         }
       }
     }
     
     private void  recordData ( )
     ///////////////////////////////////////////////////////////////////////
     {
       final double  duration
         = durationNanos * MathConstants.SECONDS_PER_NANOSECOND;
       
       final double  contemplation
         = contemplationNanos * MathConstants.SECONDS_PER_NANOSECOND;
                 
       infantData.record (
         cycle + 1,
         imageIndex,
         duration,
         contemplation );
                 
       infantConfig.getLog ( ).record (
         String.format (
           "%1$d %2$d %3$1.3f %4$1.3f",
           new Long    ( cycle + 1     ),
           new Integer ( imageIndex    ),
           new Double  ( duration      ),
           new Double  ( contemplation ) ) );
     }
     
     ///////////////////////////////////////////////////////////////////////
     ///////////////////////////////////////////////////////////////////////
     }