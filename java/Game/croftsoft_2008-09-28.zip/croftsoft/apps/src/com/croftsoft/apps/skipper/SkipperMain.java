    package com.croftsoft.apps.skipper;

    import java.awt.*;
    import java.util.logging.*;
    import javax.swing.*;

    import com.croftsoft.core.gui.LifecycleWindowListener;
    import com.croftsoft.core.lang.lifecycle.Lifecycle;
    import com.croftsoft.core.lang.lifecycle.LifecycleLib;
    import com.croftsoft.core.util.loop.EventQueueUpdateLoop;
    import com.croftsoft.core.util.loop.Looper;
    import com.croftsoft.core.util.loop.NanoTimeLoopGovernor;

    /***********************************************************************
    * Skipper Main.
    *
    * Copyright 2007 David Wallace Croft.
    * 
    * @version
    *   $Date: 2007/07/28 16:57:04 $ $Author: croft $
    * @since
    *   2006-12-19
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  SkipperMain
      implements Lifecycle
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
     
    private final SkipperConfig  skipperConfig;
     
    private final SkipperModel   skipperModel;

    private final SkipperView    skipperView;

    private final Looper         looper;

    ////////////////////////////////////////////////////////////////////////
    // public static methods
    ////////////////////////////////////////////////////////////////////////

    public static void  main ( final String [ ]  args )
    ////////////////////////////////////////////////////////////////////////
    {
      final Logger  logger = Logger.getLogger (
        SkipperMain.class.getPackage ( ).getName ( ) );

      logger.setLevel ( Level.INFO );

      final Handler  handler = new ConsoleHandler ( );

      handler.setLevel ( Level.WARNING );

      logger.addHandler ( handler );

      final SkipperMain  skipperMain = new SkipperMain ( args );

      final JFrame  jFrame = new JFrame (
        skipperMain.skipperConfig.getFrameTitle ( ) );

      skipperMain.setContentPane ( jFrame.getContentPane ( ) );

      // The Frame is the framework.

      LifecycleWindowListener.launchFrameAsDesktopApp (
        jFrame,
        skipperMain,
        skipperMain.skipperConfig.getFrameSize ( ),
        skipperMain.skipperConfig.getShutdownConfirmationPrompt ( ) );
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    public  SkipperMain ( final String [ ]  args )
    ////////////////////////////////////////////////////////////////////////
    {
      skipperConfig = SkipperConfig.load ( args );

      skipperModel = new SkipperModel ( skipperConfig );

      skipperView = new SkipperView ( skipperConfig, skipperModel );

      looper = new Looper (
        new EventQueueUpdateLoop ( skipperView ), // loopable
        new NanoTimeLoopGovernor ( skipperConfig.getUpdateRate ( ) ),
        null, // exceptionHandler
        skipperConfig.getThreadName ( ),
        Thread.MIN_PRIORITY,
        true ); // useDaemonThread
    }

    ////////////////////////////////////////////////////////////////////////
    // accessor methods
    ////////////////////////////////////////////////////////////////////////

    public SkipperConfig  getSkipperConfig ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return skipperConfig;
    }

    ////////////////////////////////////////////////////////////////////////
    // mutator methods
    ////////////////////////////////////////////////////////////////////////

    public void  setContentPane ( final Container  contentPane )
    ////////////////////////////////////////////////////////////////////////
    {
      skipperView.setContentPane ( contentPane );
    }

    ////////////////////////////////////////////////////////////////////////
    // interface Lifecycle methods
    ////////////////////////////////////////////////////////////////////////

    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.init ( skipperModel, skipperView, looper );
    }

    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.start ( looper );
    }

    public void  stop ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.stop ( looper );
    }

    public void  destroy ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.destroy ( looper, skipperModel );

      try
      {
        skipperConfig.save ( );
      }
      catch ( final Exception  ex )
      {
        ex.printStackTrace ( );
      }
    }     

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }