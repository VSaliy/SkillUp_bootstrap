     package com.croftsoft.apps.road.model.seri;

     import java.awt.*;

     import com.croftsoft.core.animation.model.ModelId;
     import com.croftsoft.core.animation.model.seri.SeriModel;
     import com.croftsoft.core.lang.NullArgumentException;
     
     import com.croftsoft.apps.road.Constants;
     import com.croftsoft.apps.road.model.Car;

     /*********************************************************************
     * Roadrunner hero car model.
     *
     * @version
     *   2003-11-09
     * @since
     *   2003-11-09
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  SeriCar
       extends SeriModel
       implements Car, Constants
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     private static final long  serialVersionUID = 0L;

     //

     private final Rectangle  bounds;

     //

     private Point   destinationPoint;

     private double  x;

     private double  y;

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public  SeriCar (
       ModelId    modelId,
       Rectangle  bounds )
     //////////////////////////////////////////////////////////////////////
     {
       super ( modelId );

       NullArgumentException.check ( this.bounds = bounds );
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public boolean  isActive   ( ) { return true; }

     public double   getCenterX ( ) { return x;    }

     public double   getCenterY ( ) { return y;    }

     public Shape    getShape   ( ) { return null; }

     public boolean  isUpdated  ( ) { return true; }

     public double   getZ       ( ) { return 0.0;  }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public void  setDestinationPoint ( Point  destinationPoint )
     //////////////////////////////////////////////////////////////////////
     {
       this.destinationPoint = destinationPoint;
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public void  setCenter (
       double  x,
       double  y )
     //////////////////////////////////////////////////////////////////////
     {
       this.x = x;

       this.y = y;
     }

     public void  prepare ( )
     //////////////////////////////////////////////////////////////////////
     {
     }

     public void  update ( double  timeDelta )
     //////////////////////////////////////////////////////////////////////
     {
       if ( destinationPoint != null )
       {
         double  deltaX = destinationPoint.x - x - TILE_SIZE / 2;

         double  deltaY = destinationPoint.y - y - TILE_SIZE / 2;

         if ( timeDelta > TIME_DELTA_MAX )
         {
           timeDelta = TIME_DELTA_MAX;
         }

         double  spaceDelta = timeDelta * RUNNER_VELOCITY;

         if ( deltaX > 0 )
         {
           x = spaceDelta >  deltaX ? x + deltaX : x + spaceDelta;
         }
         else if ( deltaX < 0 )
         {
           x = spaceDelta > -deltaX ? x + deltaX : x - spaceDelta;
         }

         if ( deltaY > 0 )
         {
           y = spaceDelta >  deltaY ? y + deltaY : y + spaceDelta;
         }
         else if ( deltaY < 0 )
         {
           y = spaceDelta > -deltaY ? y + deltaY : y - spaceDelta;
         }
       }

       if ( x < bounds.x )
       {
         x = bounds.x;

         y += 3;
       }
       else if ( x < bounds.x + TILE_SIZE )
       {
         x += 1;

         y += 2;
       }
       else if ( x < bounds.x + 2 * TILE_SIZE )
       {
         y += 1;
       }
       else if ( x > bounds.x + bounds.width )
       {
         x = bounds.x + bounds.width;

         y += 3;
       }
       else if ( x > bounds.x + bounds.width - TILE_SIZE )
       {
         x -= 1;

         y += 2;
       }
       else if ( x > bounds.x + bounds.width - 2 * TILE_SIZE )
       {
         y += 1;
       }

       if ( y > bounds.y + bounds.height - TILE_SIZE )
       {
         y = bounds.y + bounds.height - TILE_SIZE;
       }
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }