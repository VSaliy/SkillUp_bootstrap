     package com.croftsoft.apps.infant;
     
     /*********************************************************************
     * Read-only accessor interface to InfantModel.
     * 
     * @version
     *   $Id: InfantAccessor.java,v 1.14 2007/02/25 03:17:05 croft Exp $
     * @since
     *   2006-01-15
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public interface  InfantAccessor
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     //////////////////////////////////////////////////////////////////////
     // accessor methods
     //////////////////////////////////////////////////////////////////////
     
     /** Nanoseconds. */
     public long    getImageDisplayTime ( );
     
     /** Nanoseconds. */
     public long    getInterStimulusInterval ( );
     
     public String  getImagePath ( );
     
     public double  getScale ( );
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }