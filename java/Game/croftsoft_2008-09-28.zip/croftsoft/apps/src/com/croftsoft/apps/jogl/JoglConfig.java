    package com.croftsoft.apps.jogl;

    import java.awt.*;
     
    /***********************************************************************
    * JOGL configuration.
    *  
    * @version
    *   $Id: JoglConfig.java,v 1.7 2008/04/19 23:52:10 croft Exp $
    * @since
    *   2008-02-18
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public interface  JoglConfig
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    public String     getInfo ( );
     
    public Dimension  getFrameSize ( );
     
    public String     getFrameTitle ( );

    public String     getShutdownConfirmationPrompt ( );
     
    public String     getThreadName ( );
     
    public double     getUpdateRate ( );
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }