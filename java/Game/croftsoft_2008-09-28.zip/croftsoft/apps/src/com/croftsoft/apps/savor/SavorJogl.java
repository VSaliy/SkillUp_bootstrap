     package com.croftsoft.apps.savor;
     
     import java.awt.*;
     import java.awt.event.*;
     import java.util.*;
     
     import net.java.games.jogl.GL;
     import net.java.games.jogl.GLCapabilities;
     import net.java.games.jogl.GLDrawable;
     import net.java.games.jogl.GLU;
     
     import org.jdesktop.jdic.screensaver.JOGLScreensaver;
     import org.jdesktop.jdic.screensaver.ScreensaverContext;
     import org.jdesktop.jdic.screensaver.ScreensaverSettings;
     
     /*********************************************************************
     * CroftSoft Savor.
     *
     * @version
     *   $Id: SavorJogl.java,v 1.1 2006/12/09 06:31:36 croft Exp $
     * @since
     *   2006-09-26
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  SavorJogl
       extends JOGLScreensaver
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final String  PROPERTY_OVAL_SIZE = "ovalSize";
       
     private static final String [ ]  PROPERTY_VALUES = {
       "tiny",
       "small",
       "medium",
       "large" };
     
     private static final int [ ]  OVAL_SIZE_DIVISORS = {
       Integer.MAX_VALUE,
       8,
       4,
       2 };
     
     private static final long  FRAME_PERIOD = 200;
     
     //
     
     private final Map<String, Integer>  ovalSizeMap;
     
     private final Random  random;
     
     //
       
     private int
       ovalSize,
       ovalSizeDivisor,
       width,
       height;
     
     private boolean
       toggle,
       triangle;
     
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  SavorJogl ( )
     //////////////////////////////////////////////////////////////////////
     {
       random = new Random ( );
       
       ovalSizeMap = new HashMap<String, Integer> ( );
       
       for ( int  i = 0; i < PROPERTY_VALUES.length; i++ )
       {
         ovalSizeMap.put (
           PROPERTY_VALUES [ i ],
           new Integer ( OVAL_SIZE_DIVISORS [ i ] ) );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     @Override
     public GLCapabilities  getGLCapabilities ( )
     //////////////////////////////////////////////////////////////////////
     {
       final GLCapabilities  glCapabilities = new GLCapabilities ( );
       
       glCapabilities.setDoubleBuffered ( false );
       
       return glCapabilities;
     }
     
     public void  init ( final GLDrawable  glDrawable )
     //////////////////////////////////////////////////////////////////////
     {
       final GL  gl = glDrawable.getGL ( );
       
       gl.glClearColor ( 0, 0, 0, 0 );

       ovalSizeDivisor
         = OVAL_SIZE_DIVISORS [ OVAL_SIZE_DIVISORS.length - 1 ];
       
       final ScreensaverContext  screensaverContext = getContext ( );
       
       final ScreensaverSettings  screensaverSettings
         = screensaverContext.getSettings ( );
       
       String  propertyValue
         = screensaverSettings.getProperty ( PROPERTY_OVAL_SIZE );
       
       if ( propertyValue != null )
       {
         propertyValue = propertyValue.trim ( ).toLowerCase ( );
         
         final Integer  ovalSizeDivisorInteger
           = ovalSizeMap.get ( propertyValue );
         
         if ( ovalSizeDivisorInteger != null )
         {
           ovalSizeDivisor = ovalSizeDivisorInteger.intValue ( );
         }
       }
       
       final Component  component = screensaverContext.getComponent ( );
       
       component.addKeyListener (
         new KeyAdapter ( )
         {
           @Override
           public void  keyTyped ( final KeyEvent  keyEvent )
           {
             final char  keyChar = keyEvent.getKeyChar ( );
             
             if ( keyChar == ' ' )
             {
               toggle = true;
             }
             else
             {
               destroy ( );
             }
           }
         } );
       
       component.requestFocus ( );
     }
       
     public void  reshape (
       final GLDrawable  glDrawable,
       final int         x,
       final int         y,
       final int         width, 
             int         height ) 
     //////////////////////////////////////////////////////////////////////
     {
       final GL  gl = glDrawable.getGL ( );
       
       final GLU  glu = glDrawable.getGLU();
        
       gl.glViewport ( x, y, width, height);
       
       gl.glMatrixMode ( GL.GL_PROJECTION );
       
       gl.glLoadIdentity ( );
       
       glu.gluOrtho2D ( 0, width, 0, height );
       
       ovalSize = Math.max (
         1,
         Math.min ( width, height ) / ovalSizeDivisor );
       
       this.width  = width  + 2 * ovalSize;
       
       this.height = height + 2 * ovalSize;
       
       gl.glClear ( GL.GL_COLOR_BUFFER_BIT );       
     }     
     
     public void  displayChanged (
       final GLDrawable  arg0,
       final boolean     arg1,
       final boolean     arg2 )
     //////////////////////////////////////////////////////////////////////
     {
       // ignore
     }
     
     public void  display ( final GLDrawable  glDrawable )
     //////////////////////////////////////////////////////////////////////
     {
       final int  x
         = ( int ) ( Math.random ( ) * width  ) - ovalSize;
       
       final int  y
         = ( int ) ( Math.random ( ) * height ) - ovalSize;
       
       final int  ovalWidth  = Math.max (
         1, ( int ) ( ovalSize * ( 1 + 0.2 * random.nextGaussian ( ) ) ) );
       
       final int  ovalHeight = Math.max (
         1, ( int ) ( ovalSize * ( 1 + 0.2 * random.nextGaussian ( ) ) ) );
       
       final GL  gl = glDrawable.getGL ( );
       
       if ( toggle )
       {
         toggle = false;
         
         triangle = !triangle;
         
         gl.glClear ( GL.GL_COLOR_BUFFER_BIT );
       }
       
       gl.glColor3f (
         ( float ) Math.random ( ),
         ( float ) Math.random ( ),
         ( float ) Math.random ( ) );
       
       gl.glBegin ( GL.GL_POLYGON );
       
       gl.glVertex2i ( x, y );
       
       gl.glVertex2i ( x + ovalWidth, y );
       
       if ( triangle )
       {
         gl.glVertex2i ( x + ovalWidth / 2, y + ovalHeight );
       }
       else
       {
         gl.glVertex2i ( x + ovalWidth, y + ovalHeight );
       
         gl.glVertex2i ( x, y + ovalHeight );
       }
       
       gl.glEnd ( );
       
       try
       {
         Thread.sleep ( FRAME_PERIOD );
       }
       catch ( final InterruptedException  ex )
       {
         // ignore
       }
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }