     package com.croftsoft.apps.client;
     
     import com.croftsoft.core.lang.NullArgumentException;
     
     /*********************************************************************
     * Enumerated type message.
     * 
     * Use to pass messages between the model, view, and controller.
     * 
     * @version
     *   $Id: ClientMessage.java,v 1.2 2006/11/14 03:04:08 croft Exp $
     * @since
     *   2006-10-30
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  ClientMessage
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     public enum  Type
     {
       SEND_TEXT_REQUEST,
       SPEECH_EVENT,
       TEXT_EVENT
     }
     
     //
       
     private final Type    type;
     
     private final Object  content;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  ClientMessage (
       final Type    type,
       final Object  content )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.check ( this.type = type );
       
       this.content = content;
     }
     
     public  ClientMessage ( final Type  type )
     //////////////////////////////////////////////////////////////////////
     {
       this ( type, null );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public Type    getType    ( ) { return type;    }
     
     public Object  getContent ( ) { return content; }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }