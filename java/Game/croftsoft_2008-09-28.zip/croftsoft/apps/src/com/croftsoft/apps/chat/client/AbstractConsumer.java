     package com.croftsoft.apps.chat.client;

     import com.croftsoft.core.util.consumer.Consumer;

     /*********************************************************************
     * An abstract server message Consumer implementation.
     *
     * @version
     *   2003-06-11
     * @since
     *   2003-06-11
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public abstract class  AbstractConsumer
       implements Consumer
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }
