    package com.croftsoft.apps.jogl;

    import com.croftsoft.core.media.jogl.camera.JoglCamera;
    import com.croftsoft.core.media.jogl.render.JoglSpinCube;

    /***********************************************************************
    * Jogl model accessor interface.
    * 
    * Read-only access to model state.
    * 
    * @version
    *   $Id: JoglModel.java,v 1.13 2008/05/17 01:32:31 croft Exp $
    * @since
    *   2008-02-10
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public interface  JoglModel
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
      
    public enum  EnumDouble
    {
      // reserved
    }
    
    public double  get ( EnumDouble  enumDouble );
    
    public JoglCamera  getJoglCamera ( );
    
    public JoglSpinCube.Model  getJoglSpinCubeModel ( );
    
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }