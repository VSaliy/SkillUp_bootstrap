     package com.croftsoft.apps.slideshow;
     
     import java.awt.*;
     import java.util.logging.*;
     import javax.swing.*;

     import com.croftsoft.core.animation.ComponentAnimator;
     import com.croftsoft.core.animation.animator.NullComponentAnimator;
     import com.croftsoft.core.lang.NullArgumentException;
     import com.croftsoft.core.lang.lifecycle.Initializable;
     import com.croftsoft.core.lang.lifecycle.Updatable;

     /*********************************************************************
     * View.
     *  
     * @version
     *   $Id: SlideshowView.java,v 1.1 2006/12/16 09:26:39 croft Exp $
     * @since
     *   2006-12-15
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  SlideshowView
       implements Initializable, Updatable
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final String  CLASS_NAME
       = SlideshowView.class.getName ( );
     
     //
     
     private final SlideshowConfig  slideshowConfig;
     
     private final Logger           logger;
     
     private final JComponent       jComponent;
     
     //
     
     private ComponentAnimator  componentAnimator;
     
     //////////////////////////////////////////////////////////////////////
     // constructor methods
     //////////////////////////////////////////////////////////////////////
     
     public  SlideshowView ( final SlideshowConfig  slideshowConfig )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.check (
         this.slideshowConfig = slideshowConfig );
       
       logger = Logger.getLogger ( CLASS_NAME );
       
       componentAnimator = NullComponentAnimator.INSTANCE;
       
       jComponent = new JComponent ( )
         {
           private static final long  serialVersionUID = 0L;
         
           @Override
           public void  paintComponent ( final Graphics  graphics )
           {
             componentAnimator.paint ( this, ( Graphics2D ) graphics );
           }
         };
     }
     
     //////////////////////////////////////////////////////////////////////
     // mutator methods
     //////////////////////////////////////////////////////////////////////
     
     public void  setContentPane ( final Container  contentPane )
     //////////////////////////////////////////////////////////////////////
     {
       contentPane.setLayout ( new BorderLayout ( ) );
       
       contentPane.add ( jComponent, BorderLayout.CENTER );
     }
     
     //////////////////////////////////////////////////////////////////////
     // lifecycle methods
     //////////////////////////////////////////////////////////////////////
     
     public void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       componentAnimator
         = new SlideshowAnimator ( slideshowConfig, jComponent );
     }
     
     public void  update ( )
     //////////////////////////////////////////////////////////////////////
     {
       componentAnimator.update ( jComponent );
     }       

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }