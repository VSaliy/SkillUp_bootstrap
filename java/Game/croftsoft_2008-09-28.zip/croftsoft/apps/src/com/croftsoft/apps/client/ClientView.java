     package com.croftsoft.apps.client;
     
     import java.awt.*;
     import java.awt.event.*;
     import java.util.*;
     import javax.swing.*;
     
     import com.croftsoft.core.gui.LogPanel;
     import com.croftsoft.core.lang.NullArgumentException;
     import com.croftsoft.core.lang.lifecycle.Lifecycle;
     import com.croftsoft.core.lang.lifecycle.Updatable;
     
     import com.whoola.core.speech.ChatSpeaker;
     import com.whoola.core.speech.ChatSpeakerLib;
     
     /*********************************************************************
     * Exemplar view.
     *  
     * @version
     *   $Id: ClientView.java,v 1.11 2008/04/19 21:31:00 croft Exp $
     * @since
     *   2006-10-30
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  ClientView
       implements ActionListener, Lifecycle, Updatable
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
    	 
     private final LogPanel     logPanel;
     
     private final JTextField   jTextField;
     
     private final ChatSpeaker  chatSpeaker;
     
     private final Queue<ClientMessage>
       modelQueue,
       viewQueue;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  ClientView (
       final ClientConfig          config,
       final Queue<ClientMessage>  viewQueue,
       final Queue<ClientMessage>  modelQueue )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.checkArgs (
         config,
         this.viewQueue   = viewQueue,
         this.modelQueue  = modelQueue );
       
       logPanel = new LogPanel (
         1000,        // linesMax
         Color.WHITE, // backgroundColor
         null );      // font

       jTextField = new JTextField ( );
       
       jTextField.addActionListener ( this );

       chatSpeaker = ChatSpeakerLib.createChatSpeaker ( );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  setContentPane ( final Container  contentPane )
     //////////////////////////////////////////////////////////////////////
     {
       contentPane.setLayout ( new BorderLayout ( ) );
       
       final JScrollPane  jScrollPane = new JScrollPane ( logPanel );
       
       jScrollPane.setHorizontalScrollBarPolicy (
         ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER );
       
       contentPane.add ( jScrollPane, BorderLayout.CENTER );

       contentPane.add ( jTextField, BorderLayout.SOUTH );
     }
     
     //////////////////////////////////////////////////////////////////////
     // lifecycle methods
     //////////////////////////////////////////////////////////////////////
     
     public void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       // System.out.println ( "View.init()" );

       try
       {
         chatSpeaker.init ( );
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
       }
       
       modelQueue.offer ( new ClientMessage (
         ClientMessage.Type.SEND_TEXT_REQUEST, "Hello." ) );
     }
     
     public void  start ( )
     //////////////////////////////////////////////////////////////////////
     {
       // System.out.println ( "View.start()" );       
     }
     
     public void  stop ( )
     //////////////////////////////////////////////////////////////////////
     {
       // System.out.println ( "View.stop()" );       
     }
     
     public void  destroy ( )
     //////////////////////////////////////////////////////////////////////
     {
       // System.out.println ( "View.destroy()" );
       
       try
       {
         chatSpeaker.destroy ( );
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
       }
     }
     
     public void  update ( )
     //////////////////////////////////////////////////////////////////////
     {
       ClientMessage  message = null;
       
       while ( ( message = viewQueue.poll ( ) ) != null )
       {
         final ClientMessage.Type  type = message.getType ( );
         
         switch ( type )
         {
           case SPEECH_EVENT:
             
             doSpeechEvent ( message );
             
             break;
             
           case TEXT_EVENT:
             
             doTextEvent ( message );
             
             break;
             
           default:
             
             System.out.println ( getClass ( ).getName ( ) + ":  "
               + "unknown message type:  " + type );
         }
       }
     }       
     
     //////////////////////////////////////////////////////////////////////
     // interface ActionListener method
     //////////////////////////////////////////////////////////////////////

     public void  actionPerformed ( ActionEvent  actionEvent )
     //////////////////////////////////////////////////////////////////////
     {
       if ( actionEvent.getSource ( ) == jTextField )
       {
         final String  text = jTextField.getText ( );

         jTextField.setText ( "" );
         
         //logPanel.record ( text );
         
         modelQueue.offer ( new ClientMessage (
           ClientMessage.Type.TEXT_EVENT,
           "you:  " + text ) );
         
         modelQueue.offer ( new ClientMessage (
           ClientMessage.Type.SEND_TEXT_REQUEST, text ) );
       }
       else
       {
         throw new IllegalArgumentException ( );
       }
     }

     //////////////////////////////////////////////////////////////////////
     // private methods
     //////////////////////////////////////////////////////////////////////
     
     private void  doSpeechEvent ( final ClientMessage  clientMessage )
     //////////////////////////////////////////////////////////////////////
     {
       final String  ssmlString = ( String ) clientMessage.getContent ( );
       
       try
       {
         chatSpeaker.speak ( ssmlString );
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
       }
     }
     
     private void  doTextEvent ( final ClientMessage  clientMessage )
     //////////////////////////////////////////////////////////////////////
     {
       String  text = ( String ) clientMessage.getContent ( );
       
       text = text.replace (
         "<br xmlns=\"http://www.w3.org/1999/xhtml\"/>",
         "\n" );
       
       logPanel.record ( text );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }