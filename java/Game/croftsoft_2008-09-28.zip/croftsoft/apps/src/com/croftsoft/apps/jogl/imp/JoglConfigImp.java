    package com.croftsoft.apps.jogl.imp;
     
    import java.awt.*;

    import com.croftsoft.apps.jogl.JoglConfig;
    import com.croftsoft.core.CroftSoftConstants;
     
    /***********************************************************************
    * Jogl configuration.
    *  
    * Can be modified to be persistent.
    * 
    * @version
    *   $Id: JoglConfigImp.java,v 1.3 2008/09/26 23:28:05 croft Exp $
    * @since
    *   2008-02-10
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  JoglConfigImp
      implements JoglConfig
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private static final String  VERSION
      = "$Date: 2008/09/26 23:28:05 $";
   
    private static final String  TITLE
      = "CroftSoft JOGL Demo";
   
    private static final String  INFO
      = TITLE + "\n"
      + "Version " + VERSION + "\n"
      + CroftSoftConstants.COPYRIGHT + "\n"
      + CroftSoftConstants.DEFAULT_LICENSE + "\n"
      + CroftSoftConstants.HOME_PAGE + "\n";
     
    private static final int
      FRAME_WIDTH  = 600,
      FRAME_HEIGHT = 400;
   
    private static final double  UPDATE_RATE = 100.0;
     
    private static final String
      SHUTDOWN_CONFIRMATION_PROMPT = "Exit " + TITLE + "?";
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public static JoglConfigImp  load ( final String [ ]  args )
    ////////////////////////////////////////////////////////////////////////
    {
      // Could load from a persistent XML file.
      // See "Enumerated Accessors" tutorial at
      // http://www.CroftSoft.com/library/tutorials/enum/
       
      return new JoglConfigImp ( );
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public String  getInfo ( ) { return INFO; }
     
    public Dimension  getFrameSize ( )
      { return new Dimension ( FRAME_WIDTH, FRAME_HEIGHT ); }
     
    public String  getFrameTitle ( ) { return TITLE; }

    public String  getShutdownConfirmationPrompt ( )
      { return SHUTDOWN_CONFIRMATION_PROMPT; }
     
    public String  getThreadName ( ) { return TITLE; }
     
    public double  getUpdateRate ( ) { return UPDATE_RATE; }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }