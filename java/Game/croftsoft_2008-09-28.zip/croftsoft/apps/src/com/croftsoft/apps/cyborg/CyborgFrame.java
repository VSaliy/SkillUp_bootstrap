     package com.croftsoft.apps.cyborg;
     
     import java.awt.*;
     import java.awt.event.*;
     import java.awt.image.*;
     import javax.swing.*;
     import javax.swing.border.*;
     import javax.swing.event.*;
     
     import com.croftsoft.core.gui.LogPanel;
     import com.croftsoft.core.lang.NullArgumentException;
     import com.croftsoft.core.lang.lifecycle.Initializable;
     import com.croftsoft.core.lang.lifecycle.Updatable;
     
     /*********************************************************************
     * JFrame subclass.
     *  
     * @version
     *   $Date: 2008/04/19 21:30:59 $
     * @since
     *   2005-08-12
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  CyborgFrame
       extends JFrame
       implements ChangeListener, Initializable, Updatable
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
    	 
     private static final long  serialVersionUID = 0L;
     
     //
       
     private final CyborgModel       cyborgModel;
       
     private final CyborgController  cyborgController;
     
     //
     
     private final CyborgAnimator   cyborgAnimator;
       
     private final CyborgComponent  cyborgComponent;
     
     //
     
     private final SpinnerNumberModel  maxSpinnerNumberModel;
     
     private final LogPanel            logPanel;
     
     private final JCheckBox
       animateCheckBox,
       forceLengthCheckBox,
       realTimeCheckBox;
     
     private final JSlider
       gainSlider,
       offsetSlider;
     
     //
     
     private BufferedImage  bufferedImage;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  CyborgFrame (
       CyborgModel       cyborgModel,
       CyborgController  cyborgController )
     //////////////////////////////////////////////////////////////////////
     {
       super ( CyborgConfig.FRAME_TITLE );
       
       NullArgumentException.check ( this.cyborgModel = cyborgModel );
       
       NullArgumentException.check (
         this.cyborgController = cyborgController );
       
       cyborgModel.addChangeListener ( this );
/*       
       JMenuBar  jMenuBar = new JMenuBar ( );
       
       setJMenuBar ( jMenuBar );
       
       jMenuBar.add ( new JMenu ( "Test" ) );
*/
       gainSlider = new JSlider ( );
       
       offsetSlider = new JSlider ( );
       
       Container  container = getContentPane ( );
       
       container.setLayout ( new BorderLayout ( ) );
       
       cyborgComponent = new CyborgComponent ( );
       
       cyborgAnimator
         = new CyborgAnimator ( cyborgModel, cyborgComponent );
       
       cyborgComponent.setComponentAnimator ( cyborgAnimator );
       
       cyborgComponent.addMouseMotionListener ( cyborgController );
       
       JPanel  westPanel = new JPanel ( new BorderLayout ( ) );
       
       container.add ( westPanel, BorderLayout.WEST );
       
       JPanel  controlPanel = new JPanel ( new BorderLayout ( ) );
       
       westPanel.add ( controlPanel, BorderLayout.CENTER );
       
       maxSpinnerNumberModel = new SpinnerNumberModel (
         ( int ) cyborgModel.getMax ( ), 0, CyborgConfig.FRAME_RATE, 1 );
    	       
       maxSpinnerNumberModel.addChangeListener ( this );
       
       controlPanel.setLayout (
         new BoxLayout ( controlPanel, BoxLayout.Y_AXIS ) );
       
       realTimeCheckBox
         = new JCheckBox ( CyborgConfig.ACTION_COMMAND_REALTIME );
       
       animateCheckBox
         = new JCheckBox ( CyborgConfig.ACTION_COMMAND_ANIMATE );
       
       forceLengthCheckBox
         = new JCheckBox ( CyborgConfig.ACTION_COMMAND_FORCE_LENGTH );
       
       controlPanel.add ( createOptionsPanel  ( ) );
       
       controlPanel.add ( createJoystickPanel ( ) );
       
       controlPanel.add ( createButtonsPanel  ( ) );
       
       controlPanel.add ( new Box.Filler (
         new Dimension ( 0, 0 ),
         new Dimension ( 0, Integer.MAX_VALUE ),
         new Dimension ( 0, Integer.MAX_VALUE ) ) );
       
       westPanel.add( cyborgComponent, BorderLayout.EAST );
       
       JPanel  centerPanel = new JPanel ( new BorderLayout ( ) );
       
       container.add ( centerPanel, BorderLayout.CENTER );
       
       logPanel = new LogPanel ( );
       
       centerPanel.add ( createLogPanel ( ), BorderLayout.CENTER );
       
       updateView ( );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       cyborgAnimator.init ( );
     }
     
     public void  update ( )
     //////////////////////////////////////////////////////////////////////
     {
       cyborgComponent.update ( );
     }
     
     public void  stateChanged ( ChangeEvent  changeEvent )
     //////////////////////////////////////////////////////////////////////
     {       
       Object  source = changeEvent.getSource ( );
       
       if ( source == maxSpinnerNumberModel )
       {
         Object  value = maxSpinnerNumberModel.getValue ( );
         
         cyborgController.changeMax ( ( Integer ) value );
       }
       else if ( source instanceof CyborgModel )
       {
         updateView ( );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     private JPanel  createButtonsPanel ( )
     //////////////////////////////////////////////////////////////////////
     {
       JPanel  buttonsPanel = new JPanel ( new GridLayout ( 3, 1 ) );
       
       final JButton  pauseButton
         = new JButton ( CyborgConfig.ACTION_COMMAND_PAUSE );
       
       pauseButton.setActionCommand ( CyborgConfig.ACTION_COMMAND_PAUSE );
       
       pauseButton.addActionListener ( cyborgController );
       
       pauseButton.addActionListener (
         new ActionListener ( )
         {
           public void  actionPerformed ( ActionEvent  actionEvent )
           {
             String  actionCommand = actionEvent.getActionCommand ( );
             
             if ( actionCommand.equals (
               CyborgConfig.ACTION_COMMAND_PAUSE ) )
             {
               pauseButton.setActionCommand (
                 CyborgConfig.ACTION_COMMAND_RESUME );
               
               pauseButton.setText (
                 CyborgConfig.ACTION_COMMAND_RESUME );
             }
             else
             {
               pauseButton.setActionCommand (
                 CyborgConfig.ACTION_COMMAND_PAUSE );
               
               pauseButton.setText (
                 CyborgConfig.ACTION_COMMAND_PAUSE );
             }
           }
         } );
       
       buttonsPanel.add ( pauseButton );
       
       JButton  resetButton
         = new JButton ( CyborgConfig.ACTION_COMMAND_RESET );
       
       resetButton.addActionListener (
         new ActionListener ( )
         {
           public void  actionPerformed ( ActionEvent  actionEvent )
           {
             cyborgModel.reset ( );
           }
         } );
       
       buttonsPanel.add ( resetButton );
       
       JButton  clearButton = new JButton ( "Clear" );
       
       clearButton.addActionListener (
         new ActionListener ( )
         {
           public void  actionPerformed ( ActionEvent  actionEvent )
           {
             logPanel.clear ( );
           }
         } );
       
       buttonsPanel.add ( clearButton );
       
       buttonsPanel.setBorder (
         BorderFactory.createEtchedBorder ( EtchedBorder.RAISED ) );
       
       return buttonsPanel;
     }
     
     private JPanel  createJoystickPanel ( )
     //////////////////////////////////////////////////////////////////////
     {
       JPanel  joystickPanel = new JPanel ( new BorderLayout ( ) );
       
       joystickPanel.setPreferredSize ( 
         new Dimension (
           CyborgConfig.PLOT_SIZE + 2,
           0 ) );
       
       JPanel  joystickPanel1 = new JPanel ( new GridLayout ( 4, 1 ) );
       
       joystickPanel.add ( joystickPanel1, BorderLayout.NORTH );
       
       final JComboBox  jComboBox
         = new JComboBox ( CyborgConfig.JOYSTICK_TRANSFORM_OPTIONS );
       
       jComboBox.addActionListener (
         new ActionListener ( )
         {
           public void  actionPerformed ( ActionEvent  actionEvent )
           {
             cyborgController.changeTransform (
               ( String ) jComboBox.getSelectedItem ( ) );
           }
         } );
       
       String  transform = cyborgModel.getTransform ( );
       
       jComboBox.setSelectedItem ( transform );
       
       joystickPanel1.add ( jComboBox );
       
       JPanel  maxPanel = new JPanel ( );
       
       maxPanel.add ( new JLabel ( "Max" ) );
       
       JSpinner  maxSpinner = new JSpinner ( maxSpinnerNumberModel );
       
       maxPanel.add ( maxSpinner );
       
       joystickPanel1.add ( maxPanel );
       
       bufferedImage = new BufferedImage (
         CyborgConfig.PLOT_SIZE,
         CyborgConfig.PLOT_SIZE,
         BufferedImage.TYPE_INT_RGB );
   
       Icon  icon = new ImageIcon ( bufferedImage );
   
       JButton  imageButton = new JButton ( icon );
       
       imageButton.setMargin ( new Insets ( 0, 0, 0, 0 ) );
       
       imageButton.setEnabled ( false );
       
       imageButton.setDisabledIcon ( icon );
       
       imageButton.setBorder ( null );
       
       joystickPanel.add ( imageButton, BorderLayout.CENTER );
       
       JPanel  gainPanel = new JPanel ( new BorderLayout ( ) );
       
       gainPanel.add (
         new JLabel ( "Gain", JLabel.CENTER ),
         BorderLayout.NORTH );
       
       gainPanel.add ( gainSlider, BorderLayout.CENTER );
       
       gainPanel.setBorder (
         BorderFactory.createEtchedBorder ( EtchedBorder.RAISED ) );
       
       joystickPanel1.add ( gainPanel );
       
       gainSlider.addChangeListener (
         new ChangeListener ( )
         {
           public void  stateChanged ( ChangeEvent  changeEvent )
           {
             JSlider  jSlider = ( JSlider ) changeEvent.getSource ( );
             
             if ( !jSlider.getValueIsAdjusting ( ) )
             {
               cyborgController.setAlpha ( new Double (
                 jSlider.getValue ( ) / CyborgConfig.GAIN_SCALE ) );
             }       
           }
         } );
       
       JPanel  offsetPanel = new JPanel ( new BorderLayout ( ) );
       
       offsetPanel.add (
         new JLabel ( "Offset", JLabel.CENTER ), BorderLayout.NORTH );
       
       offsetPanel.add ( offsetSlider, BorderLayout.SOUTH );
       
       offsetPanel.setBorder (
         BorderFactory.createEtchedBorder ( EtchedBorder.RAISED ) );
       
       joystickPanel1.add ( offsetPanel );
       
       offsetSlider.addChangeListener (
         new ChangeListener ( )
         {
           public void  stateChanged ( ChangeEvent  changeEvent )
           {
             JSlider  jSlider = ( JSlider ) changeEvent.getSource ( );
             
             if ( !jSlider.getValueIsAdjusting ( ) )
             {
               cyborgController.setOffset ( new Double (
                 jSlider.getValue ( ) / CyborgConfig.OFFSET_SCALE ) );
             }       
           }
         } );
       
       joystickPanel.setBorder (
         BorderFactory.createEtchedBorder ( EtchedBorder.RAISED ) );
       
       return joystickPanel;
     }
     
     private JPanel  createOptionsPanel ( )
     //////////////////////////////////////////////////////////////////////
     {
       JPanel  jPanel = new JPanel ( new GridLayout ( 5, 1 ) );
       
       JRadioButton  autoRadioButton
         = new JRadioButton ( CyborgConfig.ACTION_COMMAND_AUTOMATIC );
       
       autoRadioButton.setActionCommand (
         CyborgConfig.ACTION_COMMAND_AUTOMATIC );
       
       autoRadioButton.addActionListener ( cyborgController ); 
       
       JRadioButton  manuRadioButton
         = new JRadioButton ( CyborgConfig.ACTION_COMMAND_MANUAL );
       
       manuRadioButton.setActionCommand (
         CyborgConfig.ACTION_COMMAND_MANUAL );
       
       manuRadioButton.addActionListener ( cyborgController ); 
       
       ButtonGroup  buttonGroup = new ButtonGroup ( );
       
       buttonGroup.add ( autoRadioButton );
       
       buttonGroup.add ( manuRadioButton );
       
       jPanel.add ( autoRadioButton );
       
       jPanel.add ( manuRadioButton );
       
       realTimeCheckBox.setActionCommand (
         CyborgConfig.ACTION_COMMAND_REALTIME );
       
       realTimeCheckBox.addActionListener ( cyborgController );
       
       jPanel.add ( realTimeCheckBox );
       
       animateCheckBox.setActionCommand (
         CyborgConfig.ACTION_COMMAND_ANIMATE );
       
       animateCheckBox.addActionListener ( cyborgController );
       
       jPanel.add ( animateCheckBox );
       
       forceLengthCheckBox.setActionCommand (
         CyborgConfig.ACTION_COMMAND_FORCE_LENGTH );
       
       forceLengthCheckBox.addActionListener ( cyborgController );
       
       jPanel.add ( forceLengthCheckBox );
       
       jPanel.setBorder (
         BorderFactory.createEtchedBorder ( EtchedBorder.RAISED ) );
       
       autoRadioButton.setSelected ( true );
       
       return jPanel;       
     }
     
     private JScrollPane  createLogPanel ( )
     //////////////////////////////////////////////////////////////////////
     {
       CyborgConfig.INSTANCE.setLog ( logPanel );
       
       logPanel.record ( CyborgConfig.INFO );
       
       JScrollPane  jScrollPane = new JScrollPane ( logPanel );
       
       jScrollPane.setBorder (
         BorderFactory.createEtchedBorder ( EtchedBorder.RAISED ) );
       
       return jScrollPane;
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     private void  updateView ( )
     //////////////////////////////////////////////////////////////////////
     {
       animateCheckBox.setSelected ( cyborgModel.getAnimate ( ) );
       
       gainSlider.setValue ( ( int ) Math.round (
         CyborgConfig.GAIN_SCALE * cyborgModel.getAlpha ( ) ) );
       
       offsetSlider.setValue ( ( int ) Math.round (
         CyborgConfig.OFFSET_SCALE * cyborgModel.getOffset ( ) ) );
       
       realTimeCheckBox.setSelected ( cyborgModel.getRealTime ( ) );
       
       forceLengthCheckBox.setSelected ( cyborgModel.getForceLength ( ) );
       
       updateImageButton ( );
     }
     
     private void  updateImageButton ( )
     //////////////////////////////////////////////////////////////////////
     {
       if ( bufferedImage == null )
       {
         return;
       }
       
       for ( int  x = 0; x < CyborgConfig.PLOT_SIZE; x++ )
       {
         for ( int  y = 0; y < CyborgConfig.PLOT_SIZE; y++ )
         {
           bufferedImage.setRGB ( x, y, 0 );
         }
       }
       
       for ( int  x = 0; x < CyborgConfig.PLOT_SIZE; x++ )
       {
         double  control
           = ( 2.0 * x / ( CyborgConfig.PLOT_SIZE - 1.0 ) ) - 1.0;
         
         double  percent = cyborgModel.transform ( control );
         
         int  y = ( CyborgConfig.PLOT_SIZE - 1 ) - ( int )
           ( Math.round ( ( CyborgConfig.PLOT_SIZE - 1 ) * percent ) );
         
         // System.out.println ( percent + " " + x + " " + y );
         
         if ( ( y > -1 ) && ( y < CyborgConfig.PLOT_SIZE ) )
         {         
           bufferedImage.setRGB ( x, y, 0xFFFF00 );
         }
       }
       
       repaint ( );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }