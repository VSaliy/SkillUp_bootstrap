     package com.croftsoft.apps.slideshow;

     import java.awt.*;
     import java.awt.event.*;
     import java.io.*;
     import java.util.*;
     import java.util.logging.*;
     import javax.imageio.*;
     import javax.swing.JComponent;

     import com.croftsoft.core.animation.ComponentAnimator;
     import com.croftsoft.core.awt.image.ImageLib;
     import com.croftsoft.core.lang.NullArgumentException;

     /*********************************************************************
     * ComponentAnimator.
     *
     * @version
     *   $Date: 2008/04/19 21:31:00 $
     * @since
     *   2005-08-12
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  SlideshowAnimator
       implements ComponentAnimator
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final String  CLASS_NAME
       = SlideshowAnimator.class.getName ( );
     
     //
       
     private final Logger           logger;
    	 
     private final SlideshowConfig  slideshowConfig;
       
     private final Rectangle        componentBounds;
     
     private final Random           random;
     
     //
     
     private boolean  skip;
     
     private long     lastTimeNanos;
     
     private Image    image;
     
     private String   imageFilename;
     
     //////////////////////////////////////////////////////////////////////
     // constructor methods
     //////////////////////////////////////////////////////////////////////

     /*********************************************************************
     * Main constructor.
     *********************************************************************/
     public  SlideshowAnimator (
       final SlideshowConfig  slideshowConfig,
       final JComponent       jComponent )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.checkArgs (
         this.slideshowConfig = slideshowConfig,
         jComponent );
       
       logger = Logger.getLogger ( CLASS_NAME );
       
       componentBounds = new Rectangle ( );
       
       random = new Random ( );
       
       jComponent.setOpaque ( true );
       
       jComponent.setFont ( slideshowConfig.getFont ( ) );

       jComponent.addKeyListener (
         new KeyAdapter ( )
         {
           @Override
           public void  keyPressed ( final KeyEvent  keyEvent )
           {
             final int  keyCode = keyEvent.getKeyCode ( );

             if ( keyCode == KeyEvent.VK_SPACE )
             {
               logger.info ( "spacebar pressed" );

               skip = true;
             }
           }
         } );

       jComponent.requestFocus ( );
/*       
       jComponent.addComponentListener (
         new ComponentAdapter ( )
         {
           @Override
           public void  componentResized ( ComponentEvent  componentEvent )
           {
             update ( jComponent );
    	             
             jComponent.repaint ( );
           }
         } );
*/       
       update ( jComponent );       
     }
     
     //////////////////////////////////////////////////////////////////////
     // interface ComponentAnimator methods
     //////////////////////////////////////////////////////////////////////
     
     public void  paint (
       final JComponent  jComponent,
       final Graphics2D  graphics2D )
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         jComponent.getBounds ( componentBounds );
       
         graphics2D.setColor ( slideshowConfig.getBackgroundColor ( ) );
           
         graphics2D.fill ( componentBounds );
       
         if ( image != null )
         {
           final Rectangle  rectangle = ImageLib.shrinkToFitAndCenter (
             image.getWidth  ( null ),
             image.getHeight ( null ),
             componentBounds.width,
             componentBounds.height );

           // logger.info ( rectangle.toString ( ) );
             
           graphics2D.drawImage (
             image,
             rectangle.x,
             rectangle.y,
             rectangle.width,
             rectangle.height,
             null );
         }

         if ( ( imageFilename != null )
           && slideshowConfig.getDisplayImageFilename ( ) )
         {
           graphics2D.setColor ( slideshowConfig.getForegroundColor ( ) );

           graphics2D.drawString ( imageFilename, 20, 20 );
         }
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
         
         logger.throwing ( CLASS_NAME, "paint", ex );
       }
     }
     
     public void  update ( final JComponent  jComponent )
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         final long  currentTimeNanos = System.nanoTime ( );

         final long  deltaTimeNanos = currentTimeNanos - lastTimeNanos;
         
         final long  displayTimeNanos
           = slideshowConfig.getDisplayTimeNanos ( ); 

         if ( skip
           || ( deltaTimeNanos >= displayTimeNanos ) )
         {
           // logger.info ( "update changing image" );
         
           skip = false;

           final String [ ]  imageFilenames
             = slideshowConfig.getImageFilenames ( );

           if ( ( imageFilenames != null    )
             && ( imageFilenames.length > 0 ) )
           {
             lastTimeNanos = currentTimeNanos;
             
             final int  imageIndex
               = random.nextInt ( imageFilenames.length );

             imageFilename = imageFilenames [ imageIndex ];

             logger.info ( imageFilename );
             
             final File  imageFile = new File ( imageFilename );

             image = ImageIO.read ( imageFile );             
           }
         }
         
         jComponent.paintImmediately ( componentBounds );
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
         
         logger.throwing ( CLASS_NAME, "update", ex );
       }
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }
