    package com.croftsoft.apps.exemplar;
     
    import java.awt.*;
    import javax.swing.*;
    
    import com.croftsoft.core.gui.LifecycleWindowListener;
    import com.croftsoft.core.lang.lifecycle.Lifecycle;
    import com.croftsoft.core.lang.lifecycle.LifecycleLib;
    import com.croftsoft.core.lang.lifecycle.Updatable;
    import com.croftsoft.core.util.loop.EventQueueUpdateLoop;
    import com.croftsoft.core.util.loop.Looper;
    import com.croftsoft.core.util.loop.NanoTimeLoopGovernor;
    import com.croftsoft.core.util.mail.FlipMail;
     
    /***********************************************************************
    * Main.
    *
    * Launches the application within a framework.
    * 
    * @version
    *   $Id: ExemplarMain.java,v 1.8 2008/02/18 23:22:49 croft Exp $
    * @since
    *   2006-01-03
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  ExemplarMain
      implements Lifecycle
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private final ExemplarConfig      exemplarConfig;
     
    private final ExemplarModelImp    exemplarModelImp;
     
    private final ExemplarController  exemplarController;
       
    private final ExemplarView        exemplarView;
     
    private final Looper              looper;
       
    ////////////////////////////////////////////////////////////////////////
    // public static methods
    ////////////////////////////////////////////////////////////////////////

    public static void  main ( final String [ ]  args )
    ////////////////////////////////////////////////////////////////////////
    {
      final ExemplarMain  exemplarMain = new ExemplarMain ( args );
       
      final JFrame  jFrame = new JFrame (
        exemplarMain.exemplarConfig.getFrameTitle ( ) );
       
      exemplarMain.setContentPane ( jFrame.getContentPane ( ) );
       
      // The Frame is the framework.
       
      LifecycleWindowListener.launchFrameAsDesktopApp (
        jFrame,
        exemplarMain,
        exemplarMain.exemplarConfig.getFrameSize ( ),
        exemplarMain.exemplarConfig.getShutdownConfirmationPrompt ( ) );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // constructor methods
    ////////////////////////////////////////////////////////////////////////
     
    public  ExemplarMain ( final String [ ]  args )
    ////////////////////////////////////////////////////////////////////////
    {
      exemplarConfig = ExemplarConfigImp.load ( args );
       
      System.out.println ( "\n" + exemplarConfig.getInfo ( ) );
      
      final FlipMail<ExemplarMessage>  flipMail
        = new FlipMail<ExemplarMessage> ( );
       
      exemplarModelImp = new ExemplarModelImp (
        exemplarConfig,
        flipMail );
       
      exemplarController = new ExemplarController ( flipMail );
       
      exemplarView = new ExemplarView (
        exemplarConfig,
        flipMail,
        exemplarModelImp );
       
      exemplarView.addMouseListener ( exemplarController );
       
      final Updatable [ ]  updatables = new Updatable [ ] {
        flipMail,
        exemplarModelImp,
        exemplarView,
        exemplarController };
       
      looper = new Looper (
        new EventQueueUpdateLoop ( updatables ), // loopable
        new NanoTimeLoopGovernor ( exemplarConfig.getUpdateRate ( ) ),
        null, // exceptionHandler
        exemplarConfig.getThreadName ( ),
        Thread.MIN_PRIORITY,
        true ); // useDaemonThread
    }
     
    ////////////////////////////////////////////////////////////////////////
    // accessor methods
    ////////////////////////////////////////////////////////////////////////
     
    public ExemplarConfig  getExemplarConfig ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return exemplarConfig;
    }
     
    ////////////////////////////////////////////////////////////////////////
    // mutator methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  setContentPane ( final Container  contentPane )
    ////////////////////////////////////////////////////////////////////////
    {
      exemplarView.setContentPane ( contentPane );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // interface Lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.init ( exemplarView, looper );
    }
     
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.start (
        exemplarView, exemplarController, exemplarModelImp, looper );
    }
     
    public void  stop ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.stop ( exemplarView, looper );
    }
     
    public void  destroy ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.destroy ( exemplarView, looper );
    }     
       
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }