    package com.croftsoft.apps.jogl;
     
    import java.util.*;

    /***********************************************************************
    * Request to move in a given direction.
    * 
    * @version
    *   $Id: JoglMoveState.java,v 1.5 2008/04/19 23:52:10 croft Exp $
    * @since
    *   2008-02-10
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  JoglMoveState
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
      
    public enum  EnumDirection
    {
      BACKWARD,
      DOWN,
      FORWARD,
      LEFT,
      PITCH_DOWN,
      PITCH_UP,
      RIGHT,
      ROLL_LEFT,
      ROLL_RIGHT,
      UP,
      YAW_LEFT,
      YAW_RIGHT
    }
    
    private final EnumSet<EnumDirection>  enumSet;
      
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public JoglMoveState ( )
    ////////////////////////////////////////////////////////////////////////
    {
      enumSet = EnumSet.noneOf ( EnumDirection.class );
    }
    
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    
    public void  clear ( )
    ////////////////////////////////////////////////////////////////////////
    {
      enumSet.clear ( );
    }
    
    public boolean  get ( final EnumDirection  enumDirection )
    ////////////////////////////////////////////////////////////////////////
    {
      return enumSet.contains ( enumDirection );
    }
    
    public void  set (
      final EnumDirection  enumDirection,
      final boolean        flag )
    ////////////////////////////////////////////////////////////////////////
    {
      if ( flag )
      {
        enumSet.add ( enumDirection );
      }
      else
      {
        enumSet.remove ( enumDirection );
      }
    }
      
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }