    package com.croftsoft.apps.jogl.imp;

    import javax.media.opengl.GL;
    import javax.media.opengl.glu.GLU;

    import com.croftsoft.core.lang.NullException;
    import com.croftsoft.core.math.axis.AxisAngle;
    import com.croftsoft.core.media.jogl.JoglLib;
    import com.croftsoft.core.media.jogl.JoglRenderer;
    import com.croftsoft.core.media.jogl.camera.JoglCamera;
    import com.croftsoft.core.media.jogl.render.JoglFrameRate;
    import com.croftsoft.core.media.jogl.render.JoglSpinCube;

    import com.croftsoft.apps.jogl.JoglModel;

    /***********************************************************************
    * ComponentAnimator.
    *
    * @version
    *   $Date: 2008/05/17 01:32:31 $
    * @since
    *   2005-08-12
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/
    
    public final class  JoglRendererImp
      implements JoglRenderer
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
      
    private final JoglModel         joglModel;
    
    private final JoglRenderer [ ]  joglRenderers;
    
    ////////////////////////////////////////////////////////////////////////
    // constructor methods
    ////////////////////////////////////////////////////////////////////////

    /***********************************************************************
    * Main constructor.
    ***********************************************************************/
    public  JoglRendererImp ( final JoglModel  joglModel )
    ////////////////////////////////////////////////////////////////////////
    {
      NullException.check ( this.joglModel = joglModel );
      
      final JoglFrameRate  joglFrameRate = new JoglFrameRate ( );
      
      joglFrameRate.setOffsetX ( 10 );
      
      joglFrameRate.setOffsetY ( 10 );
      
      joglRenderers = new JoglRenderer [ ] {
        new JoglSpinCube ( joglModel.getJoglSpinCubeModel ( ) ),
        joglFrameRate };
    }
     
    ////////////////////////////////////////////////////////////////////////
    // interface GLEventListener methods
    ////////////////////////////////////////////////////////////////////////

    public void init ( final GL  gl )
    ////////////////////////////////////////////////////////////////////////
    {
      JoglLib.printInfo ( gl );
       
      gl.glClearColor ( 0f, 0f, 0f, 0f );
      
      for ( final JoglRenderer  joglRenderer : joglRenderers )
      {
        joglRenderer.init ( gl );
      }
       
      JoglLib.checkError ( gl );      
    }

    public void  destroy ( final GL  gl )
    ////////////////////////////////////////////////////////////////////////
    {
      System.out.println ( getClass ( ).getName ( ) + ".destroy()" );
      
      for ( final JoglRenderer  joglRenderer : joglRenderers )
      {
        joglRenderer.destroy ( gl );
      }
       
      JoglLib.checkError ( gl );      
    }
    
    public void  setBounds (
      final GL   gl,
      final int  x,
      final int  y,
      final int  width,
      final int  height )
    ////////////////////////////////////////////////////////////////////////
    {
      for ( final JoglRenderer  joglRenderer : joglRenderers )
      {
        joglRenderer.setBounds ( gl, x, y, width, height );
      }
      
      gl.glViewport ( x, y, width, height );

      gl.glMatrixMode ( GL.GL_PROJECTION );

      gl.glLoadIdentity ( );

      new GLU ( ).gluPerspective (
        45.0,
        ( double ) width / ( double ) height,
        1,
        100 );

      JoglLib.checkError ( gl );
    }

    public void  render ( final GL  gl )
    ////////////////////////////////////////////////////////////////////////
    {
      gl.glClear (
          GL.GL_COLOR_BUFFER_BIT
        | GL.GL_DEPTH_BUFFER_BIT );
      
      gl.glMatrixMode ( GL.GL_MODELVIEW );
      
      gl.glLoadIdentity ( );
      
      final JoglCamera  joglCamera = joglModel.getJoglCamera ( );
      
      final AxisAngle  axisAngle = joglCamera.getAxisAngle ( );

      gl.glRotated (
        -axisAngle.getDegrees ( ),
        axisAngle.getX ( ),
        axisAngle.getY ( ),
        axisAngle.getZ ( ) );
      
      gl.glTranslated (
        -joglCamera.getX ( ),
        -joglCamera.getY ( ),
        -joglCamera.getZ ( ) );

      for ( final JoglRenderer  joglRenderer : joglRenderers )
      {
        joglRenderer.render ( gl );
      }

      JoglLib.checkError ( gl );
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }
