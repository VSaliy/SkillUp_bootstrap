    package com.croftsoft.apps.neuro;
     
    import com.croftsoft.core.lang.NullArgumentException;
     
    /***********************************************************************
    * Neuro enumerated type message.
    * 
    * Use to pass messages between the model, view, and controller.
    * 
    * @version
    *   $Id: NeuroMessage.java,v 1.4 2008/08/30 01:37:30 croft Exp $
    * @since
    *   2008-08-17
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  NeuroMessage
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    public static final NeuroMessage
      TOGGLE_CHANNEL_REQUEST_INSTANCE
        = new NeuroMessage ( Type.TOGGLE_CHANNEL_REQUEST ),
      TOGGLE_FRAME_RATE_REQUEST_INSTANCE
        = new NeuroMessage ( Type.TOGGLE_FRAME_RATE_REQUEST ),
      TOGGLE_PAUSE_REQUEST_INSTANCE
        = new NeuroMessage ( Type.TOGGLE_PAUSE_REQUEST );
     
    //
     
    public enum  Type
    {
      TOGGLE_CHANNEL_REQUEST,
      TOGGLE_FRAME_RATE_REQUEST,
      TOGGLE_PAUSE_REQUEST
    }
     
    //
       
    private final Type    type;
     
    private final Object  content;
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public  NeuroMessage (
      final Type    type,
      final Object  content )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.check ( this.type = type );
       
      this.content = content;
    }
     
    public  NeuroMessage ( final Type  type )
    ////////////////////////////////////////////////////////////////////////
    {
      this ( type, null );
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public Type    getType    ( ) { return type;    }
     
    public Object  getContent ( ) { return content; }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }