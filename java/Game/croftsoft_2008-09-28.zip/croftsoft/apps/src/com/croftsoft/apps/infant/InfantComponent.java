     package com.croftsoft.apps.infant;

     import java.awt.*;
     import java.awt.event.*;
     import javax.swing.*;

     import com.croftsoft.core.animation.painter.*;
     import com.croftsoft.core.lang.NullArgumentException;

     /*********************************************************************
     * Animated Swing component.
     *
     * @version
     *   $Date: 2007/02/25 03:17:05 $
     * @since
     *   2005-08-12
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  InfantComponent
       extends JComponent
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final long  serialVersionUID = 0L;
     
     private static final ColorPainter  BACKGROUND_COLOR_PAINTER
       = new ColorPainter ( Color.WHITE );
     
     //
     
     private final InfantAccessor  infantAccessor;
     
     private final ScalePainter    scalePainter;
     
     //////////////////////////////////////////////////////////////////////
     // constructor methods
     //////////////////////////////////////////////////////////////////////

     /*********************************************************************
     * Main constructor.
     *********************************************************************/
     public  InfantComponent (
       final InfantConfig    infantConfig,
       final InfantAccessor  infantAccessor )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.checkArgs (
         infantConfig,
         this.infantAccessor = infantAccessor );
         
       setOpaque ( true );
       
       setBackground ( infantConfig.getBackgroundColor ( ) );
       
       setForeground ( infantConfig.getForegroundColor ( ) );
       
       setFont ( infantConfig.getFont ( ) );
       
       setCursor ( infantConfig.getCursor ( ) );
       
       requestFocus ( );
       
       scalePainter = new ScalePainter ( );
       
       addComponentListener (
         new ComponentAdapter ( )
         {
           @Override
           public void  componentResized ( ComponentEvent  componentEvent )
           {
             setImage ( scalePainter.getImage ( ) );
           }
         } );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  setImage ( final Image  image )
     //////////////////////////////////////////////////////////////////////
     {
       scalePainter.setImage ( image );
       
       paintImmediately ( getVisibleRect ( ) );
     }

     //////////////////////////////////////////////////////////////////////
     // overridden JComponent methods
     //////////////////////////////////////////////////////////////////////

     @Override
     public void  paintComponent ( final Graphics  graphics )
     //////////////////////////////////////////////////////////////////////
     {
       final Graphics2D  graphics2D = ( Graphics2D ) graphics;
       
       BACKGROUND_COLOR_PAINTER.paint ( this, graphics2D );
       
       scalePainter.setScale ( infantAccessor.getScale ( ) );
       
       scalePainter.paint ( this, graphics2D );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }