    package com.croftsoft.apps.jogl;
     
    import java.awt.*;
    import java.awt.event.*;

    import javax.media.opengl.*;

    import com.croftsoft.core.lang.NullArgumentException;
    import com.croftsoft.core.lang.lifecycle.Lifecycle;
    import com.croftsoft.core.lang.lifecycle.Updatable;
    import com.croftsoft.core.media.jogl.JoglAdapter;
    import com.croftsoft.core.util.seq.Seq;

    import com.croftsoft.apps.jogl.imp.JoglRendererImp;
    
    /***********************************************************************
    * Jogl view.
    *  
    * @version
    *   $Id: JoglView.java,v 1.19 2008/05/17 00:18:02 croft Exp $
    * @since
    *   2008-02-10
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  JoglView
      implements Lifecycle, Updatable
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
    	 
    private final Seq<JoglMessage>  eventSeq;
     
    private final GLCanvas          glCanvas;
    
    private final JoglAdapter       joglAdapter;
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public  JoglView (
      final Seq<JoglMessage>  eventSeq,
      final JoglModel         joglModel )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        this.eventSeq = eventSeq,
        joglModel );
      
      final GLCapabilities  glCapabilities = new GLCapabilities ( );
      
      glCanvas = new GLCanvas ( glCapabilities );
      
      joglAdapter = new JoglAdapter ( new JoglRendererImp ( joglModel ) );
      
      glCanvas.addGLEventListener ( joglAdapter );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // mutator methods
    ////////////////////////////////////////////////////////////////////////
    
    public void  addKeyListener ( final KeyListener  keyListener )
    ////////////////////////////////////////////////////////////////////////
    {
      glCanvas.addKeyListener ( keyListener );
    }
     
    public void  addMouseListener ( final MouseListener  mouseListener )
    ////////////////////////////////////////////////////////////////////////
    {
      glCanvas.addMouseListener ( mouseListener );
    }
     
    public void  setContentPane ( final Container  contentPane )
    ////////////////////////////////////////////////////////////////////////
    {
      contentPane.setLayout ( new BorderLayout ( ) );
       
      contentPane.add ( glCanvas, BorderLayout.CENTER );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      // System.out.println ( "JoglView.init()" );
      
      glCanvas.requestFocus ( );
    }
     
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      // System.out.println ( "JoglView.start()" );
    }
     
    public void  stop ( )
    ////////////////////////////////////////////////////////////////////////
    {
      // System.out.println ( "JoglView.stop()" );       
    }
     
    public void  destroy ( )
    ////////////////////////////////////////////////////////////////////////
    {
      // System.out.println ( "JoglView.destroy()" );
    }
     
    public void  update ( )
    ////////////////////////////////////////////////////////////////////////
    {
      final int  size = eventSeq.size ( );
      
      for ( int  i = 0; i < size; i++ )
      {
        final JoglMessage  joglMessage = eventSeq.get ( i );

        final JoglMessage.Type  type = joglMessage.getType ( );
         
        switch ( type )
        {
          case CHANGE_PERTURBATION_FACTOR_EVENT:
             
            Toolkit.getDefaultToolkit ( ).beep ( );
             
            break;
             
          default:
            
            // ignore
        }
      }
      
      glCanvas.display ( );
    }       
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }