    package com.croftsoft.apps.jogl;
     
    import java.awt.event.*;

    import com.croftsoft.apps.jogl.JoglMoveState.EnumDirection;
    import com.croftsoft.core.gui.controller.NilController;
    import com.croftsoft.core.lang.NullArgumentException;
    import com.croftsoft.core.lang.lifecycle.Startable;
    import com.croftsoft.core.util.mail.Mail;
     
    /***********************************************************************
    * Jogl controller.
    * 
    * Modifies the Model based on user input.
    * 
    * @version
    *   $Id: JoglController.java,v 1.12 2008/05/17 00:18:02 croft Exp $
    * @since
    *   2008-02-10
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  JoglController
      extends NilController
      implements Startable
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
      
    private final Mail<JoglMessage>  mail;
    
    private final JoglMoveRequest  joglMoveRequest;
    
    //
     
    private boolean
      mouseClicked,
      sendMoveRequest;
     
    ////////////////////////////////////////////////////////////////////////
    // constructor method
    ////////////////////////////////////////////////////////////////////////
     
    public  JoglController ( final Mail<JoglMessage>  mail )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs ( this.mail = mail );
      
      joglMoveRequest = new JoglMoveRequest ( );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // listener methods
    ////////////////////////////////////////////////////////////////////////     
     
    @Override
    public void  keyPressed  ( final KeyEvent  keyEvent )
    ////////////////////////////////////////////////////////////////////////     
    {
      processKeyEvent ( keyEvent, true );
    }
    
    @Override
    public void  keyReleased  ( final KeyEvent  keyEvent )
    ////////////////////////////////////////////////////////////////////////     
    {
      processKeyEvent ( keyEvent, false );
    }
    
    @Override
    public void  mouseClicked ( final MouseEvent  mouseEvent )
    ////////////////////////////////////////////////////////////////////////
    {
      mouseClicked = true;
    }
     
    @Override
    public void  mouseMoved ( final MouseEvent  mouseEvent )
    ////////////////////////////////////////////////////////////////////////
    {
      //mouseMoved = true;
    }
     
    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      mouseClicked = false;
    }
     
    @Override
    public void  update ( )
    ////////////////////////////////////////////////////////////////////////
    {
      if ( sendMoveRequest )
      {
        sendMoveRequest = !mail.offer ( joglMoveRequest );
      }
      
      if ( mouseClicked )
      {
        mouseClicked = !mail.offer (
          JoglMessage.CHANGE_PERTURBATION_FACTOR_REQUEST_INSTANCE );
      }
    }
     
    ////////////////////////////////////////////////////////////////////////
    // private methods
    ////////////////////////////////////////////////////////////////////////
    
    private EnumDirection  getEnumDirection ( final KeyEvent  keyEvent )
    ////////////////////////////////////////////////////////////////////////
    {
      final int  keyCode = keyEvent.getKeyCode ( );
      
      final boolean  shiftDown = keyEvent.isShiftDown ( );
      
      switch ( keyCode )
      {
        case KeyEvent.VK_A:
          
          return EnumDirection.LEFT;
            
        case KeyEvent.VK_D:
          
          return EnumDirection.RIGHT;
          
        case KeyEvent.VK_W:
          
          return EnumDirection.FORWARD;
          
        case KeyEvent.VK_S:
          
          return EnumDirection.BACKWARD;
          
        case KeyEvent.VK_UP:
          
          if ( shiftDown )
          {
            return EnumDirection.PITCH_DOWN;
          }
          
          return EnumDirection.UP;
          
        case KeyEvent.VK_DOWN:
          
          if ( shiftDown )
          {
            return EnumDirection.PITCH_UP;
          }
          
          return EnumDirection.DOWN;
          
        case KeyEvent.VK_LEFT:
          
          if ( shiftDown )
          {
            return EnumDirection.ROLL_LEFT;
          }
          
          return EnumDirection.YAW_LEFT;

        case KeyEvent.VK_RIGHT:
          
          if ( shiftDown )
          {
            return EnumDirection.ROLL_RIGHT;
          }
          
          return EnumDirection.YAW_RIGHT;
          
        default:
          
          return null;
      }
    }
    
    private void  processKeyEvent (
      final KeyEvent  keyEvent,
      final boolean   keyPressed )
    ////////////////////////////////////////////////////////////////////////     
    {
      final EnumDirection  enumDirection = getEnumDirection ( keyEvent );
      
      if ( enumDirection != null )
      {
        joglMoveRequest.set ( enumDirection, keyPressed );
        
        sendMoveRequest = true;
      }
    }
    
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }