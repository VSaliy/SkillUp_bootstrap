     package com.croftsoft.apps.cyborg;
     
     import java.awt.*;
     import java.awt.event.*;

     import com.croftsoft.core.gui.controller.NilController;
     import com.croftsoft.core.lang.NullArgumentException;
     
     /*********************************************************************
     * Receives and processes user input.
     * 
     * @version
     *   $Id: CyborgController.java,v 1.20 2008/04/19 21:30:58 croft Exp $
     * @since
     *   2005-03-16
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  CyborgController
       extends NilController
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private final CyborgModel     cyborgModel;
     
     private final CyborgOperator  cyborgOperator;
     
     //
     
     private String   actionCommand;
     
     private Integer  max;
     
     private Point    point;
     
     private String   transform;
     
     private Double
       alpha,
       offset;
     
     //
     
     private boolean  manual;
     
     private double   x;
     
     private double   y;
       
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  CyborgController (
       CyborgModel     cyborgModel,
       CyborgOperator  cyborgOperator )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.check ( this.cyborgModel = cyborgModel );
       
       NullArgumentException.check (
         this.cyborgOperator = cyborgOperator );
       
       point = new Point ( );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  changeMax ( Integer  max )
     //////////////////////////////////////////////////////////////////////
     {
       this.max = max;
     }
     
     public void  setAlpha ( Double  alpha )
     //////////////////////////////////////////////////////////////////////
     {
       this.alpha = alpha;
     }
     
     public void  setOffset ( Double  offset )
     //////////////////////////////////////////////////////////////////////
     {
       this.offset = offset;
     }
     
     public void  changeTransform ( String  transform )
     //////////////////////////////////////////////////////////////////////
     {
       this.transform = transform;
     }
     
     public void  actionPerformed ( ActionEvent  actionEvent )
     //////////////////////////////////////////////////////////////////////
     {
       actionCommand = actionEvent.getActionCommand ( );
     }
     
     public void  mouseMoved ( MouseEvent  mouseEvent )
     //////////////////////////////////////////////////////////////////////
     {
       point = mouseEvent.getPoint ( );
     }
     
     public void  update ( )
     //////////////////////////////////////////////////////////////////////
     {
       if ( alpha != null )
       {
         cyborgModel.setAlpha ( alpha.doubleValue ( ) );
         
         alpha = null;
       }
       
       if ( offset != null )
       {
         cyborgModel.setOffset ( offset.doubleValue ( ) );
         
         offset = null;
       }
       
       if ( max != null )
       {
         cyborgModel.setMax ( max.intValue ( ) );
         
         max = null;
       }
       
       if ( actionCommand != null )
       {
         if ( actionCommand.equals (
           CyborgConfig.ACTION_COMMAND_ANIMATE ) )
         {
           cyborgModel.setAnimate ( !cyborgModel.getAnimate ( ) );
         }
         else if ( actionCommand.equals (
           CyborgConfig.ACTION_COMMAND_AUTOMATIC ) )
         {
           manual = false;
           
           CyborgConfig.INSTANCE.getLog ( ).record ( actionCommand );
           
           cyborgModel.reset ( );
         }
         else if ( actionCommand.equals (
           CyborgConfig.ACTION_COMMAND_FORCE_LENGTH ) )
         {
           cyborgModel.setForceLength ( !cyborgModel.getForceLength ( ) );
           
           cyborgModel.reset ( );
         }
         else if ( actionCommand.equals (
           CyborgConfig.ACTION_COMMAND_MANUAL ) )
         {
           manual = true;
           
           CyborgConfig.INSTANCE.getLog ( ).record ( actionCommand );
           
           cyborgModel.reset ( );
         }
         else if ( actionCommand.equals (
           CyborgConfig.ACTION_COMMAND_PAUSE ) )
         {
           cyborgModel.setPaused ( true );
         }
         else if ( actionCommand.equals (
           CyborgConfig.ACTION_COMMAND_RESUME ) )
         {
           cyborgModel.setPaused ( false );
         }
         else if ( actionCommand.equals (
           CyborgConfig.ACTION_COMMAND_REALTIME ) )
         {
           cyborgModel.setRealTime ( !cyborgModel.getRealTime ( ) );
         }
         
         actionCommand = null;
       }
       
       if ( transform != null )
       {
         cyborgModel.setTransform ( transform );
           
         transform = null;
       }
       
       if ( !manual )
       {
         cyborgOperator.update ( );
         
         return;
       }
       
       if ( point == null )
       {
         return;
       }
       
       x = CyborgAnimator.toX ( point.x );
       
       y = CyborgAnimator.toY ( point.y );
       
       if ( x < -1.0 )
       {
         x = -1.0;
       }
       else if ( x > 1.0 )
       {
         x = 1.0;
       }
       
       if ( y < -1.0 )
       {
         y = -1.0;
       }
       else if ( y > 1.0 )
       {
         y = 1.0;
       }
       
       cyborgModel.setAimX ( x );
       
       cyborgModel.setAimY ( y );
       
       point = null;
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }