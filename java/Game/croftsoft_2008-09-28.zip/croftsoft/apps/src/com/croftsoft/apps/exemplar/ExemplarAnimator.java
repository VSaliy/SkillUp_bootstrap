    package com.croftsoft.apps.exemplar;

    import java.awt.*;
    import java.awt.event.ComponentAdapter;
    import java.awt.event.ComponentEvent;
    import javax.swing.JComponent;

    import com.croftsoft.core.animation.ComponentAnimator;
    import com.croftsoft.core.animation.animator.FrameRateAnimator;
    import com.croftsoft.core.lang.NullArgumentException;

    /***********************************************************************
    * ComponentAnimator.
    *
    * @version
    *   $Date: 2008/02/15 22:38:03 $
    * @since
    *   2005-08-12
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  ExemplarAnimator
      implements ComponentAnimator
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
    	 
    private final ExemplarConfig     exemplarConfig;
       
    private final ExemplarModel      exemplarModel;
     
    private final Rectangle          componentBounds;
     
    private final FrameRateAnimator  frameRateAnimator;
     
    //
     
    private String  text;
     
    private int     x, y;

    ////////////////////////////////////////////////////////////////////////
    // constructor methods
    ////////////////////////////////////////////////////////////////////////

    /***********************************************************************
    * Main constructor.
    ***********************************************************************/
    public  ExemplarAnimator (
      final ExemplarConfig  exemplarConfig,
      final ExemplarModel   exemplarModel,
      final JComponent      jComponent )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        this.exemplarConfig   = exemplarConfig,
        this.exemplarModel = exemplarModel,
        jComponent );
       
      componentBounds = new Rectangle ( );
       
      jComponent.setOpaque ( true );
       
      jComponent.setFont ( exemplarConfig.getFont ( ) );
         
      jComponent.setCursor ( exemplarConfig.getCursor ( ) );
       
      jComponent.requestFocus ( );
       
      jComponent.addComponentListener (
        new ComponentAdapter ( )
        {
          @Override
          public void  componentResized ( ComponentEvent  componentEvent )
          {
            update ( jComponent );
    	             
            jComponent.repaint ( );
          }
        } );
       
      frameRateAnimator = new FrameRateAnimator ( jComponent );
       
      update ( jComponent );       
    }
     
    ////////////////////////////////////////////////////////////////////////
    // interface ComponentAnimator methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  paint (
      final JComponent  jComponent,
      final Graphics2D  graphics2D )
    ////////////////////////////////////////////////////////////////////////
    {
      graphics2D.setColor ( exemplarConfig.getBackgroundColor ( ) );
       
      graphics2D.fill ( componentBounds );
       
      graphics2D.setColor ( exemplarConfig.getForegroundColor ( ) );
       
      graphics2D.drawString ( text, x, y );
       
      frameRateAnimator.paint ( jComponent, graphics2D );
    }
     
    public void  update ( final JComponent  jComponent )
    ////////////////////////////////////////////////////////////////////////
    {
      jComponent.getBounds ( componentBounds );
         
      final int  offsetX = componentBounds.width  / 2;
         
      final int  offsetY = componentBounds.height / 2;
         
      final int  radius = Math.min ( offsetX, offsetY ) / 2;
    
      text = "Clicks:  " + exemplarModel.getClickCount ( );
         
      x = offsetX + ( int ) Math.round (
        radius * Math.sin ( exemplarModel.getPhase ( ) ) );
         
      y = offsetY + ( int ) Math.round (
        radius * Math.cos ( exemplarModel.getPhase ( ) ) );
         
      frameRateAnimator.update ( jComponent );

      jComponent.paintImmediately ( componentBounds );
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }
