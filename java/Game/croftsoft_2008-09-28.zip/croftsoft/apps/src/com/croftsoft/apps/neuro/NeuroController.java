    package com.croftsoft.apps.neuro;
     
    import java.awt.event.*;

    import com.croftsoft.core.gui.controller.NilController;
    import com.croftsoft.core.lang.NullArgumentException;
    import com.croftsoft.core.lang.lifecycle.Startable;
import com.croftsoft.core.util.slot.Slot;

    /***********************************************************************
    * Neuro controller.
    * 
    * Modifies the Model based on user input.
    * 
    * @version
    *   $Id: NeuroController.java,v 1.5 2008/09/20 05:01:49 croft Exp $
    * @since
    *   2008-08-17
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  NeuroController
      extends NilController
      implements Startable
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private final Slot<NeuroMessage>  requestSlot;
     
    //
     
    private boolean
      keyFPressed,
      mouseClicked,
      spacePressed;
     
    ////////////////////////////////////////////////////////////////////////
    // constructor method
    ////////////////////////////////////////////////////////////////////////
     
    public  NeuroController ( final Slot<NeuroMessage>  requestSlot )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs ( this.requestSlot = requestSlot );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // listener methods
    ////////////////////////////////////////////////////////////////////////
    
    @Override
    public void  keyPressed ( final KeyEvent  keyEvent )
    ////////////////////////////////////////////////////////////////////////
    {
      switch ( keyEvent.getKeyCode ( ) )
      {
        case KeyEvent.VK_SPACE:
          
          spacePressed = true;
          
          break;
          
        case KeyEvent.VK_F:
          
          keyFPressed = true;
          
          break;
          
        default:
          
          // ignore
      }
    }
     
    @Override
    public void  mouseClicked ( final MouseEvent  mouseEvent )
    ////////////////////////////////////////////////////////////////////////
    {
      mouseClicked = true;
    }
     
    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      keyFPressed  = false;
      
      mouseClicked = false;
      
      spacePressed = false;
    }
     
    @Override
    public void  update ( )
    ////////////////////////////////////////////////////////////////////////
    {
      if ( keyFPressed )
      {
        keyFPressed = !requestSlot.offer (
          NeuroMessage.TOGGLE_FRAME_RATE_REQUEST_INSTANCE );
      }
      
      if ( mouseClicked )
      {
        mouseClicked = !requestSlot.offer (
          NeuroMessage.TOGGLE_CHANNEL_REQUEST_INSTANCE );
      }
      
      if ( spacePressed )
      {
        spacePressed = !requestSlot.offer (
          NeuroMessage.TOGGLE_PAUSE_REQUEST_INSTANCE );
      }
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }