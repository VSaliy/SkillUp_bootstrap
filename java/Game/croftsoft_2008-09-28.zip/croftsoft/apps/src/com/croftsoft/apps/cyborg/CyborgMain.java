     package com.croftsoft.apps.cyborg;
     
     import java.awt.*;
     
     import com.croftsoft.core.lang.NullArgumentException;
     import com.croftsoft.core.lang.lifecycle.Initializable;
     import com.croftsoft.core.lang.lifecycle.Lifecycle;
     import com.croftsoft.core.lang.lifecycle.LifecycleLib;
     import com.croftsoft.core.lang.lifecycle.Updatable;
     import com.croftsoft.core.gui.LifecycleWindowListener;
     import com.croftsoft.core.util.loop.*;
     
     /*********************************************************************
     * Neural interface simulation using a joystick.
     *  
     * @version
     *   $Date: 2005/10/17 16:47:51 $
     * @since
     *   2005-03-14
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  CyborgMain
       implements Lifecycle, Loopable, Runnable
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private final Initializable [ ]  initializables;
     
     private final Updatable     [ ]  updatables;
     
     private final Looper             looper;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public static void  main ( String [ ]  args )
     //////////////////////////////////////////////////////////////////////
     {
       System.out.println ( "\n" + CyborgConfig.INFO );
       
       CyborgModel  cyborgModel = new CyborgModelImpl ( );
       
       CyborgOperator  cyborgOperator = new CyborgOperator ( cyborgModel );
       
       CyborgController  cyborgController = new CyborgController (
         cyborgModel,
         cyborgOperator );       
       
       CyborgFrame  cyborgFrame
         = new CyborgFrame ( cyborgModel, cyborgController );
       
       CyborgMain  cyborgMain = new CyborgMain (
         new Initializable [ ] { cyborgFrame },
         new Updatable [ ] {
           cyborgController,
           cyborgModel,
           cyborgFrame },
         cyborgModel.getLoopGovernor ( ) );
       
       LifecycleWindowListener.launchFrameAsDesktopApp (
         cyborgFrame,
         new Lifecycle [ ] { cyborgMain },
         CyborgConfig.FRAME_SIZE,
         CyborgConfig.SHUTDOWN );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  CyborgMain (
       Initializable [ ]  initializables,
       Updatable     [ ]  updatables,
       LoopGovernor       loopGovernor )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.check (
         this.initializables = initializables );
       
       NullArgumentException.check ( this.updatables = updatables );
       
       looper = new Looper (
         this, // loopable
         loopGovernor,
         null, // exceptionHandler
         "Cyborg Loop", // threadName
         Thread.MIN_PRIORITY,
         true ); // useDaemonThread       
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.init ( initializables );
       
       LifecycleLib.init ( looper );
       
       LifecycleLib.start ( looper );
     }
     
     public void  start ( )
     //////////////////////////////////////////////////////////////////////
     {
     }
     
     public void  stop ( )
     //////////////////////////////////////////////////////////////////////
     {
     }
     
     public void  destroy ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.stop ( looper );
       
       LifecycleLib.destroy ( looper );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public boolean  loop ( )
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         EventQueue.invokeAndWait ( this );
         
         return true;
       }
       catch ( InterruptedException  ex )
       {
       }
       catch ( Exception  ex )
       {
         ex.printStackTrace ( );
       }
       
       return false;
     }
     
     public void  run ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.update ( updatables );
     }
       
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }