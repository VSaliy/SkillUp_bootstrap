    package com.croftsoft.apps.skipper;
     
    import java.awt.*;
    import javax.swing.*;

    import com.croftsoft.core.animation.ComponentAnimator;
    import com.croftsoft.core.animation.animator.NullComponentAnimator;
    import com.croftsoft.core.lang.NullArgumentException;
    import com.croftsoft.core.lang.lifecycle.Initializable;
    import com.croftsoft.core.lang.lifecycle.Updatable;

    /***********************************************************************
    * Skipper View.
    *  
    * Copyright 2007 David Wallace Croft.
    * 
    * @version
    *   $Date: 2007/07/28 16:57:03 $ $Author: croft $
    * @since
    *   2006-12-19
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  SkipperView
      implements Initializable, Updatable
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private final SkipperConfig  skipperConfig;

    private final SkipperModel   skipperModel;

    private final JComponent     jComponent;

    //

    private ComponentAnimator  componentAnimator;

    ////////////////////////////////////////////////////////////////////////
    // constructor methods
    ////////////////////////////////////////////////////////////////////////

    public  SkipperView (
      final SkipperConfig  skipperConfig,
      final SkipperModel   skipperModel )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        this.skipperConfig = skipperConfig,
        this.skipperModel  = skipperModel );

      componentAnimator = NullComponentAnimator.INSTANCE;

      jComponent = new JComponent ( )
      {
        private static final long  serialVersionUID = 0L;

        @Override
        public void  paintComponent ( final Graphics  graphics )
        {
          componentAnimator.paint ( this, ( Graphics2D ) graphics );
        }
      };
    }

    ////////////////////////////////////////////////////////////////////////
    // mutator methods
    ////////////////////////////////////////////////////////////////////////

    public void  setContentPane ( final Container  contentPane )
    ////////////////////////////////////////////////////////////////////////
    {
      contentPane.setLayout ( new BorderLayout ( ) );

      contentPane.add ( jComponent, BorderLayout.CENTER );
    }

    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////

    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      componentAnimator
        = new SkipperAnimator ( skipperConfig, skipperModel, jComponent );
    }

    public void  update ( )
    ////////////////////////////////////////////////////////////////////////
    {
      componentAnimator.update ( jComponent );
    }       

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }