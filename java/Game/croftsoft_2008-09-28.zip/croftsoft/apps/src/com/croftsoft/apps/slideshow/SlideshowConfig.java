     package com.croftsoft.apps.slideshow;
     
     import java.awt.*;
     import java.io.*;
     import java.net.*;
     import java.util.*;
     import java.util.concurrent.*;
     import java.util.logging.*;
     import javax.imageio.ImageIO;

     import com.croftsoft.core.CroftSoftConstants;
     import com.croftsoft.core.math.MathConstants;
     
     /*********************************************************************
     * Configuration.
     *  
     * Can be modified to be persistent.
     * 
     * @version
     *   $Id: SlideshowConfig.java,v 1.4 2006/12/17 09:42:39 croft Exp $
     * @since
     *   2006-10-30
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  SlideshowConfig
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final String  CLASS_NAME
       = SlideshowConfig.class.getName ( );
       
     private static final String  VERSION
       = "$Date: 2006/12/17 09:42:39 $";
   
     private static final String  TITLE
       = "CroftSoft Slideshow";
   
     private static final String  INFO
       = TITLE + "\n"
       + "Version " + VERSION + "\n"
       + CroftSoftConstants.COPYRIGHT + "\n"
       + CroftSoftConstants.DEFAULT_LICENSE + "\n"
       + CroftSoftConstants.HOME_PAGE + "\n";

     private static final int
       FRAME_WIDTH  = 600,
       FRAME_HEIGHT = 400;
   
     private static final double  UPDATE_RATE = 1.0;
     
     private static final String  SHUTDOWN_CONFIRMATION_PROMPT = null;
     
     private static final Font    FONT
       = new Font ( "Arioso", Font.BOLD, 20 );
     
     private static final Color
       BACKGROUND_COLOR = Color.BLACK,
       FOREGROUND_COLOR = Color.GREEN;
     
     //
     
     private static final String
       PROPERTY_SHOW  = "show",
       PROPERTY_SPEED = "speed";
       
     private static final String [ ]  PROPERTY_SHOW_VALUES = {
       "off",
       "on" };
     
     private static final String [ ]  PROPERTY_SPEED_VALUES = {
       "slow",
       "medium",
       "fast" };
     
     private static final int [ ]  DISPLAY_TIMES = {
       600,
       60,
       6 };
     
     private static final boolean [ ]  SHOW_VALUES = {
       false,
       true };
     
     private static final long  DEFAULT_DISPLAY_TIME_NANOS
       = DISPLAY_TIMES [ 1 ] * MathConstants.NANOSECONDS_PER_SECOND;
     
     private static final boolean  DEFAULT_SHOW
       = false;
     
     //
     
     private final Logger                logger;
     
     private final Map<String, Integer>  speedMap;
     
     private final Map<String, Boolean>  showMap;
     
     //
     
     private boolean     displayImageFilename;
       
     private String [ ]  imageFilenames;
     
     private long        displayTimeNanos;

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public static SlideshowConfig  load ( String [ ]  args )
     //////////////////////////////////////////////////////////////////////
     {
       // Could load from a persistent XML file.
       
       return new SlideshowConfig ( );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  SlideshowConfig ( )
     //////////////////////////////////////////////////////////////////////
     {
       logger = Logger.getLogger ( CLASS_NAME );
       
       speedMap = new HashMap<String, Integer> ( );

       showMap = new HashMap<String, Boolean> ( );

       for ( int  i = 0; i < PROPERTY_SPEED_VALUES.length; i++ )
       {
         speedMap.put (
           PROPERTY_SPEED_VALUES [ i ],
           new Integer ( DISPLAY_TIMES [ i ] ) );
       }

       displayTimeNanos = DEFAULT_DISPLAY_TIME_NANOS;

       for ( int  i = 0; i < PROPERTY_SHOW_VALUES.length; i++ )
       {
         showMap.put (
           PROPERTY_SHOW_VALUES [ i ],
           new Boolean ( SHOW_VALUES [ i ] ) );
       }

       displayImageFilename = DEFAULT_SHOW;
/*
       final Integer  displayTimeInteger
         = ( Integer ) getPropertyValue ( PROPERTY_SPEED, speedMap );

       if ( displayTimeInteger != null )
       {
         displayTimeNanos = displayTimeInteger.intValue ( )
           * MathConstants.NANOSECONDS_PER_SECOND;
       }

       final Boolean  showBoolean
         = ( Boolean ) getPropertyValue ( PROPERTY_SHOW, showMap );

       if ( showBoolean != null )
       {
         displayImageFilename = showBoolean.booleanValue ( );
       }
*/
       final Executor  executor = Executors.newSingleThreadExecutor ( );

       executor.execute (
         new Runnable ( )
         {
           public void  run ( )
           {
             imageFilenames = loadImageFilenames ( );
           }
         } );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public Color  getBackgroundColor ( ) { return BACKGROUND_COLOR; }
     
     public Color  getForegroundColor ( ) { return FOREGROUND_COLOR; }
     
     public String  getInfo ( ) { return INFO; }
     
     public Font  getFont ( ) { return FONT; }
     
     public Dimension  getFrameSize ( )
       { return new Dimension ( FRAME_WIDTH, FRAME_HEIGHT ); }
     
     public String  getFrameTitle ( ) { return TITLE; }

     public String  getShutdownConfirmationPrompt ( )
       { return SHUTDOWN_CONFIRMATION_PROMPT; }
     
     public String  getThreadName ( ) { return TITLE; }
     
     public double  getUpdateRate ( ) { return UPDATE_RATE; }
     
     public String [ ]  getImageFilenames ( ) { return imageFilenames; }
     
     public long  getDisplayTimeNanos ( ) { return displayTimeNanos; }
     
     public boolean  getDisplayImageFilename ( )
       { return displayImageFilename; }
     
     //////////////////////////////////////////////////////////////////////
     // private methods
     //////////////////////////////////////////////////////////////////////
     
     private static void  initLoggingToFiles ( final Logger  logger )
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         final String  userHome = System.getProperty ( "user.home" );

         if ( userHome == null )
         {
           return;
         }

         final File  homeDirectory = new File ( userHome );

         if ( !homeDirectory.exists ( )
           || !homeDirectory.isDirectory ( ) )
         {
           return;
         }

         final File  logDirectory
           = new File ( homeDirectory, ".croftsoft/savor" );

         logDirectory.mkdirs ( );

         final FileHandler  fileHandler = new FileHandler (
           "%h/.croftsoft/savor/savor%g.log",
           10000,
           2,
           false );

         logger.addHandler ( fileHandler );
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
       }
     }
     
     private static String [ ]  loadImageFilenames ( )
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         final String [ ]  suffixes = ImageIO.getReaderFileSuffixes ( );
         
         final String  userHome = System.getProperty ( "user.home" );
       
         if ( userHome == null )
         {
           return null;
         }
         
         final File  homeDirectory = new File ( userHome );
         
         if ( !homeDirectory.exists ( )
           || !homeDirectory.isDirectory ( ) )
         {
           return null;
         }
       
         File  picturesDirectory
           = new File ( homeDirectory, "My Documents/My Pictures" );
         
         if ( !picturesDirectory.exists ( )
           || !picturesDirectory.isDirectory ( ) )
         {
           picturesDirectory = homeDirectory;
         }
         
         final Set<String>  imageFilenameSet = new HashSet<String> ( );
         
         final Stack<File>  directoryStack = new Stack<File> ( );
         
         directoryStack.add ( picturesDirectory );
         
         File  directory = null;
         
         while ( !directoryStack.isEmpty ( ) )
         {
           directory = directoryStack.pop ( );
           
           final String [ ]  list = directory.list ( );
           
           for ( String  filename : list )
           {
             final File  file = new File ( directory, filename );
             
             if ( file.isDirectory ( ) )
             {
               directoryStack.add ( file );
               
               continue;
             }
             
             filename = filename.toLowerCase ( );
             
             for ( final String  suffix : suffixes )
             {
               if ( filename.endsWith ( "." + suffix ) )
               {
                 filename = file.getCanonicalPath ( );
             
                 imageFilenameSet.add ( filename );
                 
                 break;
               }
             }
           }
         }
         
         return imageFilenameSet.toArray ( new String [ 0 ] );
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
       }
       
       return null;
     }
/*
     private Object  getPropertyValue (
       final String  propertyName,
       final Map     propertyMap )
     //////////////////////////////////////////////////////////////////////
     {
       final ScreensaverContext  screensaverContext = getContext ( );
       
       final ScreensaverSettings  screensaverSettings
         = screensaverContext.getSettings ( );
       
       String  propertyValue
         = screensaverSettings.getProperty ( propertyName );
       
       if ( propertyValue == null )
       {
         return null;
       }
       
       propertyValue = propertyValue.trim ( ).toLowerCase ( );
       
       return propertyMap.get ( propertyValue );
     }
*/     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }