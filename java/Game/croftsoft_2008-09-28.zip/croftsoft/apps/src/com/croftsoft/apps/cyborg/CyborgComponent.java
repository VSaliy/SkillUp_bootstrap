     package com.croftsoft.apps.cyborg;

     import java.awt.*;
     import javax.swing.JComponent;

     import com.croftsoft.core.animation.*;
     import com.croftsoft.core.animation.collector.BooleanRepaintCollector;
     import com.croftsoft.core.lang.NullArgumentException;

     /*********************************************************************
     * Animated Swing component.
     *
     * @version
     *   $Date: 2008/04/19 21:30:58 $
     * @since
     *   2005-08-12
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public class  CyborgComponent
       extends JComponent
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final long  serialVersionUID = 0L;
     
     //      

     protected ComponentAnimator  componentAnimator;

     protected RepaintCollector   repaintCollector;

     //////////////////////////////////////////////////////////////////////
     // constructor methods
     //////////////////////////////////////////////////////////////////////

     /*********************************************************************
     * Main constructor.
     *********************************************************************/
     public  CyborgComponent ( )
     //////////////////////////////////////////////////////////////////////
     {
       setRepaintCollector ( new BooleanRepaintCollector ( ) );

       setOpaque ( true );
       
       setFont ( CyborgConfig.FONT );
       
       setCursor ( CyborgConfig.CURSOR );
       
       setPreferredSize ( new Dimension (
         CyborgConfig.COMPONENT_MIN_WIDTH,
         CyborgConfig.COMPONENT_MIN_HEIGHT ) );
     }

     //////////////////////////////////////////////////////////////////////
     // mutator methods
     //////////////////////////////////////////////////////////////////////

     public synchronized ComponentAnimator  setComponentAnimator (
       ComponentAnimator  componentAnimator )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.check ( componentAnimator );

       ComponentAnimator  oldComponentAnimator = this.componentAnimator;

       this.componentAnimator = componentAnimator;

       return oldComponentAnimator;
     }

     public synchronized RepaintCollector  setRepaintCollector (
       RepaintCollector  repaintCollector )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.check ( repaintCollector );

       RepaintCollector  oldRepaintCollector = this.repaintCollector;

       this.repaintCollector = repaintCollector;

       return oldRepaintCollector;
     }

     //////////////////////////////////////////////////////////////////////
     // overridden JComponent methods
     //////////////////////////////////////////////////////////////////////

     public void  paintComponent ( Graphics  graphics )
     //////////////////////////////////////////////////////////////////////
     {
       componentAnimator.paint ( this, ( Graphics2D ) graphics );
     }

     public void  repaint ( )
     //////////////////////////////////////////////////////////////////////
     {
       repaintCollector.repaint ( );
     }

     public void  repaint ( long  tm )
     //////////////////////////////////////////////////////////////////////
     {
       repaintCollector.repaint ( );
     }

     public void  repaint (
       int  x,
       int  y,
       int  width,
       int  height )
     //////////////////////////////////////////////////////////////////////
     {
       repaintCollector.repaint ( x, y, width, height );
     }

     public void  repaint (
       long  tm,
       int   x,
       int   y,
       int   width,
       int   height )
     //////////////////////////////////////////////////////////////////////
     {
       repaintCollector.repaint ( x, y, width, height );
     }

     public void  repaint ( Rectangle  r )
     //////////////////////////////////////////////////////////////////////
     {
       repaintCollector.repaint ( r.x, r.y, r.width, r.height );
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public void  update ( )
     //////////////////////////////////////////////////////////////////////
     {
       componentAnimator.update ( this );

       int  count = repaintCollector.getCount ( );

       Rectangle [ ]  repaintRegions
         = repaintCollector.getRepaintRegions ( );

       for ( int  i = 0; i < count; i++ )
       {
         paintImmediately ( repaintRegions [ i ] );
       }

       repaintCollector.reset ( );
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }
