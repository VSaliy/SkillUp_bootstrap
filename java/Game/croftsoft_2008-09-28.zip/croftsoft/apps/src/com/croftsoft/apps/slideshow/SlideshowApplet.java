     package com.croftsoft.apps.slideshow;
     
     import javax.swing.JApplet;
     
     import com.croftsoft.core.lang.lifecycle.*;
     
     /*********************************************************************
     * Applet.
     *
     * @version
     *   $Id: SlideshowApplet.java,v 1.2 2006/12/16 09:32:41 croft Exp $
     * @since
     *   2006-12-16
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/
     
     public final class  SlideshowApplet
       extends JApplet
       implements Lifecycle
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final long  serialVersionUID = 0L;
     
     //
     
     // private static final String  PARAM_EXAMPLE = "example";
     
     //
       
     private final SlideshowMain  slideshowMain;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
       
     public  SlideshowApplet ( )
     //////////////////////////////////////////////////////////////////////
     {
       slideshowMain = new SlideshowMain ( null );
     }
     
     //////////////////////////////////////////////////////////////////////
     // overridden applet methods
     //////////////////////////////////////////////////////////////////////
     
     @Override
     public String  getAppletInfo ( )
     //////////////////////////////////////////////////////////////////////
     {
       return slideshowMain.getSlideshowConfig ( ).getInfo ( );
     }
     
     @Override
     public void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       slideshowMain.setContentPane ( getContentPane ( ) );
       
       // final SlideshowConfig  slideshowConfig
       //   = slideshowMain.getSlideshowConfig ( );
       
       // slideshowConfig.setCodeBase ( getCodeBase ( ) );
       
       // final String  example = getParameter ( PARAM_EXAMPLE );
       
       // slideshowConfig.setExample ( example );
       
       LifecycleLib.init ( slideshowMain );
     }
     
     @Override
     public void  start ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.start ( slideshowMain );
     }
     
     @Override
     public void  stop ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.stop ( slideshowMain );
     }
     
     @Override
     public void  destroy ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.destroy ( slideshowMain );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }