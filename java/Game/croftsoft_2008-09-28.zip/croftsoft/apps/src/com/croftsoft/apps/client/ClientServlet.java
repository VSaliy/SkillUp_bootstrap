     package com.croftsoft.apps.client;
     
     import java.io.*;
     import java.net.*;

     import javax.servlet.*;
     import javax.servlet.http.*;
     
     import org.aitools.programd.Core;
     import org.aitools.programd.server.servlet.ProgramDContextListener;
     import org.aitools.util.resource.URLTools;
     import org.aitools.util.xml.XML;
     
     /*********************************************************************
     * Processes Program D requests.
     * 
     * @version
     *   $Id: ClientServlet.java,v 1.3 2006/12/01 04:42:24 croft Exp $
     * @since
     *   2006-11-27
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  ClientServlet
       extends HttpServlet
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final long  serialVersionUID = 0L;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     @Override
     protected void  doGet (
       final HttpServletRequest   httpServletRequest,
       final HttpServletResponse  httpServletResponse )
       throws ServletException
     //////////////////////////////////////////////////////////////////////
     {
       String  request
         = httpServletRequest.getParameter ( "request" );
       
       if ( request == null )
       {
         return;
       }
       
       request = request.trim ( ).toLowerCase ( );
       
       if ( request.equals ( "input" ) )
       {
         doInput ( httpServletRequest, httpServletResponse );
       }
       else if ( request.equals ( "reload" ) )
       {
         doReload ( );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     private void  doInput (
       final HttpServletRequest   httpServletRequest,
       final HttpServletResponse  httpServletResponse )
       throws ServletException
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         final ServletContext  servletContext = getServletContext ( );
         
         final Core  core = ( Core ) servletContext.getAttribute (
           ProgramDContextListener.KEY_CORE ); 
         
         final PrintWriter  printWriter
           = httpServletResponse.getWriter ( );
         
         printWriter.write ( XML.filterWhitespace ( core.getResponse (
           httpServletRequest.getParameter ( "input"  ),
           httpServletRequest.getParameter ( "userid" ),
           httpServletRequest.getParameter ( "botid"  ) ) ) );
         
         printWriter.flush ( );
         
         printWriter.close ( );
       }
       catch ( Exception  ex )
       {
         throw new ServletException ( "doInput failure", ex );
       }
     }
     
     private void  doReload ( )
       throws ServletException
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         final ServletContext  servletContext = getServletContext ( );
       
         final String  config = servletContext.getInitParameter (
           ProgramDContextListener.PARAM_CORE_CONFIG );
       
         final URL  baseURL = servletContext.getResource ( "/" );
       
         final Core core = new Core (
           baseURL, URLTools.contextualize ( baseURL, config ) );
       
         servletContext.setAttribute (
           ProgramDContextListener.KEY_CORE, core );       
       }
       catch ( Exception  ex )
       {
         throw new ServletException ( "doReload failure", ex );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }