    package com.croftsoft.apps.exemplar;
     
    /***********************************************************************
    * Exemplar model accessor interface.
    * 
    * Read-only access to model state.
    * 
    * @version
    *   $Id: ExemplarModel.java,v 1.2 2008/02/15 22:38:03 croft Exp $
    * @since
    *   2006-01-14
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public interface  ExemplarModel
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    public long    getClickCount ( );
     
    public double  getPhase      ( );
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }