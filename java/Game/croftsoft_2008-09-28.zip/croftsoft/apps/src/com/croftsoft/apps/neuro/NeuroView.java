    package com.croftsoft.apps.neuro;
     
    import java.awt.*;
    import javax.swing.*;
     
    import com.croftsoft.core.animation.ComponentAnimator;
    import com.croftsoft.core.animation.animator.NullComponentAnimator;
    import com.croftsoft.core.gui.event.UserInputListener;
    import com.croftsoft.core.lang.NullArgumentException;
    import com.croftsoft.core.lang.lifecycle.Lifecycle;
    import com.croftsoft.core.lang.lifecycle.Updatable;
    import com.croftsoft.core.util.mail.Mail;
     
    /***********************************************************************
    * Neuro view.
    *  
    * @version
    *   $Id: NeuroView.java,v 1.5 2008/08/30 01:37:30 croft Exp $
    * @since
    *   2008-08-17
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  NeuroView
      implements Lifecycle, Updatable
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
    	 
    private final NeuroConfig         neuroConfig;
    
    private final Mail<NeuroMessage>  mail;
    
    private final NeuroModel          neuroModel;
     
    private final JComponent          jComponent;
    
    //
     
    private ComponentAnimator  componentAnimator;
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public  NeuroView (
      final NeuroConfig         neuroConfig,
      final Mail<NeuroMessage>  mail,
      final NeuroModel          neuroModel )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        this.neuroConfig = neuroConfig,
        this.mail        = mail,
        this.neuroModel  = neuroModel );
       
      componentAnimator = NullComponentAnimator.INSTANCE;
       
      jComponent = new JComponent ( )
        {
          private static final long  serialVersionUID = 0L;
    	   
          @Override
          public void  paintComponent ( final Graphics  graphics )
          {
            componentAnimator.paint ( this, ( Graphics2D ) graphics );
          }
        };
    }
     
    ////////////////////////////////////////////////////////////////////////
    // mutator methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  addUserInputListener (
      final UserInputListener  userInputListener )
    ////////////////////////////////////////////////////////////////////////
    {
      jComponent.addKeyListener   ( userInputListener );
      
      jComponent.addMouseListener ( userInputListener );
    }
     
    public void  setContentPane ( final Container  contentPane )
    ////////////////////////////////////////////////////////////////////////
    {
      contentPane.setLayout ( new BorderLayout ( ) );
       
      contentPane.add ( jComponent, BorderLayout.CENTER );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      System.out.println ( "NeuroView.init()" );
       
      componentAnimator = new NeuroAnimator (
        neuroConfig,
        mail,
        neuroModel,
        jComponent );
    }
     
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      System.out.println ( "NeuroView.start()" );       
    }
     
    public void  stop ( )
    ////////////////////////////////////////////////////////////////////////
    {
      System.out.println ( "NeuroView.stop()" );       
    }
     
    public void  destroy ( )
    ////////////////////////////////////////////////////////////////////////
    {
      System.out.println ( "NeuroView.destroy()" );
    }
     
    public void  update ( )
    ////////////////////////////////////////////////////////////////////////
    {
      final int  size = mail.size ( );
      
      for ( int  i = 0; i < size; i++ )
      {
        final NeuroMessage  neuroMessage = mail.get ( i );
        
        final NeuroMessage.Type  type = neuroMessage.getType ( );
         
        switch ( type )
        {
          case TOGGLE_CHANNEL_REQUEST:
          case TOGGLE_PAUSE_REQUEST:
             
            Toolkit.getDefaultToolkit ( ).beep ( );
             
            break;
             
          default:
            
            // ignore
        }
      }
      
      componentAnimator.update ( jComponent );
    }       
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }