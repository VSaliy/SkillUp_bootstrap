    package com.croftsoft.apps.infant;
     
    import java.awt.event.*;
    import java.util.*;

    import net.java.games.input.Component;
    import net.java.games.input.Controller;
    import net.java.games.input.ControllerEnvironment;

    import com.croftsoft.core.gui.controller.NilController;
    import com.croftsoft.core.lang.NullArgumentException;
    import com.croftsoft.core.util.log.Log;

    /***********************************************************************
    * Modifies model based on user input.
    * 
    * @version
    *   $Id: InfantController.java,v 1.28 2007/12/01 00:51:07 croft Exp $
    * @since
    *   2005-03-16
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  InfantController
      extends NilController
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {

    private final InfantConfig          infantConfig;

    private final Queue<InfantMessage>  requestQueue;

    //

    private Controller  pacifierController;

    private boolean
      displayRequested,
      experimentEndRequested,
      pacifierPreviouslyPressed,
      pacifierReleased,
      resetRequested,
      saveFilenameRequested;

    private int  controllerIndex;

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    public  InfantController (
      final InfantConfig          infantConfig,
      final Queue<InfantMessage>  requestQueue )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        this.infantConfig = infantConfig,
        this.requestQueue = requestQueue );

      selectController ( );
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    @Override     
    public void  actionPerformed ( final ActionEvent  actionEvent )
    ////////////////////////////////////////////////////////////////////////
    {
      final String  actionCommand = actionEvent.getActionCommand ( );

      if ( actionCommand.equals (
        InfantMessage.Type.STIMULUS_WINDOW_OPEN.name ( ) ) )
      {
        this.displayRequested = true;
      }
      else if ( actionCommand.equals (
        InfantMessage.Type.EXPERIMENT_BEGIN.name ( ) ) )
      {
        this.resetRequested = true;
      }
      else if ( actionCommand.equals (
        InfantMessage.Type.EXPERIMENT_END.name ( ) ) )
      {
        experimentEndRequested = true;
      }
      else if ( actionCommand.equals (
        InfantMessage.Type.LOAD_SETUP.name ( ) ) )
      {
        requestQueue.offer (
          new InfantMessage ( InfantMessage.Type.LOAD_SETUP ) ); 
      }
      else if ( actionCommand.equals (
        InfantMessage.Type.REQUEST_SAVE_FILENAME.name ( ) ) )
      {
        saveFilenameRequested = true;
      }
      else
      {
        this.infantConfig.getLog ( ).record (
          "InfantController:  unknown command:  " + actionCommand );
      }
    }

    @Override     
    public void  keyReleased ( final KeyEvent  keyEvent )
    ////////////////////////////////////////////////////////////////////////
    {
      final int  keyCode = keyEvent.getKeyCode ( );

      if ( keyCode == KeyEvent.VK_SPACE )
      {
        pacifierReleased = true;
      }
      else
      {
        experimentEndRequested = true;
      }
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    @Override
    public void  update ( )
    ////////////////////////////////////////////////////////////////////////
    {
      final boolean  pacifierCurrentlyPressed = pollPacifier ( );

      if ( pacifierPreviouslyPressed
        && !pacifierCurrentlyPressed )
      {
        pacifierReleased = true;
      }

      pacifierPreviouslyPressed = pacifierCurrentlyPressed;

      if ( displayRequested )
      {
        displayRequested = !requestQueue.offer (
          new InfantMessage ( InfantMessage.Type.STIMULUS_WINDOW_OPEN ) );
      }

      if ( pacifierReleased )
      {
        pacifierReleased = !requestQueue.offer (
          new InfantMessage ( InfantMessage.Type.PACIFIER ) );
      }

      if ( resetRequested )
      {
        resetRequested = !requestQueue.offer (
          new InfantMessage ( InfantMessage.Type.EXPERIMENT_BEGIN ) );
      }

      if ( experimentEndRequested )
      {
        experimentEndRequested = !requestQueue.offer (
          new InfantMessage ( InfantMessage.Type.EXPERIMENT_END ) );
      }

      if ( saveFilenameRequested )
      {
        saveFilenameRequested = !requestQueue.offer (
          new InfantMessage (
            InfantMessage.Type.REQUEST_SAVE_FILENAME ) );
      }
    }

    ////////////////////////////////////////////////////////////////////////
    // private methods
    ////////////////////////////////////////////////////////////////////////

    private void  selectController ( )
    ////////////////////////////////////////////////////////////////////////
    {
      controllerIndex = infantConfig.getControllerIndex ( );

      final Log  log = infantConfig.getLog ( );

      Controller  pacifierController = null;

      try
      {
        final ControllerEnvironment  controllerEnvironment
        = ControllerEnvironment.getDefaultEnvironment ( );

        final Controller [ ]  controllers
        = controllerEnvironment.getControllers ( );

        for ( int  i = 1; i <= controllers.length; i++ )
        {
          final Controller  controller = controllers [ i - 1 ];

          if ( i == controllerIndex )
          {
            log.record ( i + " / " + controller.getType ( ) + " / "
              + controller.getName ( ) );

            if ( Controller.Type.STICK.equals ( controller.getType ( ) ) )
            {           
              pacifierController = controller;
            }
            else
            {
              log.record (
                "Controller is not of type " + Controller.Type.STICK );
            }
          }
        }
      }
      catch ( Exception  ex )
      {
        ex.printStackTrace ( );
      }

      if ( pacifierController != null )
      {
        log.record ( "Using controller " + controllerIndex + " / "
          + pacifierController.getType ( ) + " / "
          + pacifierController.getName ( ) );
      }
      else
      {
        log.record ( "Controller not configured (use spacebar to test)" );
      }

      this.pacifierController = pacifierController;
    }

    /***********&***********************************************************
    * Polls the pacifier.
    * 
    * @return
    * 
    *   True if the pacifier is currently pressed.
    ***********************************************************************/
    private boolean  pollPacifier ( )
    ////////////////////////////////////////////////////////////////////////
    {
      if ( controllerIndex != infantConfig.getControllerIndex ( ) )
      {
        selectController ( );
      }

      if ( pacifierController == null )
      {
        return false;
      }

      final Component [ ]  components
      = pacifierController.getComponents ( );

      if ( components == null )
      {
        return false;
      }

      final Float [ ]  floats = new Float [ components.length ];

      String  format = "";

      for ( int  i = 0; i < components.length; i++ )
      {
        format += "%" + ( i + 1 ) + "$+1.3f ";
      }

      format += "%n";

      if ( !pacifierController.poll ( ) )
      {
        return false;
      }

      for ( int  i = 0; i < components.length; i++ )
      {
        Component  component = components [ i ];

        floats [ i ] = new Float ( component.getPollData ( ) );
      }

//    System.out.printf ( format, ( Object [ ] ) floats );

      if ( ( floats.length > 2  )
        && ( floats [ 2 ].floatValue ( ) < 0.5 ) )
      {
        return true; 
      }

      return false;
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }