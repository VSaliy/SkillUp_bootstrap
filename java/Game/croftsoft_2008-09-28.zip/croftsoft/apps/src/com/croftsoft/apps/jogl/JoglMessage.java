    package com.croftsoft.apps.jogl;
     
    import com.croftsoft.core.lang.NullArgumentException;
     
    /***********************************************************************
    * Jogl enumerated type message.
    * 
    * Use to pass messages between the model, view, and controller.
    * 
    * @version
    *   $Id: JoglMessage.java,v 1.6 2008/05/17 00:18:02 croft Exp $
    * @since
    *   2008-02-10
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public class  JoglMessage
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
      
    public enum  Type
    {
      CHANGE_PERTURBATION_FACTOR_EVENT,
      CHANGE_PERTURBATION_FACTOR_REQUEST,
      MOVE_REQUEST,
    }
     
    public static JoglMessage
      CHANGE_PERTURBATION_FACTOR_EVENT_INSTANCE
        = new JoglMessage ( Type.CHANGE_PERTURBATION_FACTOR_EVENT ),
      CHANGE_PERTURBATION_FACTOR_REQUEST_INSTANCE
        = new JoglMessage ( Type.CHANGE_PERTURBATION_FACTOR_REQUEST );
       
    //
       
    private final Type  type;
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public Type  getType ( ) { return type; }
     
    ////////////////////////////////////////////////////////////////////////
    // protected methods
    ////////////////////////////////////////////////////////////////////////
     
    protected  JoglMessage ( final Type  type )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.check ( this.type = type );
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }