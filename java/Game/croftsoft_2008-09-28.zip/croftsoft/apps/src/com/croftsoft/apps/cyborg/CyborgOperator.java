     package com.croftsoft.apps.cyborg;
     
     import java.util.*;
     
     import com.croftsoft.core.lang.NullArgumentException;
     import com.croftsoft.core.math.MathConstants;
     
     /*********************************************************************
     * Simulates user input.
     * 
     * @version
     *   $Id: CyborgOperator.java,v 1.10 2008/04/19 21:30:58 croft Exp $
     * @since
     *   2005-08-24
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  CyborgOperator
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final int  ARRAY_LENGTH = 1 + ( int )
       ( ( CyborgConfig.OPERATOR_DELAY_MILLIS * CyborgConfig.FRAME_RATE )
       / MathConstants.MILLISECONDS_PER_SECOND ); 
     
     //
       
     private final CyborgModel  cyborgModel;
     
     private final Random       random;
     
     private final double [ ]
       arrayX,
       arrayY,
       targetCenterXs,
       targetCenterYs;
     
     //
     
     private int  index;
       
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  CyborgOperator ( CyborgModel  cyborgModel )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.check (
         this.cyborgModel = cyborgModel );
       
       random = new Random ( );
       
       arrayX = new double [ ARRAY_LENGTH ];
       
       arrayY = new double [ ARRAY_LENGTH ];
       
       targetCenterXs = new double [ ARRAY_LENGTH ];
       
       targetCenterYs = new double [ ARRAY_LENGTH ];
       
       
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  update ( )
     //////////////////////////////////////////////////////////////////////
     {
       arrayX [ index ] = cyborgModel.getX ( );
       
       arrayY [ index ] = cyborgModel.getY ( );
       
       targetCenterXs [ index ] = cyborgModel.getTargetCenterX ( );
       
       targetCenterYs [ index ] = cyborgModel.getTargetCenterY ( );
       
       index++;
       
       if ( index == ARRAY_LENGTH )
       {
         index = 0;
       }
       
       double  x = arrayX [ index ];
       
       double  y = arrayY [ index ];
       
       double  targetCenterX = targetCenterXs [ index ];
       
       double  targetCenterY = targetCenterYs [ index ];
       
       double  aimX = cyborgModel.getAimX ( );
       
       double  aimY = cyborgModel.getAimY ( );
       
       double  deltaX
         = CyborgConfig.OPERATOR_DELTA * ( targetCenterX - x );
       
       double  deltaY
         = CyborgConfig.OPERATOR_DELTA * ( targetCenterY - y );
       
       aimX += deltaX; // + 0.01 * ( 2.0 * random.nextDouble ( ) - 1.0 );       
       
       aimY += deltaY; // + 0.01 * ( 2.0 * random.nextDouble ( ) - 1.0 );
       
       if ( aimX < -1.0 )
       {
         aimX = -1.0;
       }
       else if ( aimX > 1.0 )
       {
         aimX = 1.0;
       }
       
       if ( aimY < -1.0 )
       {
         aimY = -1.0;
       }
       else if ( aimY > 1.0 )
       {
         aimY = 1.0;
       }       
       
       cyborgModel.setAimX ( aimX );
       
       cyborgModel.setAimY ( aimY );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }