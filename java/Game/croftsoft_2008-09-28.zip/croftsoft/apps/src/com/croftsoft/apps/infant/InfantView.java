     package com.croftsoft.apps.infant;
     
     import java.awt.*;
     import java.awt.event.*;
     import java.io.*;
     import java.text.*;
     import java.util.*;
     import javax.imageio.*;
     import javax.swing.*;     
     import javax.swing.border.*;
     import javax.swing.event.*;
     
     import com.croftsoft.core.gui.LogPanel;
     import com.croftsoft.core.gui.WindowLib;
     import com.croftsoft.core.gui.event.UserInputListener;
     import com.croftsoft.core.lang.NullArgumentException;
     import com.croftsoft.core.lang.lifecycle.Destroyable;
     import com.croftsoft.core.lang.lifecycle.Updatable;
     import com.croftsoft.core.math.MathConstants;
import com.croftsoft.core.util.slot.Slot;
     
     /*********************************************************************
     * View.
     *  
     * @version
     *   $Id: InfantView.java,v 1.38 2008/09/20 05:01:49 croft Exp $
     * @since
     *   2006-01-03
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  InfantView
       implements Destroyable, Updatable
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
    	 
     private static final long  serialVersionUID = 0L;
     
     private static final DateFormat  dateFormat
       = new SimpleDateFormat ( "yyyy-MM-dd HH:mm:ss Z" );       
     
     //
     
     private final InfantConfig          infantConfig;
     
     private final InfantAccessor        infantAccessor;
     
     private final Queue<InfantMessage>  eventQueue;
     
     private final Slot<InfantMessage>   requestSlot;
     
     private final JFrame                controlFrame;
     
     private final JFrame                displayFrame;
     
     private final InfantComponent       infantComponent;
     
     private final Set<JButton>          buttonSet;
     
     private final Map<String,Image>     imagePathToImageMap;
     
     private final SpinnerNumberModel
       controllerIndexSpinnerNumberModel,
       imageDisplayTimeSpinnerNumberModel,
       interStimulusIntervalSpinnerNumberModel,
       scaleSpinnerNumberModel;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  InfantView (
       final InfantConfig          infantConfig,
       final InfantAccessor        infantAccessor,
       final Queue<InfantMessage>  eventQueue,
       final Slot<InfantMessage>   requestSlot )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.checkArgs (
         this.infantConfig   = infantConfig,
         this.infantAccessor = infantAccessor,
         this.eventQueue     = eventQueue,
         this.requestSlot    = requestSlot );
       
       buttonSet = new HashSet<JButton> ( );
       
       imageDisplayTimeSpinnerNumberModel = new SpinnerNumberModel (
         infantAccessor.getImageDisplayTime ( )
           * MathConstants.SECONDS_PER_NANOSECOND,
         0.0,
         Double.POSITIVE_INFINITY,
         0.1 );
             
       interStimulusIntervalSpinnerNumberModel = new SpinnerNumberModel (
           infantAccessor.getInterStimulusInterval ( )
             * MathConstants.SECONDS_PER_NANOSECOND,
           0.0,
           Double.POSITIVE_INFINITY,
           0.1 );
       
       controllerIndexSpinnerNumberModel = new SpinnerNumberModel (
         new Integer ( infantConfig.getControllerIndex ( ) ),
         new Integer ( 0 ),
         new Integer ( Integer.MAX_VALUE ),
         new Integer ( 1 ) );
             
       scaleSpinnerNumberModel = new SpinnerNumberModel (
         infantAccessor.getScale ( ),
         0.00001,
         10000.0,
         0.1 );
             
       this.imageDisplayTimeSpinnerNumberModel.addChangeListener (
         new ChangeListener ( )
         {
           public void  stateChanged ( final ChangeEvent  changeEvent )
           {
             final Object  value
               = imageDisplayTimeSpinnerNumberModel.getValue ( );
           
             requestSlot.offer (
               new InfantMessage (
                 InfantMessage.Type.DURATION,
                 new Long (
                   Math.round ( ( ( Double ) value ).doubleValue ( )
                     * MathConstants.NANOSECONDS_PER_SECOND ) ) ) );
           }
         } );
       
       this.interStimulusIntervalSpinnerNumberModel.addChangeListener (
         new ChangeListener ( )
         {
           public void  stateChanged ( final ChangeEvent  changeEvent )
           {
             final Object  value
               = interStimulusIntervalSpinnerNumberModel.getValue ( );
           
             requestSlot.offer (
               new InfantMessage (
                 InfantMessage.Type.ISI,
                 new Long (
                   Math.round ( ( ( Double ) value ).doubleValue ( )
                     * MathConstants.NANOSECONDS_PER_SECOND ) ) ) );                 
           }
         } );
       
       controllerIndexSpinnerNumberModel.addChangeListener (
         new ChangeListener ( )
         {
           public void  stateChanged ( final ChangeEvent  changeEvent )
           {
             final Object  value
               = controllerIndexSpinnerNumberModel.getValue ( );
           
             requestSlot.offer (
               new InfantMessage (
                 InfantMessage.Type.SET_CONTROLLER_INDEX,
                 value ) );
           }
         } );
       
       scaleSpinnerNumberModel.addChangeListener (
         new ChangeListener ( )
         {
           public void  stateChanged ( final ChangeEvent  changeEvent )
           {
             final Object  value = scaleSpinnerNumberModel.getValue ( );
           
             requestSlot.offer (
               new InfantMessage (
                 InfantMessage.Type.SET_SCALE_REQUEST,
                 value ) );
           }
         } );
       
       controlFrame = createControlFrame (
         infantConfig,
         buttonSet,
         controllerIndexSpinnerNumberModel,
         imageDisplayTimeSpinnerNumberModel,
         interStimulusIntervalSpinnerNumberModel,
         scaleSpinnerNumberModel );
       
       infantComponent
         = new InfantComponent ( infantConfig, infantAccessor );
       
       displayFrame = createStimulusFrame (
         infantComponent, requestSlot );
       
       imagePathToImageMap = new HashMap<String,Image> ( );
       
       final String [ ]  imagePaths = infantConfig.getImagePaths ( );
       
       try
       {         
         for ( int  id = 0; id < imagePaths.length; id++ )
         {
           final String  imagePath = imagePaths [ id ];
           
           final File  file = new File ( imagePath );
         
           final Image  image = ImageIO.read ( file );
           
           if ( image == null )
           {
             infantConfig.getLog ( ).record (
               "no registered ImageReader for " + imagePath );
           }
           else
           {           
             imagePathToImageMap.put ( imagePath, image );
             
             infantConfig.getLog ( ).record ( imagePath );
           }
         }
       }
       catch ( Exception  ex )
       {
         infantConfig.getLog ( ).record ( ex );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     // accessor methods
     //////////////////////////////////////////////////////////////////////
     
     public JFrame  getJFrame ( ) { return this.controlFrame; }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  addUserInputListener (
       final UserInputListener  userInputListener )
     //////////////////////////////////////////////////////////////////////
     {
       this.displayFrame.addKeyListener ( userInputListener );
       
       for ( JButton  button : this.buttonSet )
       {
         button.addActionListener ( userInputListener );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     // lifecycle methods
     //////////////////////////////////////////////////////////////////////
     
     public void  destroy ( )
     //////////////////////////////////////////////////////////////////////
     {
       this.displayFrame.setVisible ( false );
             
       this.controlFrame.setVisible ( false );
       
       this.displayFrame.dispose ( );
       
       this.controlFrame.dispose ( );             
     }
     
     public void  update ( )
     //////////////////////////////////////////////////////////////////////
     {
       InfantMessage  modelEvent = null;
       
       while ( ( modelEvent = this.eventQueue.poll ( ) ) != null )
       {
         final InfantMessage.Type  type = modelEvent.getType ( );
         
         switch ( type )
         {
           case DURATION_CHANGED:
             
             final Double  duration
               = new Double ( infantAccessor.getImageDisplayTime ( )
               * MathConstants.SECONDS_PER_NANOSECOND );
             
             final String  durationString
               = String.format ( "%1$1.3f", duration );
             
             final Double  oldDuration = ( Double )
               imageDisplayTimeSpinnerNumberModel.getValue ( );
             
             final String  oldDurationString
               = String.format ( "%1$1.3f", oldDuration );
             
             if ( !durationString.equals ( oldDurationString ) )
             {             
               imageDisplayTimeSpinnerNumberModel.setValue ( duration );
             }
             
             infantConfig.getLog ( ).record (
               createLogPrefix ( )
               + type.name ( )
               + " "
               + durationString );
             
             break;
             
           case GET_SAVE_REPORT_FILENAME:
             
             getSaveReportFilename ( modelEvent );
             
             break;
             
           case IMAGE:
             
             final String  imagePath
               = infantAccessor.getImagePath ( );
             
             final Image  image = imagePathToImageMap.get ( imagePath );
             
             infantComponent.setImage ( image );
/*             
             this.infantConfig.getLog ( ).record (
               createLogPrefix ( )
               + modelEvent.name ( )
               + " \""
               + ( imagePath == null ? "" : imagePath )  
               + "\"" );
*/             
             
             // System.out.println ( imagePath );
             
             break;
             
           case ISI_CHANGED:
             
             final Double  isi = new Double (
               infantAccessor.getInterStimulusInterval ( )
               * MathConstants.SECONDS_PER_NANOSECOND );
             
             final String  isiString
               = String.format ( "%1$1.3f", isi );
             
             final Double  oldIsi = ( Double )
               interStimulusIntervalSpinnerNumberModel.getValue ( );
             
             final String  oldIsiString
               = String.format ( "%1$1.3f", oldIsi );
             
             if ( !isiString.equals ( oldIsiString ) )
             {             
               this.interStimulusIntervalSpinnerNumberModel.setValue (
                 isi );
             }
             
             this.infantConfig.getLog ( ).record (
               createLogPrefix ( )
               + type.name ( )
               + " "
               + isiString );
             
             break;
             
           case LOAD_SETUP:
             
             loadSetup ( );
             
             break;
             
           case STIMULUS_WINDOW_CLOSE:
             
             this.displayFrame.setVisible ( false );
             
             break;
             
           case STIMULUS_WINDOW_OPEN:
             
             displayFrame.setExtendedState ( Frame.NORMAL );
       
             displayFrame.setVisible ( true );
             
             displayFrame.requestFocus ( );
             
             break;
             
           default:
             
             infantConfig.getLog ( ).record (
               createLogPrefix ( )
               + "InfantView:  unknown command:  " + type.name ( ) );             
         }
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     private static JFrame  createControlFrame (
       final InfantConfig        infantConfig,
       final Set<JButton>        buttonSet,
       final SpinnerNumberModel  controllerIndexSpinnerNumberModel,
       final SpinnerNumberModel  imageDisplayTimeSpinnerNumberModel,
       final SpinnerNumberModel  interStimulusIntervalSpinnerNumberModel,
       final SpinnerNumberModel  scaleSpinnerNumberModel )
     //////////////////////////////////////////////////////////////////////
     {
       final JFrame  controlFrame = new JFrame (
         infantConfig.getFrameTitle ( ) );
       
       WindowLib.centerOnScreen (
         controlFrame, infantConfig.getFrameSize ( ) );
       
       final Container  contentPane = controlFrame.getContentPane ( );
       
       contentPane.setLayout ( new BorderLayout ( ) );
       
       final LogPanel  logPanel
         = new LogPanel ( infantConfig.getLogLinesMax ( ) );
       
       infantConfig.setLog ( logPanel );
       
       contentPane.add (
         createLogScrollPane ( infantConfig, logPanel ),
         BorderLayout.CENTER );
       
       final JPanel  spinnerPanel = new JPanel ( new GridBagLayout ( ) );
       
       final GridBagConstraints  gridBagConstraints
         = new GridBagConstraints ( );
       
       gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
       
       gridBagConstraints.insets = new Insets ( 1, 4, 1, 0 );
       
       addImageDisplayTimeSpinner (
         spinnerPanel,
         gridBagConstraints,
         imageDisplayTimeSpinnerNumberModel );
       
       addInterStimulusIntervalSpinner (
         spinnerPanel,
         gridBagConstraints,
         interStimulusIntervalSpinnerNumberModel );
       
       addControllerIndexSpinner (
         spinnerPanel,
         gridBagConstraints,
         controllerIndexSpinnerNumberModel );
       
       addScaleSpinner (
         spinnerPanel,
         gridBagConstraints,
         scaleSpinnerNumberModel );
       
       final JPanel  buttonPanel = new JPanel ( new GridLayout ( 5, 1 ) );
       
       final JButton  loadSetupButton = new JButton ( "Load Setup" );
       
       loadSetupButton.setActionCommand (
         InfantMessage.Type.LOAD_SETUP.name ( ) );
       
       buttonPanel.add ( loadSetupButton );
       
       final JButton  displayButton = new JButton ( "Begin Experiment" );
       
       displayButton.setActionCommand (
         InfantMessage.Type.EXPERIMENT_BEGIN.name ( ) );
       
       buttonPanel.add ( displayButton );
       
       final JButton  endButton = new JButton ( "End Experiment" );
       
       endButton.setActionCommand (
         InfantMessage.Type.EXPERIMENT_END.name ( ) );
       
       buttonPanel.add ( endButton );
       
       final JButton  resetButton = new JButton ( "Save Data" );
       
       resetButton.setActionCommand (
         InfantMessage.Type.REQUEST_SAVE_FILENAME.name ( ) );
       
       buttonPanel.add ( resetButton );
       
       final JButton  clearButton = new JButton ( "Clear Log" );
       
       buttonPanel.add ( clearButton );
       
       buttonSet.add ( displayButton );
       
       buttonSet.add ( endButton );
       
       buttonSet.add ( resetButton );
       
       buttonSet.add ( loadSetupButton );
       
       // buttonSet.add ( clearButton );
       
       clearButton.addActionListener (
         new ActionListener ( )
         {
           public void  actionPerformed ( final ActionEvent  actionEvent )
           {
             logPanel.clear ( );
           }
         } );
       
       final JPanel  westPanel = new JPanel ( );
       
       westPanel.setLayout (
         new BoxLayout ( westPanel, BoxLayout.Y_AXIS ) );
       
       westPanel.add ( spinnerPanel );
       
       westPanel.add ( buttonPanel );
       
       westPanel.add ( new Box.Filler (
         new Dimension ( 0, 0 ),
         new Dimension ( 0, Integer.MAX_VALUE ),
         new Dimension ( 0, Integer.MAX_VALUE ) ) );
       
       contentPane.add ( westPanel, BorderLayout.WEST );
       
       return controlFrame;       
     }
     
     private static JFrame  createStimulusFrame (
       final InfantComponent      infantComponent,
       final Slot<InfantMessage>  requestSlot )
     //////////////////////////////////////////////////////////////////////
     {       
       final JFrame  displayFrame = new JFrame ( );
       
       displayFrame.addWindowListener (
         new WindowAdapter ( )
         {
           @Override
           public void  windowClosing ( final WindowEvent  windowEvent )
           {
             requestSlot.offer (
               new InfantMessage (
                 InfantMessage.Type.STIMULUS_WINDOW_CLOSING ) );
           }
         } );
       
       displayFrame.setUndecorated ( true );

       final Dimension  screenSize
         = Toolkit.getDefaultToolkit ( ).getScreenSize ( );
       
       displayFrame.setBounds (
         0, 0, screenSize.width, screenSize.height );
       
       final Container  displayContentPane
         = displayFrame.getContentPane ( );
       
       displayContentPane.setLayout ( new BorderLayout ( ) );

       displayContentPane.add ( infantComponent, BorderLayout.CENTER );
       
       return displayFrame;       
     }
     
     private static void  addControllerIndexSpinner (
       final JPanel              spinnerPanel,
       final GridBagConstraints  gridBagConstraints,
       final SpinnerNumberModel  controllerIndexSpinnerNumberModel )
     //////////////////////////////////////////////////////////////////////
     {
       final JSpinner  controllerIndexSpinner
         = new JSpinner ( controllerIndexSpinnerNumberModel );
       
       final JSpinner.NumberEditor  numberEditor
         = new JSpinner.NumberEditor (
         controllerIndexSpinner, "0" );
       
       controllerIndexSpinner.setEditor ( numberEditor );
       
       final JLabel  jLabel = new JLabel ( "Controller" );
       
       jLabel.setBorder (
         BorderFactory.createEmptyBorder ( 2, 2, 2, 2 ) );
       
       gridBagConstraints.gridx = 0;
       
       spinnerPanel.add ( jLabel, gridBagConstraints );
       
       gridBagConstraints.gridx = 1;
       
       spinnerPanel.add ( controllerIndexSpinner, gridBagConstraints );
     }

     private static void  addImageDisplayTimeSpinner (
       final JPanel              spinnerPanel,
       final GridBagConstraints  gridBagConstraints,
       final SpinnerNumberModel  imageDisplayTimeSpinnerNumberModel )
     //////////////////////////////////////////////////////////////////////
     {
       final JSpinner  imageDisplayTimeSpinner
         = new JSpinner ( imageDisplayTimeSpinnerNumberModel );
       
       final JSpinner.NumberEditor  numberEditor
         = new JSpinner.NumberEditor (
         imageDisplayTimeSpinner, "0.0##" );
       
       imageDisplayTimeSpinner.setEditor ( numberEditor );
       
       final JLabel  imageDisplayTimeLabel = new JLabel ( "Duration (s)" );
       
       imageDisplayTimeLabel.setBorder (
         BorderFactory.createEmptyBorder ( 2, 2, 2, 2 ) );
       
       gridBagConstraints.gridx = 0;
       
       spinnerPanel.add ( imageDisplayTimeLabel, gridBagConstraints );
       
       gridBagConstraints.gridx = 1;
       
       spinnerPanel.add ( imageDisplayTimeSpinner, gridBagConstraints );
     }

     private static void  addInterStimulusIntervalSpinner (
       final JPanel              spinnerPanel,
       final GridBagConstraints  gridBagConstraints,
       final SpinnerNumberModel  interStimulusIntervalSpinnerNumberModel )
     //////////////////////////////////////////////////////////////////////
     {
       final JSpinner  interStimulusIntervalSpinner
         = new JSpinner ( interStimulusIntervalSpinnerNumberModel );
       
       final JSpinner.NumberEditor  numberEditor
         = new JSpinner.NumberEditor (
         interStimulusIntervalSpinner, "0.0##" );
       
       interStimulusIntervalSpinner.setEditor ( numberEditor );
       
       final JLabel  jLabel = new JLabel ( "ISI (s)" );
       
       jLabel.setBorder (
         BorderFactory.createEmptyBorder ( 2, 2, 2, 2 ) );
       
       gridBagConstraints.gridx = 0;
       
       spinnerPanel.add ( jLabel, gridBagConstraints );
       
       gridBagConstraints.gridx = 1;
       
       spinnerPanel.add (
         interStimulusIntervalSpinner, gridBagConstraints );
     }

     private static void  addScaleSpinner (
       final JPanel              spinnerPanel,
       final GridBagConstraints  gridBagConstraints,
       final SpinnerNumberModel  spinnerNumberModel )
     //////////////////////////////////////////////////////////////////////
     {
       final JSpinner  jSpinner = new JSpinner ( spinnerNumberModel );
       
       final JSpinner.NumberEditor  numberEditor
         = new JSpinner.NumberEditor ( jSpinner, "0.0##" );
       
       jSpinner.setEditor ( numberEditor );
       
       final JLabel  jLabel = new JLabel ( "Scale" );
       
       jLabel.setBorder (
         BorderFactory.createEmptyBorder ( 2, 2, 2, 2 ) );
       
       gridBagConstraints.gridx = 0;
       
       spinnerPanel.add ( jLabel, gridBagConstraints );
       
       gridBagConstraints.gridx = 1;
       
       spinnerPanel.add ( jSpinner, gridBagConstraints );
     }

     private static String  createLogPrefix ( )
     //////////////////////////////////////////////////////////////////////
     {
       return dateFormat.format ( new Date ( ) ) + ":  ";
     }
     
     private static JScrollPane  createLogScrollPane (
       final InfantConfig  infantConfig,
       final LogPanel      logPanel )
     //////////////////////////////////////////////////////////////////////
     {
       logPanel.record ( infantConfig.getInfo ( ) );
       
       final JScrollPane  jScrollPane = new JScrollPane ( logPanel );
       
       jScrollPane.setBorder (
         BorderFactory.createEtchedBorder ( EtchedBorder.RAISED ) );
       
       return jScrollPane;
     }
     
     private void  loadSetup ( )
     //////////////////////////////////////////////////////////////////////
     {
       final JFileChooser  jFileChooser
         = new JFileChooser ( InfantConfig.getInfantSetupDirPath ( ) );
       
       final int  returnVal = jFileChooser.showOpenDialog ( controlFrame );
       
       if ( returnVal != JFileChooser.APPROVE_OPTION )
       {
         return;
       }
       
       final File  file = jFileChooser.getSelectedFile ( );
       
       if ( file != null )
       {
         requestSlot.offer (
           new InfantMessage (
             InfantMessage.Type.LOAD_SETUP,
             file ) );
       }
     }
     
     private void  getSaveReportFilename (
       final InfantMessage  infantMessage )
     //////////////////////////////////////////////////////////////////////
     {
       final InfantData  infantData
         = ( InfantData ) infantMessage.getValue ( );
       
       final JFileChooser  jFileChooser = new JFileChooser (
         InfantConfig.getInfantReportDirPath ( ) );
       
       final int  returnVal
         = jFileChooser.showSaveDialog ( controlFrame );
       
       if ( returnVal != JFileChooser.APPROVE_OPTION )
       {
         return;
       }
       
       final File  file = jFileChooser.getSelectedFile ( );
       
       if ( file != null )
       {
         requestSlot.offer (
           new InfantMessage (
             InfantMessage.Type.SAVE_DATA,
             new Object [ ] { file, infantData } ) );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }