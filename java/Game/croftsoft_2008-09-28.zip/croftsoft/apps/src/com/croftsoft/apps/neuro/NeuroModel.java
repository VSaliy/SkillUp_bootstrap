    package com.croftsoft.apps.neuro;

    import com.croftsoft.core.ai.neuro.HhNeuron;
     
    /***********************************************************************
    * Neuro model accessor interface.
    * 
    * Read-only access to model state.
    * 
    * @version
    *   $Id: NeuroModel.java,v 1.7 2008/08/24 01:26:27 croft Exp $
    * @since
    *   2008-08-17
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public interface  NeuroModel
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
      
    HhNeuron  getHhNeuron ( );
       
    double    getMembraneVoltage ( int  index );
    
    int       getMembraneVoltageLength ( );
    
    double    getMembraneVoltageMax ( );
    
    int       getSpikeCount ( );
    
    double    getTimeInterval ( );
      
    double    getTimeMin ( );
    
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }