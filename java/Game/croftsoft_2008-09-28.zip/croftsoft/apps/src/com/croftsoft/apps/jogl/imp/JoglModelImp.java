    package com.croftsoft.apps.jogl.imp;
    
    import java.util.*;
     
    import com.croftsoft.core.lang.NullArgumentException;
    import com.croftsoft.core.lang.lifecycle.Updatable;
    import com.croftsoft.core.media.jogl.camera.JoglCamera;
    import com.croftsoft.core.media.jogl.camera.JoglCameraImp;
    import com.croftsoft.core.media.jogl.camera.JoglCameraMut;
    import com.croftsoft.core.media.jogl.render.JoglSpinCube;
    import com.croftsoft.core.util.mail.Mail;

    import com.croftsoft.apps.jogl.JoglConfig;
    import com.croftsoft.apps.jogl.JoglMessage;
    import com.croftsoft.apps.jogl.JoglModel;
    import com.croftsoft.apps.jogl.JoglMoveRequest;
    import com.croftsoft.apps.jogl.JoglMoveState;
    import com.croftsoft.apps.jogl.JoglMoveState.EnumDirection;

    /***********************************************************************
    * Model.
    * 
    * Maintains program state.
    * 
    * @version
    *   $Id: JoglModelImp.java,v 1.19 2008/05/17 01:32:31 croft Exp $
    * @since
    *   2008-02-10
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  JoglModelImp
      implements JoglModel, Updatable
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
      
    private static final double [ ]
      PERTURBATION_FACTORS = { 0.01, 0.10, 1.00, 0 };
    
    private static final double
      ROTATE_DELTA    = 1,
      TRANSLATE_DELTA = 0.1;
       
    // private final instance variables
    
    private final Mail<JoglMessage>      mail;
    
    private final JoglMoveState          joglMoveState;
    
    private final JoglCameraMut          joglCameraMut;
    
    private final JoglSpinCube.ModelImp  joglSpinCubeModelImp;
       
    // model state instance variables
     
    private int  perturbationFactorIndex;
    
    private final Map<EnumDouble, Double>  doubleMap;
    
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public  JoglModelImp (
      final JoglConfig         joglConfig,
      final Mail<JoglMessage>  mail )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        joglConfig,
        this.mail = mail );
      
      doubleMap = new HashMap<EnumDouble, Double> ( );
      
      joglMoveState = new JoglMoveState ( );
      
      joglCameraMut = new JoglCameraImp ( );
      
      joglSpinCubeModelImp = new JoglSpinCube.ModelImp ( );
            
      joglSpinCubeModelImp.setXYZ ( 0, 0, -10 );
      
      joglSpinCubeModelImp.setPerturbationFactor (
        PERTURBATION_FACTORS [ perturbationFactorIndex ] );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // interface Accessor methods
    ////////////////////////////////////////////////////////////////////////
     
    public double  get ( final EnumDouble  enumDouble )
    ////////////////////////////////////////////////////////////////////////
    {
      final Double  d = doubleMap.get ( enumDouble );
      
      return d == null ? 0 : d.doubleValue ( );
    }
    
    public JoglCamera  getJoglCamera ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return joglCameraMut;
    }
    
    public JoglSpinCube.Model  getJoglSpinCubeModel ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return joglSpinCubeModelImp;
    }
    
    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  update ( )
    ////////////////////////////////////////////////////////////////////////
    {
      final int  size = mail.size ( );
      
      for ( int  i = 0; i < size; i++ )
      {
        final JoglMessage  joglMessage = mail.get ( i );
        
        final JoglMessage.Type  type = joglMessage.getType ( );
         
        switch ( type )
        {
          case CHANGE_PERTURBATION_FACTOR_REQUEST:
             
            perturbationFactorIndex = ( perturbationFactorIndex + 1 )
              % PERTURBATION_FACTORS.length;
            
            joglSpinCubeModelImp.setPerturbationFactor (
              PERTURBATION_FACTORS [ perturbationFactorIndex ] );
            
            mail.offer (
              JoglMessage.CHANGE_PERTURBATION_FACTOR_EVENT_INSTANCE );
             
            break;
            
          case MOVE_REQUEST:
            
            processMoveRequest ( ( JoglMoveRequest ) joglMessage );
            
            break;
             
          default:
            
            // ignore
        }
      }
      
      joglSpinCubeModelImp.update ( );
      
      updateMove ( );
    }
    
    ////////////////////////////////////////////////////////////////////////
    // private methods
    ////////////////////////////////////////////////////////////////////////
    
    private void  processMoveRequest (
      final JoglMoveRequest  joglMoveRequest )
    ////////////////////////////////////////////////////////////////////////
    {
      final EnumDirection [ ]  enumDirections = EnumDirection.values ( );
      
      for ( final EnumDirection  enumDirection : enumDirections )
      {
        joglMoveState.set (
          enumDirection,
          joglMoveRequest.get ( enumDirection ) );
      }
    }
/*    
    private void  set (
      final EnumDouble  enumDouble,
      final double      value )
    ////////////////////////////////////////////////////////////////////////
    {
      doubleMap.put ( enumDouble, new Double ( value ) );
    }
*/    
    private void  updateMove ( )
    ////////////////////////////////////////////////////////////////////////
    {
      int
        stepX    = 0,
        stepY    = 0,
        stepZ    = 0,
        stepRotX = 0,
        stepRotY = 0,
        stepRotZ = 0;
      
      final EnumDirection [ ]  enumDirections = EnumDirection.values ( );
      
      for ( final EnumDirection  enumDirection : enumDirections )
      {
        if ( joglMoveState.get ( enumDirection ) )
        {
          switch ( enumDirection )
          {
            case BACKWARD:
              
              stepZ++;
          
              break;
              
            case DOWN:
              
              stepY--;
          
              break;
              
            case FORWARD:
          
              stepZ--;
          
              break;
          
            case LEFT:
              
              stepX--;
              
              break;
              
            case PITCH_DOWN:
              
              stepRotX--;
              
              break;             
          
            case PITCH_UP:
              
              stepRotX++;
              
              break;             
          
            case RIGHT:
              
              stepX++;
              
              break;
          
            case ROLL_LEFT:
              
              stepRotZ++;
              
              break;             
          
            case ROLL_RIGHT:
              
              stepRotZ--;
              
              break;             
          
            case UP:
              
              stepY++;
          
              break;
              
            case YAW_LEFT:
              
              stepRotY++;
              
              break;             
          
            case YAW_RIGHT:
              
              stepRotY--;
              
              break;             
          
            default:
           
              throw new RuntimeException ( );
          }
        }
      }
      
      if ( ( stepX != 0 )
        || ( stepY != 0 )
        || ( stepZ != 0 ) )
      {
        if ( stepX != 0 )
        {
          joglCameraMut.translate (
            JoglCamera.Axis.X,
            TRANSLATE_DELTA * stepX );
        }      

        if ( stepY != 0 )
        {
          joglCameraMut.translate (
            JoglCamera.Axis.Y,
            TRANSLATE_DELTA * stepY );
        }      

        if ( stepZ != 0 )
        {
          joglCameraMut.translate (
            JoglCamera.Axis.Z,
            TRANSLATE_DELTA * stepZ );
        }      
      }
      
      if ( ( stepRotX != 0 )
        || ( stepRotY != 0 )
        || ( stepRotZ != 0 ) )
      {
        if ( stepRotX != 0 )
        {
          joglCameraMut.rotate (
            JoglCamera.Axis.X,
            ROTATE_DELTA * stepRotX );
        }

        if ( stepRotY != 0 )
        {
          joglCameraMut.rotate (
            JoglCamera.Axis.Y,
            ROTATE_DELTA * stepRotY );
        }

        if ( stepRotZ != 0 )
        {
          joglCameraMut.rotate (
            JoglCamera.Axis.Z,
            ROTATE_DELTA * stepRotZ );
        }
      }
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }