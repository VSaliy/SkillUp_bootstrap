    package com.croftsoft.apps.ajgp.data;
    
    import java.io.*;
    import javax.xml.bind.*;

    import com.croftsoft.apps.ajgp.data.EnumData.*;
    
    /*********************************************************************
    * Test of enumerated accessors.
    *
    * @version
    *   $Id: EnumDataTest.java,v 1.2 2007/06/29 03:26:45 croft Exp $
    * @since
    *   2007-06-28
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    *********************************************************************/

    public final class  EnumDataTest
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
      
    public static void  main ( final String [ ]  args )
      throws Exception
    ////////////////////////////////////////////////////////////////////////
    {
      final EnumData  enumData = new EnumDataBean ( );
      
      enumData.set ( EnumInteger.HEALTH, new Integer ( 10 ) );
      
      enumData.set ( EnumInteger.WEALTH, new Integer ( 99 ) );
      
      enumData.set ( EnumInteger.WISDOM, new Integer ( 18 ) );
      
      enumData.set ( EnumString.USER_ID, "croft" );
      
      enumData.set ( EnumString.PLAYER_NAME, "David Wallace Croft" );
      
      enumData.set ( EnumString.CHARACTER_NAME, "Enoch the Elf" );
      
      // convert from bean object to XML
      
      final JAXBContext  jaxbContext
        = JAXBContext.newInstance ( EnumDataBean.class );
      
      final Marshaller  marshaller = jaxbContext.createMarshaller ( ); 
      
      marshaller.setProperty (
        Marshaller.JAXB_FORMATTED_OUTPUT,
        Boolean.TRUE );

      final ByteArrayOutputStream  byteArrayOutputStream
        = new ByteArrayOutputStream ( );

      marshaller.marshal ( enumData, byteArrayOutputStream );
      
      final byte [ ]  byteArray = byteArrayOutputStream.toByteArray ( ); 
      
      System.out.println ( new String ( byteArray, "UTF-8" ) );
      
      // convert from XML to bean object
      
      final Unmarshaller  unmarshaller = jaxbContext.createUnmarshaller ( );
      
      final EnumData  enumData2
        = ( EnumData ) unmarshaller.unmarshal (
          new ByteArrayInputStream ( byteArray ) );
      
      System.out.println ( "" );
      
      for ( final EnumInteger  enumInteger : EnumInteger.values ( ) )
      {
        System.out.println ( enumData2.get ( enumInteger ) );
      }
      
      for ( final EnumString  enumString : EnumString.values ( ) )
      {
        System.out.println ( enumData2.get ( enumString ) );
      }      
    }
    
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }