    package com.croftsoft.apps.exemplar;
     
    import java.awt.event.*;

    import com.croftsoft.core.gui.controller.NilController;
    import com.croftsoft.core.lang.NullArgumentException;
    import com.croftsoft.core.lang.lifecycle.Startable;
import com.croftsoft.core.util.slot.Slot;

    /***********************************************************************
    * Exemplar controller.
    * 
    * Modifies the Model based on user input.
    * 
    * @version
    *   $Id: ExemplarController.java,v 1.6 2008/09/20 05:01:49 croft Exp $
    * @since
    *   2005-03-16
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  ExemplarController
      extends NilController
      implements Startable
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private final Slot<ExemplarMessage>  requestSlot;
     
    //
     
    private boolean  mouseClicked;
     
    ////////////////////////////////////////////////////////////////////////
    // constructor method
    ////////////////////////////////////////////////////////////////////////
     
    public  ExemplarController ( final Slot<ExemplarMessage>  requestSlot )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs ( this.requestSlot = requestSlot );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // listener methods
    ////////////////////////////////////////////////////////////////////////     
     
    @Override
    public void  mouseClicked ( final MouseEvent  mouseEvent )
    ////////////////////////////////////////////////////////////////////////
    {
      mouseClicked = true;
    }
     
    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      mouseClicked = false;
    }
     
    @Override
    public void  update ( )
    ////////////////////////////////////////////////////////////////////////
    {
      if ( mouseClicked )
      {
        mouseClicked = !requestSlot.offer (
          ExemplarMessage.INCREMENT_CLICK_COUNT_INSTANCE );
      }
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }