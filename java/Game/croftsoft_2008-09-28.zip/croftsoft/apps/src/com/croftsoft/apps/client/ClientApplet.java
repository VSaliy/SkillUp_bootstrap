     package com.croftsoft.apps.client;
     
     import javax.swing.JApplet;
     
     import com.croftsoft.core.lang.lifecycle.*;
     
     /*********************************************************************
     * Applet.
     *
     * @version
     *   $Id: ClientApplet.java,v 1.4 2006/12/09 05:15:29 croft Exp $
     * @since
     *   2006-10-30
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/
     
     public final class  ClientApplet
       extends JApplet
       implements Lifecycle
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final long  serialVersionUID = 0L;
     
     //
     
     private static final String  PARAM_BOT_ID = "botid";
     
     //
       
     private final ClientMain  chatMain;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
       
     public  ClientApplet ( )
     //////////////////////////////////////////////////////////////////////
     {
       chatMain = new ClientMain ( null );
     }
     
     //////////////////////////////////////////////////////////////////////
     // overridden applet methods
     //////////////////////////////////////////////////////////////////////
     
     @Override
     public String  getAppletInfo ( )
     //////////////////////////////////////////////////////////////////////
     {
       return chatMain.getClientConfig ( ).getInfo ( );
     }
     
     @Override
     public void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       final ClientConfig  clientConfig = chatMain.getClientConfig ( );
       
       clientConfig.setCodeBase ( getCodeBase ( ) );
       
       chatMain.setContentPane ( getContentPane ( ) );
       
       final String  botId = getParameter ( PARAM_BOT_ID );
       
       clientConfig.setBotId ( botId );
       
       LifecycleLib.init ( chatMain );
     }
     
     @Override
     public void  start ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.start ( chatMain );
     }
     
     @Override
     public void  stop ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.stop ( chatMain );
     }
     
     @Override
     public void  destroy ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.destroy ( chatMain );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }