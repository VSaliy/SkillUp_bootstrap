     package com.croftsoft.apps.cyborg;
     
     import java.awt.*;
     import java.awt.event.*;
     import javax.swing.*;
     
     import com.croftsoft.core.animation.*;
     import com.croftsoft.core.animation.animator.FrameRateAnimator;
     import com.croftsoft.core.lang.NullArgumentException;
     import com.croftsoft.core.lang.lifecycle.Initializable;
     
     /*********************************************************************
     * Graphical representation of the model.
     * 
     * @version
     *   $Date: 2008/04/19 21:30:59 $
     * @since
     *   2005-03-16
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  CyborgAnimator     
       implements ComponentAnimator, Initializable
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final Color
       BACKGROUND = Color.WHITE,
       FOREGROUND = Color.BLACK;
     
     private static final int
       OFFSET_X      =  60,
       SQUARE_HALF   = 100,
       OFFSET_Y_TOP  =  10,
       OFFSET_Y      = OFFSET_Y_TOP + 2 * SQUARE_HALF + 10,
       CURSOR_RADIUS =  10,
       OFFSET_SPIKES = OFFSET_Y + 2 * SQUARE_HALF;
     
     //
     
     private final CyborgModel  cyborgModel;
     
     private final Component    component;
       
     private final Rectangle    componentBounds;
     
     //
     
     private boolean            componentResized;
       
     private FrameRateAnimator  frameRateAnimator;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public static int  fromX ( double  x )
     //////////////////////////////////////////////////////////////////////
     {
       return ( int ) ( SQUARE_HALF * x ) + OFFSET_X + SQUARE_HALF;
     }
     
     public static int  fromY ( double  y )
     //////////////////////////////////////////////////////////////////////
     {
       return ( int ) ( -SQUARE_HALF * y ) + OFFSET_Y + SQUARE_HALF;
     }
     
     public static double  toX ( int  x )
     //////////////////////////////////////////////////////////////////////
     {
       return ( x - OFFSET_X - SQUARE_HALF ) / ( double ) SQUARE_HALF;
     }
     
     public static double  toY ( int  y )
     //////////////////////////////////////////////////////////////////////
     {
       return -( y - OFFSET_Y - SQUARE_HALF ) / ( double ) SQUARE_HALF;
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  CyborgAnimator (
       CyborgModel  cyborgModel,
       Component    component )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.check ( this.cyborgModel = cyborgModel );
       
       NullArgumentException.check ( this.component   = component   );       
       
       component.requestFocus ( );
       
       component.addComponentListener (
         new ComponentAdapter ( )
         {
           public void  componentResized ( ComponentEvent  componentEvent )
           {
             componentResized = true;
           }
         } );
       
       componentBounds  = new Rectangle ( );
       
       componentResized = true;
     }
       
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       frameRateAnimator = new FrameRateAnimator ( component ); 
     }
     
     public void  update ( JComponent  jComponent )
     //////////////////////////////////////////////////////////////////////
     {
       if ( componentResized )
       {
         componentResized = false;
         
         jComponent.repaint ( );
         
         jComponent.getBounds ( componentBounds );
         
         componentBounds.x = 0;
       }
       
       frameRateAnimator.update ( jComponent );
       
       if ( cyborgModel.getAnimate ( ) )
       {       
         jComponent.repaint ( );
       }
     }     
     
     public void  paint (
       JComponent  jComponent,
       Graphics2D  graphics2D )
     //////////////////////////////////////////////////////////////////////
     {
       graphics2D.setColor ( BACKGROUND );
       
       graphics2D.fill ( componentBounds );
       
       graphics2D.setColor ( FOREGROUND );
       
       double  x = cyborgModel.getX ( );
       
       double  y = cyborgModel.getY ( );
       
       double  aimX = cyborgModel.getAimX ( );
       
       double  aimY = cyborgModel.getAimY ( );
       
       String  text = String.format (
         "%1$+1.3f %2$+1.3f%n",
         new Object [ ] {
           new Double ( aimX ),
           new Double ( aimY ) } );
       
       graphics2D.drawString ( text, OFFSET_X, OFFSET_SPIKES + 225 );
       
       text = String.format (
         "%1$+1.3f %2$+1.3f%n",
         new Object [ ] {
           new Double ( x ),
           new Double ( y ) } );
       
       graphics2D.drawString ( text, OFFSET_X, OFFSET_SPIKES + 250 );
       
       boolean [ ] [ ]  spikeRasters = cyborgModel.getSpikeRasters ( );
       
       for ( int  i = 0; i < spikeRasters.length; i++ )
       {
         boolean [ ]  spikeRaster = spikeRasters [ i ];
         
         graphics2D.drawLine (
           OFFSET_X,
           OFFSET_SPIKES + 20 + i * 50,
           OFFSET_X + spikeRaster.length - 1,
           OFFSET_SPIKES + 20 + i * 50 );
         
         int  spikeCount = 0;
         
         for ( int  j = 0; j < spikeRaster.length; j++ )
         {
           if ( spikeRaster [ j ] )
           {
             spikeCount++;
             
             graphics2D.drawLine (
               OFFSET_X + j,
               OFFSET_SPIKES + 20 + i * 50,
               OFFSET_X + j,
               OFFSET_SPIKES + 20 + i * 50 - 10 );
           }
         }
         
         String  rate = Integer.toString ( spikeCount );
         
         graphics2D.drawString (
           rate,
           OFFSET_X,
           OFFSET_SPIKES + 40 + i * 50 );
       }
       
       graphics2D.drawRect (
         OFFSET_X, OFFSET_Y_TOP, 2 * SQUARE_HALF, 2 * SQUARE_HALF );
       
       graphics2D.drawRect (
         OFFSET_X, OFFSET_Y, 2 * SQUARE_HALF, 2 * SQUARE_HALF );
       
       graphics2D.drawOval (
         fromX ( x ) - CURSOR_RADIUS,
         fromY ( y ) - CURSOR_RADIUS - ( OFFSET_Y - OFFSET_Y_TOP ),
         2 * CURSOR_RADIUS,
         2 * CURSOR_RADIUS );
       
       int  targetRadius
         = ( int ) ( 2 * SQUARE_HALF * cyborgModel.getTargetRadius ( ) );
       
       int  targetCenterX
         = fromX ( cyborgModel.getTargetCenterX ( ) );
       
       int  targetCenterY
         = fromY ( cyborgModel.getTargetCenterY ( ) );
       
       graphics2D.drawOval (
         targetCenterX - targetRadius,
         targetCenterY - targetRadius - ( OFFSET_Y - OFFSET_Y_TOP ),
         2 * targetRadius,
         2 * targetRadius );
       
       graphics2D.drawLine (
         fromX ( 0.0 ),
         fromY ( 0.0 ),
         fromX ( aimX ),
         fromY ( aimY ) );
       
       frameRateAnimator.paint ( jComponent, graphics2D );
     }     
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }