     package com.croftsoft.apps.jinput;

     import net.java.games.input.Component;
     import net.java.games.input.Controller;
     import net.java.games.input.ControllerEnvironment;

     /*********************************************************************
     * Tests connecting to a joystick using JInput.
     *  
     * @version
     *   $Id: Joystick.java,v 1.5 2005/12/19 02:26:05 croft Exp $
     * @since
     *   2005-03-14
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  Joystick
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     public static void  main ( String [ ]  args )
     //////////////////////////////////////////////////////////////////////
     {
       final ControllerEnvironment  controllerEnvironment
         = ControllerEnvironment.getDefaultEnvironment ( );
       
       final Controller [ ]  controllers
         = controllerEnvironment.getControllers ( );
       
       if ( controllers.length == 0 )
       {
         System.out.println ( "No controllers found." );
         
         return;
       }
       
       for ( int  i = 0; i < controllers.length; i++ )
       {
         Controller  controller = controllers [ i ];
         
         System.out.println ( "Controller " + i + " *******************" );
         
         System.out.println ( controller.getName ( ) );
         
         System.out.println ( controller.getType ( ) );
         
         Controller [ ]  childControllers = controller.getControllers ( );
         
         System.out.println ( "child controllers:  " + childControllers.length );
         
         Component [ ]  axes = controller.getComponents ( );
         
         for ( int  j = 0; j < axes.length; j++ )
         {
           Component  axis = axes [ j ];
           
           System.out.println (
             "axis " + j + " isAnalog:  " + axis.isAnalog ( ) );
         }       
       }
         
       poll ( controllers [ 5 ] );
     }
     
     public static void  poll ( Controller  controller )
     //////////////////////////////////////////////////////////////////////
     {
       Component [ ]  components = controller.getComponents ( );
       
       Float [ ]  floats = new Float [ components.length ];
       
       String  format = "";
       
       for ( int  i = 0; i < components.length; i++ )
       {
         format += "%" + ( i + 1 ) + "$+1.3f ";
       }
       
       format += "%n";
       
       final long  endTime = System.currentTimeMillis ( ) + 30 * 1000;  
       
       while ( System.currentTimeMillis ( ) < endTime )
       {
         if ( !controller.poll ( ) )
         {
           break;
         }
         
         for ( int  i = 0; i < components.length; i++ )
         {
           Component  component = components [ i ];
           
           floats [ i ] = new Float ( component.getPollData ( ) );
         }

         System.out.printf ( format, ( Object [ ] ) floats );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }