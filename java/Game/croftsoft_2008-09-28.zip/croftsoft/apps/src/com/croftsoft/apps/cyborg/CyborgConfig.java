     package com.croftsoft.apps.cyborg;
     
     import java.awt.*;
     
     import com.croftsoft.core.CroftSoftConstants;
     import com.croftsoft.core.lang.*;
     import com.croftsoft.core.util.log.*;
     
     /*********************************************************************
     * Configuration.
     *  
     * @version
     *   $Id: CyborgConfig.java,v 1.30 2005/12/19 02:31:00 croft Exp $
     * @since
     *   2005-08-12
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public class  CyborgConfig
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     public static final CyborgConfig  INSTANCE = new CyborgConfig ( );
     
     //
       
     public static final String  VERSION
       = "$Date: 2005/12/19 02:31:00 $";
     
     public static final String  TITLE
       = "CroftSoft Newt Cyborg";
     
     public static final String  INFO
       = TITLE + "\n"
       + "Version " + VERSION + "\n"
       + CroftSoftConstants.COPYRIGHT + "\n"
       + CroftSoftConstants.DEFAULT_LICENSE + "\n"
       + CroftSoftConstants.HOME_PAGE + "\n";
       
     public static final String  FRAME_TITLE  = TITLE;
     
     public static final int
       COMPONENT_MIN_WIDTH  = 340,
       COMPONENT_MIN_HEIGHT = 540,
       FRAME_WIDTH          = 800,
       FRAME_HEIGHT         = 750; // leave pad for applet warning
     
     public static final Dimension  FRAME_SIZE
       = new Dimension ( FRAME_WIDTH, FRAME_HEIGHT );
     
     public static final int     FRAME_RATE   = 200;
     
     public static final String  SHUTDOWN     = null;
     
     public static final String  FRAME_ICON   = null;
     
     public static final Cursor  CURSOR
       = new Cursor ( Cursor.CROSSHAIR_CURSOR );
     
     public static final Font    FONT
       = new Font ( "Arioso", Font.BOLD, 20 );
     
     public static final String
       ACTION_COMMAND_ANIMATE      = "Animate",
       ACTION_COMMAND_AUTOMATIC    = "Automatic",
       ACTION_COMMAND_FORCE_LENGTH = "Force-length",
       ACTION_COMMAND_MANUAL       = "Manual",
       ACTION_COMMAND_PAUSE        = "Pause",
       ACTION_COMMAND_REALTIME     = "Real-time",
       ACTION_COMMAND_RESET        = "Reset",
       ACTION_COMMAND_RESUME       = "Resume";
       
     
     public static final String
       JOYSTICK_TRANSFORM_OPTION_CUMULATIVE  = "Cumulative",
       JOYSTICK_TRANSFORM_OPTION_EXPONENTIAL = "Exponential",
       JOYSTICK_TRANSFORM_OPTION_LINEAR      = "Linear",
       JOYSTICK_TRANSFORM_OPTION_LOGARITHMIC = "Logarithmic",
       JOYSTICK_TRANSFORM_OPTION_SIGMOIDAL   = "Sigmoidal";
     
     public static final String [ ]  JOYSTICK_TRANSFORM_OPTIONS = {
       JOYSTICK_TRANSFORM_OPTION_CUMULATIVE,
       JOYSTICK_TRANSFORM_OPTION_EXPONENTIAL,
       JOYSTICK_TRANSFORM_OPTION_LINEAR,
       JOYSTICK_TRANSFORM_OPTION_LOGARITHMIC,
       JOYSTICK_TRANSFORM_OPTION_SIGMOIDAL };
     
     public static final double
       DEFAULT_MAX    = 120.0,
       DELTA          =   1.0,
       OPERATOR_DELTA =   0.01;
     
     public static final int  PLOT_SIZE = 101; // should be odd number
     
     public static final double
       GAIN_SCALE   = 100.0,
       OFFSET_SCALE = 100.0;
     
     public static final long  OPERATOR_DELAY_MILLIS = 100;
   
     //
     
     private Log  log;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public Log  getLog ( )
     //////////////////////////////////////////////////////////////////////
     {
       return log;
     }
     
     public void  setLog ( Log  log )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.check ( this.log = log );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     private  CyborgConfig ( )
     //////////////////////////////////////////////////////////////////////
     {
       setLog ( PrintStreamLog.SYSTEM_OUT_INSTANCE );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }