    package com.croftsoft.apps.exemplar;
     
    import com.croftsoft.core.lang.NullArgumentException;
     
    /***********************************************************************
    * Exemplar enumerated type message.
    * 
    * Use to pass messages between the model, view, and controller.
    * 
    * @version
    *   $Id: ExemplarMessage.java,v 1.4 2008/02/15 22:38:03 croft Exp $
    * @since
    *   2006-06-22
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  ExemplarMessage
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    public static final ExemplarMessage
      CLICK_COUNT_CHANGED_INSTANCE
        = new ExemplarMessage ( Type.CLICK_COUNT_CHANGED ),
      INCREMENT_CLICK_COUNT_INSTANCE
        = new ExemplarMessage ( Type.INCREMENT_CLICK_COUNT );
     
    //
     
    public enum  Type
    {
      CLICK_COUNT_CHANGED,
      INCREMENT_CLICK_COUNT;
    }
     
    //
       
    private final Type    type;
     
    private final Object  content;
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public  ExemplarMessage (
      final Type    type,
      final Object  content )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.check ( this.type = type );
       
      this.content = content;
    }
     
    public  ExemplarMessage ( final Type  type )
    ////////////////////////////////////////////////////////////////////////
    {
      this ( type, null );
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public Type    getType    ( ) { return type;    }
     
    public Object  getContent ( ) { return content; }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }