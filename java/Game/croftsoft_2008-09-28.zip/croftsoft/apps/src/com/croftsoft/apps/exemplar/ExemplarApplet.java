    package com.croftsoft.apps.exemplar;
     
    import javax.swing.JApplet;
     
    import com.croftsoft.core.lang.lifecycle.*;
     
    /***********************************************************************
    * Applet.
    *
    * @version
    *   $Id: ExemplarApplet.java,v 1.4 2008/02/15 22:38:03 croft Exp $
    * @since
    *   2006-12-16
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/
     
    public final class  ExemplarApplet
      extends JApplet
      implements Lifecycle
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private static final long  serialVersionUID = 0L;
     
    //
     
    // private static final String  EXAMPLE_PARAMETER = "example";
     
    //
       
    private final ExemplarMain  exemplarMain;
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
       
    public  ExemplarApplet ( )
    ////////////////////////////////////////////////////////////////////////
    {
      exemplarMain = new ExemplarMain ( null );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // overridden applet methods
    ////////////////////////////////////////////////////////////////////////
     
    @Override
    public String  getAppletInfo ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return exemplarMain.getExemplarConfig ( ).getInfo ( );
    }
     
    @Override
    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      // final ExemplarConfig  exemplarConfig
      //   = exemplarMain.getExemplarConfig ( );
       
      // exemplarConfig.setCodeBase ( getCodeBase ( ) );
       
      exemplarMain.setContentPane ( getContentPane ( ) );
       
      // exemplarConfig.setExampleParameter (
      //   getParameter ( EXAMPLE_PARAMETER ) );
       
      LifecycleLib.init ( exemplarMain );
    }
     
    @Override
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.start ( exemplarMain );
    }
     
    @Override
    public void  stop ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.stop ( exemplarMain );
    }
     
    @Override
    public void  destroy ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.destroy ( exemplarMain );
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }