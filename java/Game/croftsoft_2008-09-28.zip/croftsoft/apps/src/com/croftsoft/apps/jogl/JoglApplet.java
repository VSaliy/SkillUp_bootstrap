    package com.croftsoft.apps.jogl;
     
    import javax.swing.JApplet;
     
    import com.croftsoft.core.lang.lifecycle.*;
     
    /***********************************************************************
    * Applet wrapper.
    *
    * @version
    *   $Id: JoglApplet.java,v 1.4 2008/02/18 23:28:00 croft Exp $
    * @since
    *   2008-02-10
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/
     
    public final class  JoglApplet
      extends JApplet
      implements Lifecycle
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private static final long  serialVersionUID = 0L;
     
    //
     
    // private static final String  EXAMPLE_PARAMETER = "example";
     
    //
       
    private final JoglMain  joglMain;
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
       
    public  JoglApplet ( )
    ////////////////////////////////////////////////////////////////////////
    {
      joglMain = new JoglMain ( null );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // overridden applet methods
    ////////////////////////////////////////////////////////////////////////
     
    @Override
    public String  getAppletInfo ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return joglMain.getJoglConfig ( ).getInfo ( );
    }
     
    @Override
    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      // final JoglConfig  joglConfig
      //   = joglMain.getJoglConfig ( );
       
      // joglConfig.setCodeBase ( getCodeBase ( ) );
       
      joglMain.setContentPane ( getContentPane ( ) );
       
      // joglConfig.setExampleParameter (
      //   getParameter ( EXAMPLE_PARAMETER ) );
       
      LifecycleLib.init ( joglMain );
    }
     
    @Override
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.start ( joglMain );
    }
     
    @Override
    public void  stop ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.stop ( joglMain );
    }
     
    @Override
    public void  destroy ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.destroy ( joglMain );
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }