    package com.croftsoft.apps.ajgp.data;

    /*********************************************************************
    * Example of enumerated accessors.
    *
    * @version
    *   $Id: EnumData.java,v 1.3 2007/06/29 03:13:51 croft Exp $
    * @since
    *   2007-06-28
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    *********************************************************************/

    public interface  EnumData
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
      
    public enum  EnumInteger
    {
      HEALTH,
      WEALTH,
      WISDOM,
    }
    
    public enum  EnumString
    {
      CHARACTER_NAME,
      PLAYER_NAME,
      USER_ID,
    }

    ////////////////////////////////////////////////////////////////////////
    // accessor methods
    ////////////////////////////////////////////////////////////////////////

    public Integer  get ( EnumInteger  enumInteger );
    
    public String   get ( EnumString   enumString  );

    ////////////////////////////////////////////////////////////////////////
    // mutator methods
    ////////////////////////////////////////////////////////////////////////

    public void  set (
      EnumInteger  enumInteger,
      Integer      value );
    
    public void  set (
      EnumString  enumString,
      String      value );

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }