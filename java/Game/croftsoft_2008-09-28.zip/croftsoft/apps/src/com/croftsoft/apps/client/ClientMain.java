     package com.croftsoft.apps.client;
     
     import java.awt.*;
     import java.util.*;
     import java.util.concurrent.*;
     import javax.swing.*;
     
     import com.croftsoft.core.gui.LifecycleWindowListener;
     import com.croftsoft.core.lang.lifecycle.*;
     import com.croftsoft.core.util.loop.*;
     
     /*********************************************************************
     * Main.
     *
     * Launches the application within a framework.
     * 
     * @version
     *   $Id: ClientMain.java,v 1.7 2006/12/09 05:23:45 croft Exp $
     * @since
     *   2006-10-30
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  ClientMain
       implements Lifecycle
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private final ClientConfig      clientConfig;
       
     private final ClientModel       clientModel;
     
     private final ClientNet         clientNet;
     
     private final ClientView        clientView;
       
     private final Looper            looper;
     
     private final Queue<ClientMessage>
       modelQueue,
       viewQueue;
     
     private final BlockingQueue<ClientMessage>  netQueue;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
       
     public static void  main ( final String [ ]  args )
     //////////////////////////////////////////////////////////////////////
     {
       final ClientMain  clientMain = new ClientMain ( args );
       
       final JFrame  jFrame = new JFrame (
         clientMain.clientConfig.getFrameTitle ( ) );
       
       clientMain.setContentPane ( jFrame.getContentPane ( ) );
       
       // The Frame is the framework.
       
       LifecycleWindowListener.launchFrameAsDesktopApp (
         jFrame,
         clientMain,
         clientMain.clientConfig.getFrameSize ( ),
         clientMain.clientConfig.getShutdownConfirmationPrompt ( ) );
     }
       
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  ClientMain ( final String [ ]  args )
     //////////////////////////////////////////////////////////////////////
     {
       clientConfig = ClientConfig.load ( args );
       
       System.out.println ( "\n" + clientConfig.getInfo ( ) );
       
       modelQueue = new LinkedList<ClientMessage> ( );
       
       viewQueue  = new LinkedList<ClientMessage> ( );
       
       netQueue   = new LinkedBlockingQueue<ClientMessage> ( );
       
       clientModel = new ClientModel ( modelQueue, viewQueue, netQueue );
       
       clientNet = new ClientNet ( clientConfig, netQueue, modelQueue );
       
       clientView = new ClientView ( clientConfig, viewQueue, modelQueue );
       
       final Updatable [ ]  updatables = new Updatable [ ] {
         clientModel,
         clientView };
       
       looper = new Looper (
         new EventQueueUpdateLoop ( updatables ), // loopable
         new NanoTimeLoopGovernor ( clientConfig.getUpdateRate ( ) ),
         null, // exceptionHandler
         clientConfig.getThreadName ( ),
         Thread.MIN_PRIORITY,
         true ); // useDaemonThread
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public ClientConfig  getClientConfig ( ) { return clientConfig; }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  setContentPane ( final Container  contentPane )
     //////////////////////////////////////////////////////////////////////
     {
       clientView.setContentPane ( contentPane );
     }
     
     //////////////////////////////////////////////////////////////////////
     // interface Lifecycle methods
     //////////////////////////////////////////////////////////////////////
     
     public void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.init ( clientView, looper, clientNet );
     }
     
     public void  start ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.start ( clientView, looper, clientNet );
     }
     
     public void  stop ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.stop ( clientNet, clientView, looper );
     }
     
     public void  destroy ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.destroy ( clientNet, clientView, looper );
     }     
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }