     package com.croftsoft.apps.road.model;

     import java.awt.*;
     
     import com.croftsoft.core.animation.model.Model;

     /*********************************************************************
     * Roadrunner car.
     *
     * @version
     *   2003-11-09
     * @since
     *   2003-11-09
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public interface  Car
       extends Model
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     public void  setDestinationPoint ( Point  destinationPoint );

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }