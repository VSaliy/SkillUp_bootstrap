    package com.croftsoft.apps.infant;
     
    import java.awt.*;
    import java.io.*;
    import java.util.*;
     
    import com.croftsoft.core.CroftSoftConstants;
    import com.croftsoft.core.beans.XmlBeanCoder;
    import com.croftsoft.core.gui.CursorLib;
    import com.croftsoft.core.math.MathConstants;
    import com.croftsoft.core.util.log.*;

    /***********************************************************************
    * Configuration.
    *  
    * @version
    *   $Id: InfantConfig.java,v 1.31 2007/06/29 01:09:13 croft Exp $
    * @since
    *   2006-01-03
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  InfantConfig
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private static final String  VERSION
      = "$Date: 2007/06/29 01:09:13 $";

    private static final String  TITLE
      = "CroftSoft Infant";

    private static final String  INFO
      = TITLE + "\n"
      + "Version " + VERSION + "\n"
      + CroftSoftConstants.COPYRIGHT + "\n"
      + CroftSoftConstants.DEFAULT_LICENSE + "\n"
      + CroftSoftConstants.HOME_PAGE + "\n";

    private static final String
      CONFIG_FILENAME        = "config.xml",
      REPORT_DIR             = "data",
      SETUP_DIR              = "setup",
      DEFAULT_SETUP_FILENAME = "setup.txt";

    private static final int
      FRAME_WIDTH  = 800,
      FRAME_HEIGHT = 750; // leave pad for applet warning

    private static final double  UPDATE_RATE = 100.0;

    private static final Color
      BACKGROUND_COLOR = Color.BLACK,
      FOREGROUND_COLOR = Color.WHITE;

    private static final String
      SHUTDOWN_CONFIRMATION_PROMPT = null; // "Exit " + TITLE + "?";

    private static final Font    FONT
      = new Font ( "Arioso", Font.BOLD, 20 );

    private static final String [ ]  IMAGE_FILENAMES = {
      "image0.png",
      "image1.bmp",
      "image2.bmp",
      "image3.bmp",
      "image4.bmp",
      "image5.bmp",
      "image6.bmp" };

    private static final long
      IMAGE_DISPLAY_TIME
        = 400 * MathConstants.NANOSECONDS_PER_MILLISECOND,
      INTER_STIMULUS_INTERVAL
        = 1 * MathConstants.NANOSECONDS_PER_SECOND;

    private static final int  LOG_LINES_MAX = 1000;
    
    private static final double  SCALE = 1.0;

    //

    private transient boolean     dirty;

    private transient String [ ]  imagePaths;

    private transient Log         log;

    //

    private int  controllerIndex;

    private long
      imageDisplayTime,
      interStimulusInterval;
    
    private double  scale;

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    public static String  getInfantDirPath ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return System.getProperty ( "user.home" )
        + File.separator
        + ".croftsoft"
        + File.separator
        + "infant";
    }

    public static String  getInfantImagesDirPath ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return getInfantDirPath ( )
        + File.separator
        + "images";
    }

    public static String  getInfantReportDirPath ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return getInfantDirPath ( )
        + File.separator
        + REPORT_DIR;
    }

    public static String  getInfantSetupDirPath ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return getInfantDirPath ( )
        + File.separator
        + SETUP_DIR;
    }

    public static InfantConfig  load ( )
    ////////////////////////////////////////////////////////////////////////
    {
      createLocalFiles ( );

      try
      {
        final File  file
          = new File ( getInfantDirPath ( ), CONFIG_FILENAME );

        if ( file.exists ( ) )
        {
          final InfantConfig  infantConfig
            = ( InfantConfig ) XmlBeanCoder.loadFromXmlFile ( file );

          return infantConfig;
        }
      }
      catch ( IOException  ex )
      {
        ex.printStackTrace ( );
      }

      return new InfantConfig ( );
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////

    public  InfantConfig ( )
    ////////////////////////////////////////////////////////////////////////
    {
      createImagePaths ( );

      imageDisplayTime = IMAGE_DISPLAY_TIME;

      interStimulusInterval = INTER_STIMULUS_INTERVAL;
      
      scale = SCALE;
    }

    ////////////////////////////////////////////////////////////////////////
    // accessor methods
    ////////////////////////////////////////////////////////////////////////

    public Color  getBackgroundColor ( ) { return BACKGROUND_COLOR; }

    public int  getControllerIndex ( ) { return controllerIndex; }

    public Cursor  getCursor ( )
      { return CursorLib.createInvisibleCursor ( ); }

    public Color  getForegroundColor ( ) { return FOREGROUND_COLOR; }

    public String  getInfo ( ) { return INFO; }

    public Font  getFont ( ) { return FONT; }

    public Dimension  getFrameSize ( )
      { return new Dimension ( FRAME_WIDTH, FRAME_HEIGHT ); }

    public String  getFrameTitle ( ) { return TITLE; }

    public long  getImageDisplayTime ( ) { return imageDisplayTime; }

    public long  getInterStimulusInterval ( )
      { return interStimulusInterval; }

    public String [ ]  getImagePaths ( ) { return imagePaths; }

    public Log  getLog ( ) { return log; }

    public int  getLogLinesMax ( ) { return LOG_LINES_MAX; }
    
    public double  getScale ( ) { return scale; }

    public String  getShutdownConfirmationPrompt ( )
      { return SHUTDOWN_CONFIRMATION_PROMPT; }

    public String  getThreadName ( ) { return TITLE; }

    public double  getUpdateRate ( ) { return UPDATE_RATE; }

    ////////////////////////////////////////////////////////////////////////
    // mutator methods
    ////////////////////////////////////////////////////////////////////////

    public void  setControllerIndex ( final int  controllerIndex )
    ////////////////////////////////////////////////////////////////////////
    {
      if ( controllerIndex == this.controllerIndex )
      {
        return;
      }

      this.controllerIndex = controllerIndex;

      dirty = true;
    }

    public void  setImageDisplayTime ( final long  imageDisplayTime )
    ////////////////////////////////////////////////////////////////////////
    {
      this.imageDisplayTime = imageDisplayTime;
      
      dirty = true;
    }

    public void  setInterStimulusInterval (
      final long  interStimulusInterval )
    ////////////////////////////////////////////////////////////////////////
    {
      this.interStimulusInterval = interStimulusInterval;
      
      dirty = true;
    }

    public void  setLog ( final Log  log ) { this.log = log; }
    
    public void  setScale ( final double  scale )
    ////////////////////////////////////////////////////////////////////////
    {
      this.scale = scale;
      
      dirty = true;
    }

    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////

    public void  saveIfChanged ( final InfantAccessor  infantAccessor )
      throws IOException
    ////////////////////////////////////////////////////////////////////////
    {
      final long  imageDisplayTime
        = infantAccessor.getImageDisplayTime ( );

      final long  interStimulusInterval
        = infantAccessor.getInterStimulusInterval ( );

      if ( !dirty
        && ( imageDisplayTime      == this.imageDisplayTime      )
        && ( interStimulusInterval == this.interStimulusInterval ) )
      {
        return;
      }

      setImageDisplayTime ( imageDisplayTime );

      setInterStimulusInterval ( interStimulusInterval );

      final String  infantDirPath = getInfantDirPath ( );

      XmlBeanCoder.saveToXmlFile (
        this,
        new File ( infantDirPath, CONFIG_FILENAME ) );

      dirty = false;
    }

    ////////////////////////////////////////////////////////////////////////
    // private static methods
    ////////////////////////////////////////////////////////////////////////

    private static void  createLocalFiles ( )
    ////////////////////////////////////////////////////////////////////////
    {
      try
      {

        final File  reportDirFile
          = new File ( getInfantReportDirPath ( ) );

        if ( !reportDirFile.exists ( ) )
        {
          reportDirFile.mkdirs ( );
        }

        final File  imagesDirFile
          = new File ( getInfantImagesDirPath ( ) );

        if ( !imagesDirFile.exists ( ) )
        {
          imagesDirFile.mkdirs ( );

          for ( String  filename : IMAGE_FILENAMES )
          {
            copyLocalFile (
              "images/" + filename,
              imagesDirFile,
              filename );
          }
        }

        final File  setupDirFile
        = new File ( getInfantSetupDirPath ( ) );

        if ( !setupDirFile.exists ( ) )
        {
          setupDirFile.mkdirs ( );

          copyLocalFile (
            "setup/" + DEFAULT_SETUP_FILENAME,
            setupDirFile,
            DEFAULT_SETUP_FILENAME );
        }
      }
      catch ( Exception  ex )
      {
        ex.printStackTrace ( );
      }     
    }

    private static void  copyLocalFile (
      final String  resourceFilename,
      final File    dirFile,
      final String  filename )
    ////////////////////////////////////////////////////////////////////////
    {
      final ClassLoader  classLoader
      = InfantConfig.class.getClassLoader ( );

      InputStream   inputStream  = null;

      OutputStream  outputStream = null;

      try
      {
        inputStream = new BufferedInputStream (
          classLoader.getResourceAsStream ( resourceFilename ) );

        final File  file = new File ( dirFile, filename );

        outputStream = new BufferedOutputStream (
          new FileOutputStream ( file ) );

        int  i;

        while ( ( i = inputStream.read ( ) ) > -1 )
        {
          outputStream.write ( i );
        }
      }
      catch ( Exception  ex )
      {
        ex.printStackTrace ( );
      }
      finally
      {
        if ( outputStream != null )
        {
          try
          {
            outputStream.close ( );
          }
          catch ( Exception  ex )
          {
            ex.printStackTrace ( );
          }
        }

        if ( inputStream != null )
        {
          try
          {
            inputStream.close ( );
          }
          catch ( Exception  ex )
          {
            ex.printStackTrace ( );
          }
        }         
      }
    }

    private void  createImagePaths ( )
    ////////////////////////////////////////////////////////////////////////
    {
      try
      {
        final File  infantImagesDir
          = new File ( getInfantImagesDirPath ( ) );

        final File [ ]  imageFiles = infantImagesDir.listFiles ( );

        final Set<String>  imagePathSet = new HashSet<String> ( );

        for ( final File  imageFile : imageFiles )
        {
          imagePathSet.add ( imageFile.getCanonicalPath ( ) );
        }

        imagePaths = imagePathSet.toArray ( new String [ 0 ] );

        Arrays.sort ( imagePaths );
      }
      catch ( IOException  ex )
      {
        ex.printStackTrace ( );
      }
    }

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }