     package com.croftsoft.apps.client;
     
     import java.io.*;
     import java.net.*;
     import java.util.*;
     import java.util.concurrent.*;
     
     import com.croftsoft.core.io.StreamLib;
     import com.croftsoft.core.lang.*;
     import com.croftsoft.core.lang.lifecycle.*;
     import com.croftsoft.core.util.loop.*;
     
     /*********************************************************************
     * Network communications.
     * 
     * @version
     *   $Id: ClientNet.java,v 1.7 2006/12/16 05:05:27 croft Exp $
     * @since
     *   2006-10-30
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  ClientNet
       implements Lifecycle, Loopable
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private final ClientConfig  clientConfig;
       
     private final Queue<ClientMessage>
       modelQueue,
       netQueue;
     
     private final Looper  looper;
     
     //
     
     private URL  codeBase;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  ClientNet (
       final ClientConfig                  clientConfig,
       final BlockingQueue<ClientMessage>  netQueue,
       final Queue<ClientMessage>          modelQueue )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.checkArgs (
         this.clientConfig  = clientConfig,
         this.netQueue      = netQueue,
         this.modelQueue    = modelQueue );
       
       looper = new Looper (
         this, // loopable         
         new NanoTimeLoopGovernor ( ),
         null, // exceptionHandler
         getClass ( ).getName ( ), // threadName
         Thread.MIN_PRIORITY,
         true ); // useDaemonThread
     }
     
     //////////////////////////////////////////////////////////////////////
     // interface Lifecycle methods
     //////////////////////////////////////////////////////////////////////
     
     public void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       codeBase = clientConfig.getCodeBase ( );
       
       if ( codeBase == null )
       {
         try
         {
           final String  defaultCodeBaseName
             = clientConfig.getDefaultCodeBaseName ( );
         
           codeBase = new URL ( defaultCodeBaseName );
         }
         catch ( Exception  ex )
         {
           ex.printStackTrace ( );
           
           try
           {
             codeBase = new URL ( "http://localhost:8080/" );
           }
           catch ( Exception  ex2 )
           {
             ex2.printStackTrace ( );
           }
         }
        }
         
       LifecycleLib.init ( looper );
     }
     
     public void  start ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.start ( looper );
     }
     
     public void  stop ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.stop ( looper );
     }
     
     public void  destroy ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.destroy ( looper );
     }     
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public boolean  loop ( )
     //////////////////////////////////////////////////////////////////////
     {
       ClientMessage  message = null;
       
       while ( ( message = netQueue.poll ( ) ) != null )
       {
         final ClientMessage.Type  type = message.getType ( );
         
         switch ( type )
         {
           case SEND_TEXT_REQUEST:
             
             doSendTextRequest ( message );
             
             break;
             
           default:
             
             System.out.println ( getClass ( ).getName ( ) + ":  "
               + "unknown message type:  " + type );
         }
       }
       
       return true;
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     private void  doSendTextRequest ( final ClientMessage  clientMessage )
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         final String  text = ( String ) clientMessage.getContent ( );
       
         String  botIdParam = "";
         
         final String  botId = clientConfig.getBotId ( );
         
         if ( botId != null )
         {
           botIdParam = "botid=" + botId + "&";
         }
         
         final URL  url = new URL (
           codeBase,
           "/programd/GetBotResponse?"
           + botIdParam
           + "input=" + URLEncoder.encode ( text, "UTF-8" ) );
       
         final HttpURLConnection  httpURLConnection
           = ( HttpURLConnection ) url.openConnection ( );
         
         final InputStream  inputStream
           = httpURLConnection.getInputStream ( );
         
         final String  content = StreamLib.toString ( inputStream );
         
         inputStream.close ( );
         
         modelQueue.offer ( new ClientMessage (
           ClientMessage.Type.TEXT_EVENT,
           "bot:  " + content.toString ( ) ) );
         
         modelQueue.offer ( new ClientMessage (
           ClientMessage.Type.SPEECH_EVENT,
           content.toString ( ) ) );
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
         
         modelQueue.offer ( new ClientMessage (
           ClientMessage.Type.TEXT_EVENT, ex.getMessage ( ) ) );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }