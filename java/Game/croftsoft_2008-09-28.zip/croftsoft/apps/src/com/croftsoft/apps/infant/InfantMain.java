     package com.croftsoft.apps.infant;
     
     import java.util.*;
     
     import com.croftsoft.core.gui.*;
     import com.croftsoft.core.lang.lifecycle.*;
     
import com.croftsoft.core.util.loop.*;
import com.croftsoft.core.util.slot.Slot;
     
     /*********************************************************************
     * Infant stimulation and response with pacifier input.
     *  
     * @version
     *   $Id: InfantMain.java,v 1.17 2008/09/20 05:01:49 croft Exp $
     * @since
     *   2006-01-03
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  InfantMain
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     public static void  main ( final String [ ]  args )
     //////////////////////////////////////////////////////////////////////
     {
       final InfantConfig  infantConfig = InfantConfig.load ( );
       
       System.out.println ( "\n" + infantConfig.getInfo ( ) );
       
       final Queue<InfantMessage>  requestQueue
         = new LinkedList<InfantMessage> ( );
       
       final Slot<InfantMessage>  requestSlot = new Slot<InfantMessage> ( )
         {
           public boolean  offer ( final InfantMessage  infantMessage )
           {
             return requestQueue.offer ( infantMessage );
           }
         };
       
       final Queue<InfantMessage>  eventQueue
         = new LinkedList<InfantMessage> ( );
       
       final InfantModel  infantModel
         = new InfantModel ( infantConfig, requestQueue, eventQueue );
       
       final InfantView  infantView = new InfantView (
         infantConfig, infantModel, eventQueue, requestSlot );
       
       final InfantController  infantController
         = new InfantController ( infantConfig, requestQueue );
       
       infantView.addUserInputListener ( infantController );
       
       final Updatable [ ]  updatables = new Updatable [ ] {
         infantController,
         infantModel,
         infantView };
       
       final Looper  looper = new Looper (
         new EventQueueUpdateLoop ( updatables ), // loopable
         new NanoTimeLoopGovernor ( infantConfig.getUpdateRate ( ) ),
         null, // exceptionHandler
         infantConfig.getThreadName ( ),
         Thread.MIN_PRIORITY,
         true ); // useDaemonThread
       
       LifecycleWindowListener.launchFrameAsDesktopApp (
         infantView.getJFrame ( ),
         new CompositeLifecycle (
           new Initializable [ ] { looper },
           new Startable     [ ] { looper },
           new Stoppable     [ ] { },
           new Destroyable   [ ] { infantView, looper, infantModel } ),
         infantConfig.getFrameSize ( ),
         infantConfig.getShutdownConfirmationPrompt ( ) );
     }
       
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }