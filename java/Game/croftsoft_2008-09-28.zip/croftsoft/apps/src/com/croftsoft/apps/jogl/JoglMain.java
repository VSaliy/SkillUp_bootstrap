    package com.croftsoft.apps.jogl;
     
    import java.awt.*;
    import javax.swing.*;
    
    import com.croftsoft.core.gui.LifecycleWindowListener;
    import com.croftsoft.core.lang.lifecycle.Lifecycle;
    import com.croftsoft.core.lang.lifecycle.LifecycleLib;
    import com.croftsoft.core.lang.lifecycle.Updatable;
    import com.croftsoft.core.util.loop.EventQueueUpdateLoop;
    import com.croftsoft.core.util.loop.Looper;
    import com.croftsoft.core.util.loop.NanoTimeLoopGovernor;
    import com.croftsoft.core.util.mail.FlipMail;
     
    import com.croftsoft.apps.jogl.imp.JoglConfigImp;
    import com.croftsoft.apps.jogl.imp.JoglModelImp;

    /***********************************************************************
    * Main.
    *
    * Launches the application within a framework.
    * 
    * @version
    *   $Id: JoglMain.java,v 1.9 2008/04/19 21:57:09 croft Exp $
    * @since
    *   2008-02-10
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  JoglMain
      implements Lifecycle
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private final JoglConfig      joglConfig;
     
    private final JoglModelImp    joglModelImp;
     
    private final JoglController  joglController;
       
    private final JoglView        joglView;
     
    private final Looper          looper;
       
    ////////////////////////////////////////////////////////////////////////
    // public static methods
    ////////////////////////////////////////////////////////////////////////

    public static void  main ( final String [ ]  args )
    ////////////////////////////////////////////////////////////////////////
    {
      final JoglMain  joglMain = new JoglMain ( args );
       
      final JFrame  jFrame = new JFrame (
        joglMain.joglConfig.getFrameTitle ( ) );
       
      joglMain.setContentPane ( jFrame.getContentPane ( ) );
       
      // The Frame is the framework.
       
      LifecycleWindowListener.launchFrameAsDesktopApp (
        jFrame,
        joglMain,
        joglMain.joglConfig.getFrameSize ( ),
        joglMain.joglConfig.getShutdownConfirmationPrompt ( ) );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // constructor methods
    ////////////////////////////////////////////////////////////////////////
     
    public  JoglMain ( final String [ ]  args )
    ////////////////////////////////////////////////////////////////////////
    {
      joglConfig = JoglConfigImp.load ( args );
       
      System.out.println ( "\n" + joglConfig.getInfo ( ) );
      
      final FlipMail<JoglMessage>  flipMail
        = new FlipMail<JoglMessage> ( );
       
      joglModelImp = new JoglModelImp (
        joglConfig,
        flipMail );
       
      joglController = new JoglController ( flipMail );
       
      joglView = new JoglView (
        flipMail,
        joglModelImp );
      
      joglView.addKeyListener ( joglController );
       
      joglView.addMouseListener ( joglController );
       
      final Updatable [ ]  updatables = new Updatable [ ] {
        flipMail,
        joglModelImp,
        joglView,
        joglController };
       
      looper = new Looper (
        new EventQueueUpdateLoop ( updatables ), // loopable
        new NanoTimeLoopGovernor ( joglConfig.getUpdateRate ( ) ),
        null, // exceptionHandler
        joglConfig.getThreadName ( ),
        Thread.MIN_PRIORITY,
        true ); // useDaemonThread
    }
     
    ////////////////////////////////////////////////////////////////////////
    // accessor methods
    ////////////////////////////////////////////////////////////////////////
     
    public JoglConfig  getJoglConfig ( )
    ////////////////////////////////////////////////////////////////////////
    {
      return joglConfig;
    }
     
    ////////////////////////////////////////////////////////////////////////
    // mutator methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  setContentPane ( final Container  contentPane )
    ////////////////////////////////////////////////////////////////////////
    {
      joglView.setContentPane ( contentPane );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // interface Lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.init ( joglView, looper );
    }
     
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.start ( joglView, joglController, looper );
    }
     
    public void  stop ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.stop ( joglView, looper );
    }
     
    public void  destroy ( )
    ////////////////////////////////////////////////////////////////////////
    {
      LifecycleLib.destroy ( joglView, looper );
    }     
       
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }