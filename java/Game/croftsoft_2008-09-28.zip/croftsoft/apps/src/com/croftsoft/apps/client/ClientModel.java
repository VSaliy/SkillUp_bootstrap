     package com.croftsoft.apps.client;
     
     import java.util.*;
     
     import com.croftsoft.core.lang.*;
     import com.croftsoft.core.lang.lifecycle.Updatable;
     
     /*********************************************************************
     * Exemplar model.
     * 
     * Maintains program state.
     * 
     * @version
     *   $Id: ClientModel.java,v 1.6 2006/12/16 05:05:27 croft Exp $
     * @since
     *   2006-10-30
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  ClientModel
       implements Updatable
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     // private final instance variables
       
     private final Queue<ClientMessage>
       modelQueue,
       netQueue,
       viewQueue;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  ClientModel (
       final Queue<ClientMessage>  modelQueue,
       final Queue<ClientMessage>  viewQueue,
       final Queue<ClientMessage>  netQueue )
     //////////////////////////////////////////////////////////////////////
     {
       NullArgumentException.checkArgs (
         this.modelQueue = modelQueue,
         this.viewQueue  = viewQueue,
         this.netQueue   = netQueue );
     }
     
     //////////////////////////////////////////////////////////////////////
     // lifecycle methods
     //////////////////////////////////////////////////////////////////////
     
     public void  update ( )
     //////////////////////////////////////////////////////////////////////
     {
       ClientMessage  message = null;
       
       while ( ( message = modelQueue.poll ( ) ) != null )
       {
         final ClientMessage.Type  type = message.getType ( );
         
         switch ( type )
         {
           case SEND_TEXT_REQUEST:
             
             netQueue.offer ( message );
             
             break;
             
           case SPEECH_EVENT:
             
             viewQueue.offer ( message );
             
             break;
             
           case TEXT_EVENT:
             
             viewQueue.offer ( message );
             
             break;
             
           default:
             
             System.out.println ( getClass ( ).getName ( ) + ":  "
               + "unknown message type:  " + type );
         }
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }