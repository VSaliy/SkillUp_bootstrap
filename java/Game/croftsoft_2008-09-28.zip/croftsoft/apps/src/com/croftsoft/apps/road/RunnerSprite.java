     package com.croftsoft.apps.road;
     
     import java.applet.*;
     import java.awt.*;
     import java.awt.event.*;
     import java.awt.geom.*;
     import java.io.*;
     import java.net.URL;
     import java.util.*;
     import javax.swing.*;
     import javax.swing.event.*;

     import com.croftsoft.core.animation.clock.Timekeeper;
     import com.croftsoft.core.animation.sprite.IconSprite;

     import com.croftsoft.apps.road.model.Car;

     /*********************************************************************
     * Roadrunner Sprite.
     *
     * @version
     *   2003-11-09
     * @since
     *   2003-08-05
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  RunnerSprite
       extends IconSprite
       implements Constants
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     private final Car         car;

     private final Timekeeper  timekeeper;

     //

     private Point  mousePoint;

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public  RunnerSprite (
       Car         car,
       Icon        runnerIcon,
       Timekeeper  timekeeper,
       Component   component )
     //////////////////////////////////////////////////////////////////////
     {
       super ( runnerIcon );

       this.car = car;

       this.timekeeper = timekeeper;

       // initialize mouse input

       component.addMouseMotionListener (
         new MouseMotionAdapter ( )
         {
           public void  mouseMoved ( MouseEvent  mouseEvent )
           {
             mousePoint = mouseEvent.getPoint ( );
           }
         } );

       component.addMouseListener (
         new MouseAdapter ( )
         {
           public void  mouseExited ( MouseEvent  mouseEvent )
           {
             mousePoint = null;
           }
         } );
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public void  update ( JComponent  component )
     //////////////////////////////////////////////////////////////////////
     {
       if ( mousePoint != null )
       {
         car.setDestinationPoint ( mousePoint );

         mousePoint = null;
       }

       double  timeDelta = timekeeper.getTimeDelta ( );

       car.update ( timeDelta );

       x = car.getCenterX ( );

       y = car.getCenterY ( );
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }