     package com.croftsoft.apps.slideshow;
     
     import java.awt.*;
     import javax.swing.*;

     import com.croftsoft.core.gui.LifecycleWindowListener;
     import com.croftsoft.core.lang.lifecycle.Lifecycle;
     import com.croftsoft.core.lang.lifecycle.LifecycleLib;
     import com.croftsoft.core.lang.lifecycle.Updatable;
     import com.croftsoft.core.util.loop.EventQueueUpdateLoop;
     import com.croftsoft.core.util.loop.Looper;
     import com.croftsoft.core.util.loop.NanoTimeLoopGovernor;

     /*********************************************************************
     * CroftSoft Savor.
     *
     * @version
     *   $Id: SlideshowMain.java,v 1.1 2006/12/16 09:27:57 croft Exp $
     * @since
     *   2006-12-09
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  SlideshowMain
       implements Lifecycle
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
     
     private final SlideshowConfig  slideshowConfig;
     
     private final SlideshowView    slideshowView;
       
     private final Looper           looper;
     
     //////////////////////////////////////////////////////////////////////
     // public static methods
     //////////////////////////////////////////////////////////////////////

     public static void  main ( final String [ ]  args )
     //////////////////////////////////////////////////////////////////////
     {
       final SlideshowMain  slideshowMain = new SlideshowMain ( args );
       
       final JFrame  jFrame = new JFrame (
         slideshowMain.slideshowConfig.getFrameTitle ( ) );
       
       slideshowMain.setContentPane ( jFrame.getContentPane ( ) );
       
       // The Frame is the framework.
       
       LifecycleWindowListener.launchFrameAsDesktopApp (
         jFrame,
         slideshowMain,
         slideshowMain.slideshowConfig.getFrameSize ( ),
         slideshowMain.slideshowConfig.getShutdownConfirmationPrompt ( ) );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  SlideshowMain ( final String [ ]  args )
     //////////////////////////////////////////////////////////////////////
     {
       slideshowConfig = SlideshowConfig.load ( args );
       
       slideshowView = new SlideshowView ( slideshowConfig );
       
       final Updatable [ ]  updatables = new Updatable [ ] {
         slideshowView };
       
       looper = new Looper (
         new EventQueueUpdateLoop ( updatables ), // loopable
         new NanoTimeLoopGovernor ( slideshowConfig.getUpdateRate ( ) ),
         null, // exceptionHandler
         slideshowConfig.getThreadName ( ),
         Thread.MIN_PRIORITY,
         true ); // useDaemonThread
     }
     
     //////////////////////////////////////////////////////////////////////
     // accessor methods
     //////////////////////////////////////////////////////////////////////
     
     public SlideshowConfig  getSlideshowConfig ( )
     //////////////////////////////////////////////////////////////////////
     {
       return slideshowConfig;
     }
     
     //////////////////////////////////////////////////////////////////////
     // mutator methods
     //////////////////////////////////////////////////////////////////////
     
     public void  setContentPane ( final Container  contentPane )
     //////////////////////////////////////////////////////////////////////
     {
       slideshowView.setContentPane ( contentPane );
     }
     
     //////////////////////////////////////////////////////////////////////
     // interface Lifecycle methods
     //////////////////////////////////////////////////////////////////////
     
     public void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.init ( slideshowView, looper );
     }
     
     public void  start ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.start ( looper );
     }
     
     public void  stop ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.stop ( looper );
     }
     
     public void  destroy ( )
     //////////////////////////////////////////////////////////////////////
     {
       LifecycleLib.destroy ( looper );
     }     
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }