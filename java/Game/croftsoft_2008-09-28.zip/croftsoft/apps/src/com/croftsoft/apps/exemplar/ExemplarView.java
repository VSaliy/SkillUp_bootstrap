    package com.croftsoft.apps.exemplar;
     
    import java.awt.*;
    import java.awt.event.*;
    import javax.swing.*;
     
    import com.croftsoft.core.animation.ComponentAnimator;
    import com.croftsoft.core.animation.animator.NullComponentAnimator;
    import com.croftsoft.core.lang.NullArgumentException;
    import com.croftsoft.core.lang.lifecycle.Lifecycle;
    import com.croftsoft.core.lang.lifecycle.Updatable;
    import com.croftsoft.core.util.mail.Mail;
     
    /***********************************************************************
    * Exemplar view.
    *  
    * @version
    *   $Id: ExemplarView.java,v 1.9 2008/02/15 22:38:03 croft Exp $
    * @since
    *   2006-01-03
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  ExemplarView
      implements Lifecycle, Updatable
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
    	 
    private final ExemplarConfig         exemplarConfig;
    
    private final Mail<ExemplarMessage>  mail;
    
    private final ExemplarModel          exemplarModel;
     
    private final JComponent             jComponent;
     
    //
     
    private ComponentAnimator  componentAnimator;
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public  ExemplarView (
      final ExemplarConfig         exemplarConfig,
      final Mail<ExemplarMessage>  mail,
      final ExemplarModel          exemplarModel )
    ////////////////////////////////////////////////////////////////////////
    {
      NullArgumentException.checkArgs (
        this.exemplarConfig = exemplarConfig,
        this.mail           = mail,
        this.exemplarModel  = exemplarModel );
       
      componentAnimator = NullComponentAnimator.INSTANCE;
       
      jComponent = new JComponent ( )
        {
          private static final long  serialVersionUID = 0L;
    	   
          @Override
          public void  paintComponent ( final Graphics  graphics )
          {
            componentAnimator.paint ( this, ( Graphics2D ) graphics );
          }
        };
    }
     
    ////////////////////////////////////////////////////////////////////////
    // mutator methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  addMouseListener ( final MouseListener  mouseListener )
    ////////////////////////////////////////////////////////////////////////
    {
      jComponent.addMouseListener ( mouseListener );
    }
     
    public void  setContentPane ( final Container  contentPane )
    ////////////////////////////////////////////////////////////////////////
    {
      contentPane.setLayout ( new BorderLayout ( ) );
       
      contentPane.add ( jComponent, BorderLayout.CENTER );
    }
     
    ////////////////////////////////////////////////////////////////////////
    // lifecycle methods
    ////////////////////////////////////////////////////////////////////////
     
    public void  init ( )
    ////////////////////////////////////////////////////////////////////////
    {
      System.out.println ( "ExemplarView.init()" );
       
      componentAnimator = new ExemplarAnimator (
        exemplarConfig,
        exemplarModel,
        jComponent );
    }
     
    public void  start ( )
    ////////////////////////////////////////////////////////////////////////
    {
      System.out.println ( "ExemplarView.start()" );       
    }
     
    public void  stop ( )
    ////////////////////////////////////////////////////////////////////////
    {
      System.out.println ( "ExemplarView.stop()" );       
    }
     
    public void  destroy ( )
    ////////////////////////////////////////////////////////////////////////
    {
      System.out.println ( "ExemplarView.destroy()" );
    }
     
    public void  update ( )
    ////////////////////////////////////////////////////////////////////////
    {
      final int  size = mail.size ( );
      
      for ( int  i = 0; i < size; i++ )
      {
        final ExemplarMessage  exemplarMessage = mail.get ( i );
        
        final ExemplarMessage.Type  type = exemplarMessage.getType ( );
         
        switch ( type )
        {
          case CLICK_COUNT_CHANGED:
             
            Toolkit.getDefaultToolkit ( ).beep ( );
             
            break;
             
          default:
            
            // ignore
        }
      }
       
      componentAnimator.update ( jComponent );
    }       
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }