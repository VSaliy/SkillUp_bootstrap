     package com.croftsoft.apps.chat.response;

     /*********************************************************************
     * Response to a MoveRequest.
     *
     * @version
     *   $Date: 2008/04/19 21:46:35 $
     * @since
     *   2003-06-10
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  MoveResponse
       extends AbstractResponse
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     private static final long  serialVersionUID = 0L;

     //

     private final boolean  noModel;

     private final boolean  modelNotInWorld;

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public  MoveResponse (
       boolean  denied,
       boolean  noModel,
       boolean  modelNotInWorld )
     //////////////////////////////////////////////////////////////////////
     {
       super ( denied );

       this.noModel = noModel;

       this.modelNotInWorld = modelNotInWorld;
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////

     public boolean  getNoModel         ( ) { return noModel;         }

     public boolean  getModelNotInWorld ( ) { return modelNotInWorld; }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }
