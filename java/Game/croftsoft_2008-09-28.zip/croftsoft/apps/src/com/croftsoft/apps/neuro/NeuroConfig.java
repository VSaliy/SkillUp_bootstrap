    package com.croftsoft.apps.neuro;
     
    import java.awt.*;
     
    /***********************************************************************
    * Neuro configuration.
    *  
    * Can be modified to be persistent.
    * 
    * @version
    *   $Id: NeuroConfig.java,v 1.1 2008/08/17 21:03:25 croft Exp $
    * @since
    *   2008-08-17
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public interface  NeuroConfig
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
     
    public Color      getBackgroundColor ( );
     
    public Cursor     getCursor ( );
     
    public String     getExampleParameter ( );
     
    public Color      getForegroundColor ( );
     
    public String     getInfo ( );
     
    public Font       getFont ( );
     
    public Dimension  getFrameSize ( );
     
    public String     getFrameTitle ( );

    public String     getShutdownConfirmationPrompt ( );
     
    public String     getThreadName ( );
     
    public double     getUpdateRate ( );
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public void  setExampleParameter ( final String  exampleParameter );
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }