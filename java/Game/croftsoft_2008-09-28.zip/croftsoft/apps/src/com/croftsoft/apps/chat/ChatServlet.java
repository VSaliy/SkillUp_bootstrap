     package com.croftsoft.apps.chat;

     import javax.servlet.*;

     import com.croftsoft.core.io.SerializableCoder;
     import com.croftsoft.core.servlet.HttpGatewayServlet;

     import com.croftsoft.apps.chat.server.ChatServer;

     /*********************************************************************
     * Chat servlet.
     *
     * @version
     *   $Id: ChatServlet.java,v 1.3 2008/04/19 21:31:00 croft Exp $
     * @since
     *   2000-04-27
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  ChatServlet
       extends HttpGatewayServlet
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {

     private static final long  serialVersionUID = 0L;
     
     //
      
     private final ChatServer  chatServer;

     //////////////////////////////////////////////////////////////////////
     // constructor methods
     //////////////////////////////////////////////////////////////////////

     private  ChatServlet ( ChatServer  chatServer )
     //////////////////////////////////////////////////////////////////////
     {
       super (
         chatServer,
         SerializableCoder.INSTANCE,
         SerializableCoder.INSTANCE );

       this.chatServer = chatServer;
     }

     public  ChatServlet ( )
     //////////////////////////////////////////////////////////////////////
     {
       this ( new ChatServer ( ) );
     }

     //////////////////////////////////////////////////////////////////////
     // overridden Servlet methods
     //////////////////////////////////////////////////////////////////////

     @Override
     public String  getServletInfo ( ) { return ChatConstants.INFO; }

     @Override
     public void  init ( )
       throws ServletException
     //////////////////////////////////////////////////////////////////////
     {
       System.out.println ( getServletInfo ( ) );

       chatServer.init ( );
     }

     @Override
     public void  destroy ( )
     //////////////////////////////////////////////////////////////////////
     {
       chatServer.destroy ( );
     }

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }
