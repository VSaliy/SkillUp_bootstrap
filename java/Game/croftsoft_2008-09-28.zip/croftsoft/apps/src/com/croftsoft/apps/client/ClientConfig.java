     package com.croftsoft.apps.client;
     
     import java.awt.*;
     import java.net.*;
     
     import com.croftsoft.core.CroftSoftConstants;
     
     /*********************************************************************
     * Configuration.
     *  
     * Can be modified to be persistent.
     * 
     * @version
     *   $Id: ClientConfig.java,v 1.7 2006/12/09 05:24:59 croft Exp $
     * @since
     *   2006-10-30
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  ClientConfig
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final String  VERSION
       = "$Date: 2006/12/09 05:24:59 $";
   
     private static final String  TITLE
       = "CroftSoft Client";
   
     private static final String  INFO
       = TITLE + "\n"
       + "Version " + VERSION + "\n"
       + CroftSoftConstants.COPYRIGHT + "\n"
       + CroftSoftConstants.DEFAULT_LICENSE + "\n"
       + CroftSoftConstants.HOME_PAGE + "\n";

     private static final String  DEFAULT_CODE_BASE_NAME
       = "http://CroftSoft.com:8080/";
     
     private static final int
       FRAME_WIDTH  = 600,
       FRAME_HEIGHT = 400;
   
     private static final double  UPDATE_RATE = 85.0;
     
     private static final String
       SHUTDOWN_CONFIRMATION_PROMPT = "Exit " + TITLE + "?";
     
     private static final Font    FONT
       = new Font ( "Arioso", Font.BOLD, 20 );
     
     //
     
     private String  botId;
     
     private URL     codeBase;

     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public static ClientConfig  load ( String [ ]  args )
     //////////////////////////////////////////////////////////////////////
     {
       // Could load from a persistent XML file.
       
       return new ClientConfig ( );
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  ClientConfig ( )
     //////////////////////////////////////////////////////////////////////
     {
       try
       {
         System.setProperty (
           "freetts.voices",
           "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory" );
       }
       catch ( final Exception  ex )
       {
         ex.printStackTrace ( );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public String  getBotId ( ) { return botId; }
     
     public URL     getCodeBase ( ) { return codeBase; }
     
     public String  getDefaultCodeBaseName ( ) {
       return DEFAULT_CODE_BASE_NAME; }
     
     public String  getInfo ( ) { return INFO; }
     
     public Font  getFont ( ) { return FONT; }
     
     public Dimension  getFrameSize ( )
       { return new Dimension ( FRAME_WIDTH, FRAME_HEIGHT ); }
     
     public String  getFrameTitle ( ) { return TITLE; }

     public String  getShutdownConfirmationPrompt ( )
       { return SHUTDOWN_CONFIRMATION_PROMPT; }
     
     public String  getThreadName ( ) { return TITLE; }
     
     public double  getUpdateRate ( ) { return UPDATE_RATE; }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public void  setBotId ( final String  botId )
     //////////////////////////////////////////////////////////////////////
     {
       this.botId = botId;
     }
     
     public void  setCodeBase ( final URL  codeBase )
     //////////////////////////////////////////////////////////////////////
     {
       this.codeBase = codeBase;
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }