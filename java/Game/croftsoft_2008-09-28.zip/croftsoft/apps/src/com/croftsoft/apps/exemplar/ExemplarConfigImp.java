    package com.croftsoft.apps.exemplar;
     
    import java.awt.*;
     
    import com.croftsoft.core.CroftSoftConstants;
     
    /***********************************************************************
    * Exemplar configuration.
    *  
    * Can be modified to be persistent.
    * 
    * @version
    *   $Id: ExemplarConfigImp.java,v 1.2 2008/04/19 21:31:00 croft Exp $
    * @since
    *   2006-01-03
    * @author
    *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
    ***********************************************************************/

    public final class  ExemplarConfigImp
      implements ExemplarConfig
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    {
       
    private static final String  VERSION
      = "$Date: 2008/04/19 21:31:00 $";
   
    private static final String  TITLE
      = "CroftSoft Exemplar";
   
    private static final String  INFO
      = TITLE + "\n"
      + "Version " + VERSION + "\n"
      + CroftSoftConstants.COPYRIGHT + "\n"
      + CroftSoftConstants.DEFAULT_LICENSE + "\n"
      + CroftSoftConstants.HOME_PAGE + "\n";
     
    private static final int
      FRAME_WIDTH  = 600,
      FRAME_HEIGHT = 400;
   
    private static final double  UPDATE_RATE = 85.0;
     
    private static final Color
      BACKGROUND_COLOR = Color.WHITE,
      FOREGROUND_COLOR = Color.BLACK;
     
    private static final String
      SHUTDOWN_CONFIRMATION_PROMPT = "Exit " + TITLE + "?";
     
    private static final Cursor  CURSOR
      = new Cursor ( Cursor.CROSSHAIR_CURSOR );
   
    private static final Font    FONT
      = new Font ( "Arioso", Font.BOLD, 20 );
     
    //
     
    private String  exampleParameter;

    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public static ExemplarConfig  load ( String [ ]  args )
    ////////////////////////////////////////////////////////////////////////
    {
      // Could load from a persistent XML file.
      // See "Enumerated Accessors" tutorial at
      // http://www.CroftSoft.com/library/tutorials/enum/
       
      final ExemplarConfig  exemplarConfig = new ExemplarConfigImp ( );
       
      if ( ( args != null    )
        && ( args.length > 0 ) )
      {
        exemplarConfig.setExampleParameter ( args [ 0 ] );
      }
       
      return exemplarConfig;
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public Color   getBackgroundColor ( ) { return BACKGROUND_COLOR; }
     
    public Cursor  getCursor ( ) { return CURSOR; }
     
    public String  getExampleParameter ( ) { return exampleParameter; }
     
    public Color   getForegroundColor ( ) { return FOREGROUND_COLOR; }
     
    public String  getInfo ( ) { return INFO; }
     
    public Font    getFont ( ) { return FONT; }
     
    public Dimension  getFrameSize ( )
      { return new Dimension ( FRAME_WIDTH, FRAME_HEIGHT ); }
     
    public String  getFrameTitle ( ) { return TITLE; }

    public String  getShutdownConfirmationPrompt ( )
      { return SHUTDOWN_CONFIRMATION_PROMPT; }
     
    public String  getThreadName ( ) { return TITLE; }
     
    public double  getUpdateRate ( ) { return UPDATE_RATE; }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
     
    public void  setExampleParameter ( final String  exampleParameter )
    ////////////////////////////////////////////////////////////////////////
    {
      this.exampleParameter = exampleParameter;
    }
     
    ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    }