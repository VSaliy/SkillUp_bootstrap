     package com.croftsoft.apps.savor;
     
     import java.awt.*;
     import java.util.*;
     
     import org.jdesktop.jdic.screensaver.ScreensaverContext;
     import org.jdesktop.jdic.screensaver.ScreensaverSettings;
     import org.jdesktop.jdic.screensaver.SimpleScreensaver;
     
     /*********************************************************************
     * CroftSoft Savor.
     *
     * @version
     *   $Id: Savor2D.java,v 1.1 2006/12/09 06:31:36 croft Exp $
     * @since
     *   2006-09-26
     * @author
     *   <a href="http://www.CroftSoft.com/">David Wallace Croft</a>
     *********************************************************************/

     public final class  Savor2D
       extends SimpleScreensaver
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     {
       
     private static final String  PROPERTY_OVAL_SIZE = "ovalSize";
       
     private static final String [ ]  PROPERTY_VALUES = {
       "tiny",
       "small",
       "medium",
       "large" };
     
     private static final int [ ]  OVAL_SIZE_DIVISORS = {
       Integer.MAX_VALUE,
       8,
       4,
       2 };
     
     private static final int  FRAME_PERIOD = 50;
     
     //
     
     private final Map<String, Integer>  ovalSizeMap;
     
     private final Random  random;
     
     //
       
     private int
       ovalSize,
       width,
       height;
     
     private Image  offscreenImage;
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     public  Savor2D ( )
     //////////////////////////////////////////////////////////////////////
     {
       random = new Random ( );
       
       ovalSizeMap = new HashMap<String, Integer> ( );
       
       for ( int  i = 0; i < PROPERTY_VALUES.length; i++ )
       {
         ovalSizeMap.put (
           PROPERTY_VALUES [ i ],
           new Integer ( OVAL_SIZE_DIVISORS [ i ] ) );
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     
     @Override
     public void  init ( )
     //////////////////////////////////////////////////////////////////////
     {
       int  ovalSizeDivisor
         = OVAL_SIZE_DIVISORS [ OVAL_SIZE_DIVISORS.length - 1 ];
       
       final ScreensaverContext  screensaverContext = getContext ( );
       
       final ScreensaverSettings  screensaverSettings
         = screensaverContext.getSettings ( );
       
       String  propertyValue
         = screensaverSettings.getProperty ( PROPERTY_OVAL_SIZE );
       
       if ( propertyValue != null )
       {
         propertyValue = propertyValue.trim ( ).toLowerCase ( );
         
         final Integer  ovalSizeDivisorInteger
           = ovalSizeMap.get ( propertyValue );
         
         if ( ovalSizeDivisorInteger != null )
         {
           ovalSizeDivisor = ovalSizeDivisorInteger.intValue ( );
         }
       }
       
       final Component  component = screensaverContext.getComponent ( );
       
       final int  componentWidth  = component.getWidth  ( );
       
       final int  componentHeight = component.getHeight ( );
       
       if ( ( componentWidth  > 0 )
         && ( componentHeight > 0 ) )
       {       
         offscreenImage
           = component.createImage ( componentWidth, componentHeight );
       }
       
       ovalSize = Math.max (
         1,
         Math.min ( componentWidth, componentHeight ) / ovalSizeDivisor );
       
       width  = componentWidth  + 2 * ovalSize;
       
       height = componentHeight + 2 * ovalSize;
     }
       
     @Override
     public void  paint ( final Graphics  graphics )
     //////////////////////////////////////////////////////////////////////
     {
       if ( offscreenImage == null )
       {
         return;
       }
       
       final Graphics2D  offscreenGraphics2D
         = ( Graphics2D ) offscreenImage.getGraphics ( );
       
       offscreenGraphics2D.setRenderingHint (
         RenderingHints.KEY_ANTIALIASING,
         RenderingHints.VALUE_ANTIALIAS_ON );
       
       offscreenGraphics2D.setColor (
         new Color (
           ( float ) Math.random ( ),
           ( float ) Math.random ( ),
           ( float ) Math.random ( ) ) );
       
       final int  ovalWidth  = Math.max (
         1, ( int ) ( ovalSize * ( 1 + 0.2 * random.nextGaussian ( ) ) ) );
       
       final int  ovalHeight = Math.max (
         1, ( int ) ( ovalSize * ( 1 + 0.2 * random.nextGaussian ( ) ) ) );
       
       offscreenGraphics2D.fillOval (
         ( int ) ( Math.random ( ) * width  ) - ovalSize,
         ( int ) ( Math.random ( ) * height ) - ovalSize,
         ovalWidth,
         ovalHeight );
       
       offscreenGraphics2D.dispose ( );
       
       graphics.drawImage ( offscreenImage, 0, 0, null );
       
       try
       {
         Thread.sleep ( FRAME_PERIOD );
       }
       catch ( final InterruptedException  ex )
       {
         // ignore
       }
     }
     
     //////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////
     }