package packt.java9.by.example.mybusiness;


public interface SpringScanBase {
}
