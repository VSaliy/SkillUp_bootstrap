package com.javax0.aptools;

/**
 * Alias class for {@link AbstractToolFactory}
 *
 */
public class FromThe extends AbstractToolFactory {

}
