package packt.java9.by.example.mastermind.integration;

public interface Player {
    void play();
}
