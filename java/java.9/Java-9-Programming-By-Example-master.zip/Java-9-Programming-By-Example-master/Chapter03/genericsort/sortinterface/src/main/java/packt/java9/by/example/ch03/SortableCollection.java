package packt.java9.by.example.ch03;

public interface SortableCollection<E> {
    E get(int i);
    int size();
}
