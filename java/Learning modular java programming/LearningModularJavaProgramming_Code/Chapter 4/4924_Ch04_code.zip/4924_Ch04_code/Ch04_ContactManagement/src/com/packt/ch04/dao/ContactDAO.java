package com.packt.ch04.dao;

import com.packt.ch04.pojo.Contact;

public interface ContactDAO {
  int addContact(Contact contact);
}
