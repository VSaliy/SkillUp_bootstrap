package com.packt.ch04.pojo;

public class Gender {
	private int id;
	private String value;

	public Gender() {
		// TODO Auto-generated constructor stub
		id = 1;
		value = "F";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}


}
