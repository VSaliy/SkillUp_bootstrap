fun main(args: Array<String>) {
     val myInt = 5 //infers type as `Int`
     val myString = "Alpha" //infers type as `String`

     println("myInt=$myInt and myString=$myString")
 }