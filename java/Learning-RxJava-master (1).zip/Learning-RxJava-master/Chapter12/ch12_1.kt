fun main(args: Array<String>) {
     val myInt: Int = 5
     val myString: String = "Alpha"

     println("myInt=$myInt and myString=$myString")
 }