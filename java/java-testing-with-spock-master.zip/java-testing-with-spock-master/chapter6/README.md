# Chapter 6 sample code from "Java testing with Spock".

Requirements

1. JDK
2. Maven


