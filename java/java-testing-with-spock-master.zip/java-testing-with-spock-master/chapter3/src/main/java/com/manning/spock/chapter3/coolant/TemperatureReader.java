package com.manning.spock.chapter3.coolant;

public interface TemperatureReader {
	TemperatureReadings getCurrentReadings();
}
