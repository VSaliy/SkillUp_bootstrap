package com.manning.spock.chapter3.coolant;

public class TemperatureReadings {

	private long sensor1Data;
	private long sensor2Data;
	private long sensor3Data;
	
	public long getSensor1Data() {
		return sensor1Data;
	}
	public void setSensor1Data(long sensor1Data) {
		this.sensor1Data = sensor1Data;
	}
	public long getSensor2Data() {
		return sensor2Data;
	}
	public void setSensor2Data(long sensor2Data) {
		this.sensor2Data = sensor2Data;
	}
	public long getSensor3Data() {
		return sensor3Data;
	}
	public void setSensor3Data(long sensor3Data) {
		this.sensor3Data = sensor3Data;
	}
	
	
}
