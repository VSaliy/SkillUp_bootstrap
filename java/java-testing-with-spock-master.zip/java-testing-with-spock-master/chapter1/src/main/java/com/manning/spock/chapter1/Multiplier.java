package com.manning.spock.chapter1;

public class Multiplier {
	
	public int multiply(int a, int b) {
//		if(a == 4) //A dummy bug that happens only if the first argument is 4
//		{
//			return 5 * b; //multiply an extra time.
//		}
		return a *b;
	}

}
