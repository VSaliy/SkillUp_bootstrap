package com.manning.spock.chapter8.loan;

public class CreditCard {
	
	private int totalAmountSpent;
	private int amountDue;
	
	public CreditCard(String number) {
		
	}
	
	public int getTotalAmountSpent() {
		return totalAmountSpent;
	}
	public void setTotalAmountSpent(int totalAmountSpent) {
		this.totalAmountSpent = totalAmountSpent;
	}
	public int getAmountDue() {
		return amountDue;
	}
	public void setAmountDue(int amountDue) {
	}
	
	public void assign(BankAccount bankAccount)	{
		
	}
	
	public void setHolder(String name)	{
		
	}
	
}
